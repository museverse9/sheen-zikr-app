package com.sheen.zikr.data.local

import android.content.Context
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BackupSummary(
    val zikrCount: Int,
    val dailyLogCount: Int,
    val hourlyLogCount: Int
)

data class ImportResult(
    val zikrCount: Int,
    val dailyLogsImported: Int,
    val hourlyLogsImported: Int
)

object BackupManager {

    fun defaultBackupFileName(): String {
        val stamp = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        return "sheen-zikr-backup-$stamp.json"
    }

    fun parseBackupSummary(rawJson: String): BackupSummary {
        val root = JSONObject(rawJson)
        val zikrArr = root.optJSONArray("zikrItems") ?: JSONArray()
        val dailyArr = root.optJSONArray("dailyLogs") ?: JSONArray()
        val hourlyArr = root.optJSONArray("hourlyLogs") ?: JSONArray()
        return BackupSummary(
            zikrCount = zikrArr.length(),
            dailyLogCount = dailyArr.length(),
            hourlyLogCount = hourlyArr.length()
        )
    }

    suspend fun exportBackupJson(context: Context): String = withContext(Dispatchers.IO) {
        val db = SheenDatabase.getInstance(context)
        val zikrDao = db.zikrDao()
        val dailyDao = db.dailyLogDao()
        val hourlyDao = db.hourlyLogDao()

        val items = zikrDao.observeAll().first()
        val daily = dailyDao.observeAll().first()
        val hourly = hourlyDao.getAll()

        val root = JSONObject().apply {
            put("app", "SHEEN")
            put("version", 2)
            put("exportedAt", System.currentTimeMillis())
        }

        val zikrArr = JSONArray()
        items.forEach { z ->
            zikrArr.put(
                JSONObject().apply {
                    put("id", z.id)
                    put("name", z.name)
                    put("targetCount", z.targetCount)
                    put("currentCount", z.currentCount)
                    put("completedRounds", z.completedRounds)
                    put("sortOrder", z.sortOrder)
                    put("createdAt", z.createdAt)
                    put("updatedAt", z.updatedAt)
                    put("currentRoundElapsedMs", z.currentRoundElapsedMs)
                    put("fastestRoundMs", z.fastestRoundMs)
                    put("slowestRoundMs", z.slowestRoundMs)
                    put("totalRoundDurationMs", z.totalRoundDurationMs)
                    put("timedRoundsCount", z.timedRoundsCount)
                }
            )
        }
        root.put("zikrItems", zikrArr)

        val dailyArr = JSONArray()
        daily.forEach { d ->
            dailyArr.put(
                JSONObject().apply {
                    put("zikrId", d.zikrId)
                    put("dateKey", d.dateKey)
                    put("count", d.count)
                    put("rounds", d.rounds)
                    put("updatedAt", d.updatedAt)
                }
            )
        }
        root.put("dailyLogs", dailyArr)

        val hourlyArr = JSONArray()
        hourly.forEach { h ->
            hourlyArr.put(
                JSONObject().apply {
                    put("zikrId", h.zikrId)
                    put("dateKey", h.dateKey)
                    put("hour", h.hour)
                    put("count", h.count)
                }
            )
        }
        root.put("hourlyLogs", hourlyArr)

        root.toString(2)
    }

    /**
     * Imports a JSON backup into Room atomically.
     *
     * - replaceExisting = true  (Replace): Wipes current Zikr items, daily logs, and hourly logs,
     *   and restores the exact snapshot from the backup file with proper per-Zikr ID mapping.
     * - replaceExisting = false (Merge): Keeps all current Zikr items and logs intact, adds any
     *   missing Zikrs from the backup, combines daily & hourly logs by date/hour (taking the
     *   higher value on overlapping dates to avoid double-counting), and syncs each Zikr's total
     *   count & rounds with the combined daily history.
     */
    suspend fun importBackupJson(
        context: Context,
        rawJson: String,
        replaceExisting: Boolean
    ): ImportResult = withContext(Dispatchers.IO) {
        val root = JSONObject(rawJson)
        val zikrArr = root.optJSONArray("zikrItems") ?: JSONArray()
        val dailyArr = root.optJSONArray("dailyLogs") ?: JSONArray()
        val hourlyArr = root.optJSONArray("hourlyLogs") ?: JSONArray()

        val db = SheenDatabase.getInstance(context)
        val zikrDao = db.zikrDao()
        val dailyDao = db.dailyLogDao()
        val hourlyDao = db.hourlyLogDao()

        db.withTransaction {
            if (replaceExisting) {
                hourlyDao.deleteAll()
                dailyDao.deleteAll()
                zikrDao.deleteAll()
            }

            val existingByName = zikrDao.observeAll().first()
                .associateBy { it.name.trim().lowercase(Locale.ROOT) }
                .toMutableMap()

            val oldIdToNewId = mutableMapOf<Long, Long>()
            var nextSortOrder = (zikrDao.getMaxSortOrder() + 1).coerceAtLeast(0)
            var processedZikrCount = 0
            val mergedTargetZikrIds = mutableSetOf<Long>()

            for (i in 0 until zikrArr.length()) {
                val obj = zikrArr.optJSONObject(i) ?: continue
                val name = obj.optString("name", "").trim()
                if (name.isEmpty()) continue

                val oldId = obj.optLong("id", -1L)
                val target = obj.optInt("targetCount", 33).coerceAtLeast(1)
                val incomingCount = obj.optInt("currentCount", 0).coerceAtLeast(0)
                val incomingRounds = obj.optInt("completedRounds", 0).coerceAtLeast(0)
                val incomingFastest = obj.optLong("fastestRoundMs", 0L).coerceAtLeast(0L)
                val incomingSlowest = obj.optLong("slowestRoundMs", 0L).coerceAtLeast(0L)
                val incomingTotalDur = obj.optLong("totalRoundDurationMs", 0L).coerceAtLeast(0L)
                val incomingTimedCount = obj.optInt("timedRoundsCount", 0).coerceAtLeast(0)

                val key = name.lowercase(Locale.ROOT)
                val matched = existingByName[key]

                val newId = if (matched != null && !replaceExisting) {
                    val combinedFastest = when {
                        matched.fastestRoundMs > 0L && incomingFastest > 0L -> minOf(matched.fastestRoundMs, incomingFastest)
                        matched.fastestRoundMs > 0L -> matched.fastestRoundMs
                        else -> incomingFastest
                    }
                    val combinedSlowest = maxOf(matched.slowestRoundMs, incomingSlowest)
                    val updated = matched.copy(
                        currentCount = maxOf(matched.currentCount, incomingCount),
                        completedRounds = maxOf(matched.completedRounds, incomingRounds),
                        fastestRoundMs = combinedFastest,
                        slowestRoundMs = combinedSlowest,
                        totalRoundDurationMs = maxOf(matched.totalRoundDurationMs, incomingTotalDur),
                        timedRoundsCount = maxOf(matched.timedRoundsCount, incomingTimedCount),
                        updatedAt = System.currentTimeMillis()
                    )
                    zikrDao.update(updated)
                    existingByName[key] = updated
                    mergedTargetZikrIds.add(matched.id)
                    matched.id
                } else {
                    val sortOrder = if (replaceExisting) obj.optInt("sortOrder", i) else nextSortOrder++
                    val inserted = ZikrEntity(
                        id = 0L,
                        name = name,
                        targetCount = target,
                        currentCount = incomingCount,
                        completedRounds = incomingRounds,
                        sortOrder = sortOrder,
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = System.currentTimeMillis(),
                        currentRoundElapsedMs = obj.optLong("currentRoundElapsedMs", 0L).coerceAtLeast(0L),
                        fastestRoundMs = incomingFastest,
                        slowestRoundMs = incomingSlowest,
                        totalRoundDurationMs = incomingTotalDur,
                        timedRoundsCount = incomingTimedCount
                    )
                    val insertedId = zikrDao.insert(inserted)
                    existingByName[key] = inserted.copy(id = insertedId)
                    insertedId
                }

                if (oldId > 0L) {
                    oldIdToNewId[oldId] = newId
                }
                processedZikrCount++
            }

            val fallbackId = oldIdToNewId.values.firstOrNull()
                ?: zikrDao.observeAll().first().firstOrNull()?.id
                ?: 0L

            var dailyImported = 0
            for (i in 0 until dailyArr.length()) {
                val dObj = dailyArr.optJSONObject(i) ?: continue
                val dateKey = dObj.optString("dateKey", "").trim()
                if (dateKey.isBlank()) continue

                val oldZikrId = dObj.optLong("zikrId", -1L)
                val targetZikrId = oldIdToNewId[oldZikrId] ?: if (oldZikrId <= 0L) fallbackId else continue
                if (targetZikrId <= 0L) continue

                val incomingCount = dObj.optInt("count", 0).coerceAtLeast(0)
                val incomingRounds = dObj.optInt("rounds", 0).coerceAtLeast(0)
                val incomingUpdatedAt = dObj.optLong("updatedAt", System.currentTimeMillis())

                if (replaceExisting) {
                    dailyDao.upsert(
                        ZikrDailyLogEntity(
                            zikrId = targetZikrId,
                            dateKey = dateKey,
                            count = incomingCount,
                            rounds = incomingRounds,
                            updatedAt = incomingUpdatedAt
                        )
                    )
                } else {
                    val prev = dailyDao.getForDay(targetZikrId, dateKey)
                    dailyDao.upsert(
                        ZikrDailyLogEntity(
                            zikrId = targetZikrId,
                            dateKey = dateKey,
                            count = if (prev != null) maxOf(prev.count, incomingCount) else incomingCount,
                            rounds = if (prev != null) maxOf(prev.rounds, incomingRounds) else incomingRounds,
                            updatedAt = maxOf(prev?.updatedAt ?: 0L, incomingUpdatedAt)
                        )
                    )
                    mergedTargetZikrIds.add(targetZikrId)
                }
                dailyImported++
            }

            var hourlyImported = 0
            for (i in 0 until hourlyArr.length()) {
                val hObj = hourlyArr.optJSONObject(i) ?: continue
                val dateKey = hObj.optString("dateKey", "").trim()
                val hour = hObj.optInt("hour", -1)
                if (dateKey.isBlank() || hour !in 0..23) continue

                val oldZikrId = hObj.optLong("zikrId", -1L)
                val targetZikrId = oldIdToNewId[oldZikrId] ?: if (oldZikrId <= 0L) fallbackId else continue
                if (targetZikrId <= 0L) continue

                val incomingCount = hObj.optInt("count", 0).coerceAtLeast(0)
                if (replaceExisting) {
                    hourlyDao.upsert(
                        ZikrHourlyLogEntity(
                            zikrId = targetZikrId,
                            dateKey = dateKey,
                            hour = hour,
                            count = incomingCount
                        )
                    )
                } else {
                    val prev = hourlyDao.getForHour(targetZikrId, dateKey, hour)
                    hourlyDao.upsert(
                        ZikrHourlyLogEntity(
                            zikrId = targetZikrId,
                            dateKey = dateKey,
                            hour = hour,
                            count = if (prev != null) maxOf(prev.count, incomingCount) else incomingCount
                        )
                    )
                }
                hourlyImported++
            }

            // Keep merged Zikr totals synchronized with combined daily logs
            if (!replaceExisting && mergedTargetZikrIds.isNotEmpty()) {
                for (zId in mergedTargetZikrIds) {
                    val zikr = zikrDao.getById(zId) ?: continue
                    val logs = dailyDao.observeForZikr(zId).first()
                    val summedCount = logs.sumOf { it.count }
                    val summedRounds = logs.sumOf { it.rounds }
                    val syncedCount = maxOf(zikr.currentCount, summedCount)
                    val derivedRounds = if (zikr.targetCount > 0) syncedCount / zikr.targetCount else 0
                    val syncedRounds = maxOf(zikr.completedRounds, summedRounds, derivedRounds)
                    if (syncedCount != zikr.currentCount || syncedRounds != zikr.completedRounds) {
                        zikrDao.updateProgress(
                            id = zId,
                            currentCount = syncedCount,
                            completedRounds = syncedRounds,
                            updatedAt = System.currentTimeMillis()
                        )
                    }
                }
            }

            ImportResult(
                zikrCount = processedZikrCount,
                dailyLogsImported = dailyImported,
                hourlyLogsImported = hourlyImported
            )
        }
    }
}
