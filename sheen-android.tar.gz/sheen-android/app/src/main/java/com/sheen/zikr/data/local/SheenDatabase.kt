package com.sheen.zikr.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [ZikrEntity::class, ZikrDailyLogEntity::class, ZikrHourlyLogEntity::class],
    version = 3,
    exportSchema = false
)
abstract class SheenDatabase : RoomDatabase() {
    abstract fun zikrDao(): ZikrDao
    abstract fun dailyLogDao(): ZikrDailyLogDao
    abstract fun hourlyLogDao(): ZikrHourlyLogDao

    companion object {
        @Volatile
        private var INSTANCE: SheenDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `zikr_daily_logs` (
                        `zikrId` INTEGER NOT NULL,
                        `dateKey` TEXT NOT NULL,
                        `count` INTEGER NOT NULL,
                        `rounds` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`zikrId`, `dateKey`),
                        FOREIGN KEY(`zikrId`) REFERENCES `zikr_items`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_zikr_daily_logs_zikrId` ON `zikr_daily_logs` (`zikrId`)")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `zikr_hourly_logs` (
                        `zikrId` INTEGER NOT NULL,
                        `dateKey` TEXT NOT NULL,
                        `hour` INTEGER NOT NULL,
                        `count` INTEGER NOT NULL,
                        PRIMARY KEY(`zikrId`, `dateKey`, `hour`),
                        FOREIGN KEY(`zikrId`) REFERENCES `zikr_items`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_zikr_hourly_logs_zikrId_dateKey` ON `zikr_hourly_logs` (`zikrId`, `dateKey`)")
            }
        }

        fun getInstance(context: Context): SheenDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SheenDatabase::class.java,
                    "sheen_zikr.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
