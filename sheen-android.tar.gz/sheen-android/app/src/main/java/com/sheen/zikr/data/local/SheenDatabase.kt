package com.sheen.zikr.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ZikrEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SheenDatabase : RoomDatabase() {
    abstract fun zikrDao(): ZikrDao

    companion object {
        @Volatile
        private var INSTANCE: SheenDatabase? = null

        fun getInstance(context: Context): SheenDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SheenDatabase::class.java,
                    "sheen_zikr.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
