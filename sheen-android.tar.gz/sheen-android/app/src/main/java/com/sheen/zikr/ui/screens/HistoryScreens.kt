package com.sheen.zikr.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sheen.zikr.data.local.ZikrDailyLogEntity
import com.sheen.zikr.data.local.ZikrEntity
import com.sheen.zikr.data.local.ZikrHourlyLogEntity
import com.sheen.zikr.ui.components.formatDurationTimer
import com.sheen.zikr.ui.theme.LocalSheenColors
import com.sheen.zikr.ui.theme.SheenEditorialSerif
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale


private fun formatStreakDays(days: Int): String {
    val safe = days.coerceAtLeast(0)
    if (safe < 365) return "${safe}d"
    val years = safe / 365
    val remDays = safe % 365
    return "${years}y${remDays}d"
}

private data class LongestStreakRecord(
    val days: Int,
    val startDateKey: String?,
    val endDateKey: String?
)

private fun formatDateKey(year: Int, monthZeroBased: Int, day: Int): String =
    String.format(Locale.US, "%04d-%02d-%02d", year, monthZeroBased + 1, day)

private fun formatReadableDate(dateKey: String): String {
    return try {
        val inFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val outFmt = SimpleDateFormat("MMM d, yyyy", Locale.US)
        val parsed = inFmt.parse(dateKey) ?: return dateKey
        outFmt.format(parsed)
    } catch (_: Exception) {
        dateKey
    }
}

private fun stepDateKey(dateKey: String, dayDelta: Int): String {
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val parsed = sdf.parse(dateKey) ?: return dateKey
        val cal = Calendar.getInstance().apply {
            time = parsed
            add(Calendar.DAY_OF_YEAR, dayDelta)
        }
        sdf.format(cal.time)
    } catch (_: Exception) {
        dateKey
    }
}

private fun monthTitle(year: Int, monthZeroBased: Int): String {
    val cal = Calendar.getInstance().apply { set(year, monthZeroBased, 1) }
    return SimpleDateFormat("MMMM yyyy", Locale.US).format(cal.time)
}

private fun calculateRoundStreak(completedRoundDateKeys: Set<String>): Int {
    if (completedRoundDateKeys.isEmpty()) return 0
    val cal = Calendar.getInstance()
    val todayKey = formatDateKey(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
    if (todayKey !in completedRoundDateKeys) {
        cal.add(Calendar.DAY_OF_YEAR, -1)
    }
    var streak = 0
    while (true) {
        val key = formatDateKey(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
        if (key in completedRoundDateKeys) {
            streak++
            cal.add(Calendar.DAY_OF_YEAR, -1)
        } else {
            break
        }
    }
    return streak
}

private fun calculateLongestStreak(completedRoundDateKeys: Set<String>): LongestStreakRecord {
    if (completedRoundDateKeys.isEmpty()) {
        return LongestStreakRecord(days = 0, startDateKey = null, endDateKey = null)
    }
    val sortedKeys = completedRoundDateKeys.sorted()
    var bestDays = 1
    var bestStart = sortedKeys.first()
    var bestEnd = sortedKeys.first()

    var curDays = 1
    var curStart = sortedKeys.first()
    var prevKey = sortedKeys.first()

    for (i in 1 until sortedKeys.size) {
        val key = sortedKeys[i]
        if (stepDateKey(prevKey, 1) == key) {
            curDays++
        } else {
            curDays = 1
            curStart = key
        }
        if (curDays >= bestDays) {
            bestDays = curDays
            bestStart = curStart
            bestEnd = key
        }
        prevKey = key
    }
    return LongestStreakRecord(days = bestDays, startDateKey = bestStart, endDateKey = bestEnd)
}

@Composable
private fun StreakDetailsDialog(
    title: String,
    currentStreakDays: Int,
    longestRecord: LongestStreakRecord,
    onDismiss: () -> Unit
) {
    val brandColors = LocalSheenColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Rounded.EmojiEvents,
                contentDescription = null,
                tint = brandColors.gold,
                modifier = Modifier.size(28.dp)
            )
        },
        title = {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = SheenEditorialSerif,
                    fontWeight = FontWeight.SemiBold
                )
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = brandColors.dockBg,
                    border = BorderStroke(1.dp, brandColors.cardBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Current Streak",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = formatStreakDays(currentStreakDays),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = brandColors.gold.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, brandColors.gold.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Longest Streak",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = formatStreakDays(longestRecord.days),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = brandColors.gold
                            )
                        }
                        if (longestRecord.startDateKey != null && longestRecord.endDateKey != null) {
                            val startFormatted = formatReadableDate(longestRecord.startDateKey)
                            val endFormatted = formatReadableDate(longestRecord.endDateKey)
                            Text(
                                text = if (longestRecord.startDateKey == longestRecord.endDateKey) {
                                    startFormatted
                                } else {
                                    "$startFormatted – $endFormatted"
                                },
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Text(
                                text = "Complete at least 1 round in a day to start a streak",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = brandColors.gold)
            }
        }
    )
}

@Composable
private fun MonthCalendarCard(
    year: Int,
    monthZeroBased: Int,
    selectedDateKey: String,
    streakDates: Set<String>,
    countOnlyDates: Set<String>,
    onPrevMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onSelectDate: (String) -> Unit
) {
    val brandColors = LocalSheenColors.current
    val cal = remember(year, monthZeroBased) {
        Calendar.getInstance().apply { set(year, monthZeroBased, 1) }
    }
    val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 1
    val dayHeaders = listOf("S", "M", "T", "W", "T", "F", "S")

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, brandColors.cardBorder),
        tonalElevation = 1.dp
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onPrevMonth) {
                    Icon(Icons.Rounded.ChevronLeft, contentDescription = "Previous month")
                }
                Text(
                    text = monthTitle(year, monthZeroBased),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = SheenEditorialSerif,
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(onClick = onNextMonth) {
                    Icon(Icons.Rounded.ChevronRight, contentDescription = "Next month")
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                dayHeaders.forEach { d ->
                    Text(
                        text = d,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            val totalCells = firstDayOfWeek + daysInMonth
            val rows = (totalCells + 6) / 7
            for (r in 0 until rows) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                ) {
                    for (c in 0 until 7) {
                        val cellIndex = r * 7 + c
                        val dayNum = cellIndex - firstDayOfWeek + 1
                        if (dayNum in 1..daysInMonth) {
                            val key = formatDateKey(year, monthZeroBased, dayNum)
                            val isSelected = key == selectedDateKey
                            val isStreakDay = key in streakDates
                            val hasCountOnly = !isStreakDay && (key in countOnlyDates)
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            isSelected -> brandColors.gold
                                            isStreakDay -> brandColors.gold.copy(alpha = 0.14f)
                                            else -> MaterialTheme.colorScheme.surface
                                        }
                                    )
                                    .clickable { onSelectDate(key) },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = dayNum.toString(),
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = if (isSelected || isStreakDay) FontWeight.Bold else FontWeight.Normal
                                        ),
                                        color = if (isSelected) brandColors.deepBrand else MaterialTheme.colorScheme.onSurface
                                    )
                                    when {
                                        isStreakDay -> {
                                            Icon(
                                                imageVector = Icons.Rounded.LocalFireDepartment,
                                                contentDescription = "Round completed",
                                                tint = if (isSelected) brandColors.deepBrand else brandColors.gold,
                                                modifier = Modifier.size(11.dp)
                                            )
                                        }
                                        hasCountOnly -> {
                                            Box(
                                                modifier = Modifier
                                                    .size(4.dp)
                                                    .clip(CircleShape)
                                                    .background(
                                                        if (isSelected) brandColors.deepBrand
                                                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
                                                    )
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            Spacer(modifier = Modifier.weight(1f).height(42.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StreakBadge(
    streakDays: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val brandColors = LocalSheenColors.current
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(999.dp),
        color = brandColors.gold.copy(alpha = 0.16f),
        border = BorderStroke(1.dp, brandColors.gold.copy(alpha = 0.55f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.LocalFireDepartment,
                contentDescription = null,
                tint = brandColors.gold,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = formatStreakDays(streakDays),
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                color = brandColors.gold
            )
        }
    }
}

@Composable
fun ZikrHistoryScreen(
    zikr: ZikrEntity,
    observeDailyHistory: (Long) -> Flow<List<ZikrDailyLogEntity>>,
    observeHourly: (Long, String) -> Flow<List<ZikrHourlyLogEntity>>,
    onResetDayHistory: (Long, String) -> Unit,
    onResetHistory: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val brandColors = LocalSheenColors.current
    val today = remember { Calendar.getInstance() }
    var currentYear by remember { mutableIntStateOf(today.get(Calendar.YEAR)) }
    var currentMonth by remember { mutableIntStateOf(today.get(Calendar.MONTH)) }
    var selectedDateKey by remember {
        mutableStateOf(formatDateKey(today.get(Calendar.YEAR), today.get(Calendar.MONTH), today.get(Calendar.DAY_OF_MONTH)))
    }
    var resetTargetDateKey by remember { mutableStateOf(selectedDateKey) }
    var showResetOptions by remember { mutableStateOf(false) }
    var showCalendarPickerForReset by remember { mutableStateOf(false) }
    var showStreakPopup by remember { mutableStateOf(false) }

    val dailyLogs by remember(zikr.id) { observeDailyHistory(zikr.id) }
        .collectAsStateWithLifecycle(initialValue = emptyList())
    val hourlyLogs by remember(zikr.id, selectedDateKey) { observeHourly(zikr.id, selectedDateKey) }
        .collectAsStateWithLifecycle(initialValue = emptyList())

    val streakDates = remember(dailyLogs) { dailyLogs.filter { it.rounds > 0 }.map { it.dateKey }.toSet() }
    val countOnlyDates = remember(dailyLogs) { dailyLogs.filter { it.count > 0 && it.rounds == 0 }.map { it.dateKey }.toSet() }
    var showWholeMonth by remember { mutableStateOf(false) }
    val streakDays = remember(streakDates) { calculateRoundStreak(streakDates) }
    val longestRecord = remember(streakDates) { calculateLongestStreak(streakDates) }
    val dayLog = remember(dailyLogs, selectedDateKey) { dailyLogs.firstOrNull { it.dateKey == selectedDateKey } }

    val activeMonthPrefix = String.format(Locale.US, "%04d-%02d", currentYear, currentMonth + 1)
    val monthLogs = remember(dailyLogs, activeMonthPrefix) {
        dailyLogs.filter { it.dateKey.startsWith(activeMonthPrefix) }
    }
    val monthTotalCount = remember(monthLogs) { monthLogs.sumOf { it.count } }
    val monthTotalRounds = remember(monthLogs) { monthLogs.sumOf { it.rounds } }

    val grandTotalCount = remember(dailyLogs, zikr.currentCount) {
        maxOf(zikr.currentCount, dailyLogs.sumOf { it.count })
    }
    val grandTotalRounds = remember(dailyLogs, zikr.rounds) {
        maxOf(zikr.rounds, dailyLogs.sumOf { it.rounds })
    }

    val hourlyMap = remember(hourlyLogs) { hourlyLogs.associate { it.hour to it.count } }
    val maxHourCount = remember(hourlyMap) { (hourlyMap.values.maxOrNull() ?: 1).coerceAtLeast(1) }

    val hourScrollState = rememberScrollState()
    val currentHourNow = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }

    LaunchedEffect(zikr.id, selectedDateKey) {
        val targetScroll = ((currentHourNow - 2).coerceAtLeast(0)) * 126
        hourScrollState.animateScrollTo(targetScroll)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        MonthCalendarCard(
            year = currentYear,
            monthZeroBased = currentMonth,
            selectedDateKey = selectedDateKey,
            streakDates = streakDates,
            countOnlyDates = countOnlyDates,
            onPrevMonth = {
                if (currentMonth == 0) {
                    currentMonth = 11; currentYear--
                } else currentMonth--
            },
            onNextMonth = {
                if (currentMonth == 11) {
                    currentMonth = 0; currentYear++
                } else currentMonth++
            },
            onSelectDate = {
                selectedDateKey = it
                resetTargetDateKey = it
                showWholeMonth = false
            }
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val todayDateKey = remember {
                formatDateKey(today.get(Calendar.YEAR), today.get(Calendar.MONTH), today.get(Calendar.DAY_OF_MONTH))
            }
            listOf(false to "Selected Day", true to "Whole Month").forEach { (isMonth, label) ->
                val selected = showWholeMonth == isMonth
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            showWholeMonth = isMonth
                            if (isMonth) {
                                currentYear = today.get(Calendar.YEAR)
                                currentMonth = today.get(Calendar.MONTH)
                                selectedDateKey = todayDateKey
                            }
                        },
                    shape = RoundedCornerShape(12.dp),
                    color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(
                        width = if (selected) 1.4.dp else 1.dp,
                        color = if (selected) brandColors.gold else brandColors.cardBorder
                    )
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                            ),
                            color = if (selected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, brandColors.cardBorder),
            tonalElevation = 1.dp
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (showWholeMonth) monthTitle(currentYear, currentMonth) else selectedDateKey,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    StreakBadge(
                        streakDays = streakDays,
                        onClick = { showStreakPopup = true }
                    )
                }

                Text(
                    text = "${if (showWholeMonth) monthTotalCount else (dayLog?.count ?: 0)}",
                    style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
                    color = brandColors.gold
                )

                Text(
                    text = "Rounds: ${if (showWholeMonth) monthTotalRounds else (dayLog?.rounds ?: 0)}",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.onSurface
                )

                val chartBarActiveColor = Color(0xFF38B2AC)
                val chartValueTextColor = MaterialTheme.colorScheme.onSurface

                if (showWholeMonth) {
                    val mCal = remember(currentYear, currentMonth) {
                        Calendar.getInstance().apply { set(currentYear, currentMonth, 1) }
                    }
                    val totalDaysInMonth = mCal.getActualMaximum(Calendar.DAY_OF_MONTH)
                    val dayCountMap = remember(monthLogs) {
                        monthLogs.associate { it.dateKey to it.count }
                    }
                    val maxMonthDayCount = remember(dayCountMap) {
                        (dayCountMap.values.maxOrNull() ?: 1).coerceAtLeast(1)
                    }
                    val monthScrollState = rememberScrollState()
                    val highlightDayNum = remember(selectedDateKey, currentYear, currentMonth) {
                        val prefix = String.format(Locale.US, "%04d-%02d-", currentYear, currentMonth + 1)
                        if (selectedDateKey.startsWith(prefix)) {
                            selectedDateKey.substringAfterLast("-").toIntOrNull() ?: 1
                        } else {
                            1
                        }
                    }
                    LaunchedEffect(showWholeMonth, currentYear, currentMonth, highlightDayNum) {
                        if (showWholeMonth) {
                            val scrollTarget = ((highlightDayNum - 3).coerceAtLeast(0)) * 126
                            monthScrollState.animateScrollTo(scrollTarget)
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(monthScrollState)
                            .height(164.dp),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (d in 1..totalDaysInMonth) {
                            val dKey = formatDateKey(currentYear, currentMonth, d)
                            val count = dayCountMap[dKey] ?: 0
                            val fraction = if (count > 0) {
                                (count.toFloat() / maxMonthDayCount.toFloat()).coerceIn(0.18f, 1f)
                            } else {
                                0f
                            }
                            val barHeightDp = if (count > 0) (76f * fraction).coerceAtLeast(16f) else 3f
                            Column(
                                modifier = Modifier.width(34.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Bottom
                            ) {
                                if (count > 0) {
                                    Text(
                                        text = count.toString(),
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = chartValueTextColor,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Visible,
                                        modifier = Modifier.graphicsLayer { rotationZ = -90f }
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                }
                                Box(
                                    modifier = Modifier
                                        .width(18.dp)
                                        .height(barHeightDp.dp)
                                        .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                        .background(if (count > 0) chartBarActiveColor else brandColors.trackColor)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = String.format(Locale.US, "%02d", d),
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontSize = 10.sp,
                                        fontWeight = if (dKey == selectedDateKey) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    color = if (dKey == selectedDateKey) chartBarActiveColor else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(hourScrollState)
                            .height(164.dp),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (h in 0..23) {
                            val count = hourlyMap[h] ?: 0
                            val fraction = if (count > 0) {
                                (count.toFloat() / maxHourCount.toFloat()).coerceIn(0.18f, 1f)
                            } else {
                                0f
                            }
                            val barHeightDp = if (count > 0) (76f * fraction).coerceAtLeast(16f) else 3f
                            Column(
                                modifier = Modifier.width(34.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Bottom
                            ) {
                                if (count > 0) {
                                    Text(
                                        text = count.toString(),
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = chartValueTextColor,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Visible,
                                        modifier = Modifier.graphicsLayer { rotationZ = -90f }
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                }
                                Box(
                                    modifier = Modifier
                                        .width(18.dp)
                                        .height(barHeightDp.dp)
                                        .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                        .background(if (count > 0) chartBarActiveColor else brandColors.trackColor)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = String.format(Locale.US, "%02d", h),
                                    style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, brandColors.cardBorder),
            tonalElevation = 1.dp
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Round Timings",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = SheenEditorialSerif,
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = brandColors.gold
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf(
                        "Fastest" to if (zikr.timedRoundsCount > 0) formatDurationTimer(zikr.fastestRoundMs) else "—",
                        "Average" to if (zikr.timedRoundsCount > 0) formatDurationTimer(zikr.averageRoundMs) else "—",
                        "Slowest" to if (zikr.timedRoundsCount > 0) formatDurationTimer(zikr.slowestRoundMs) else "—"
                    ).forEach { (label, value) ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = value,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        val grandDigits = grandTotalCount.toString().length
        val grandCountFontSize = when {
            grandDigits >= 9 -> 20.sp
            grandDigits >= 7 -> 24.sp
            else -> 30.sp
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, brandColors.cardBorder),
            tonalElevation = 1.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Grand Total",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontFamily = SheenEditorialSerif,
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = brandColors.gold,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "$grandTotalCount",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontSize = grandCountFontSize,
                            fontWeight = FontWeight.Bold
                        ),
                        color = brandColors.gold,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Rounds: $grandTotalRounds",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        OutlinedButton(
            onClick = {
                resetTargetDateKey = selectedDateKey
                showCalendarPickerForReset = false
                showResetOptions = true
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(Icons.Rounded.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Reset Counter & History")
        }

        Spacer(modifier = Modifier.height(12.dp))
    }

    if (showStreakPopup) {
        StreakDetailsDialog(
            title = zikr.name,
            currentStreakDays = streakDays,
            longestRecord = longestRecord,
            onDismiss = { showStreakPopup = false }
        )
    }

    if (showResetOptions) {
        AlertDialog(
            onDismissRequest = { showResetOptions = false },
            title = { Text("Reset Counter & History") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Step across dates with arrows or tap the calendar icon to pick a specific date to reset.",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = brandColors.dockBg,
                        border = BorderStroke(1.dp, brandColors.cardBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconButton(
                                onClick = { resetTargetDateKey = stepDateKey(resetTargetDateKey, -1) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Rounded.ChevronLeft, contentDescription = "Previous day")
                            }

                            Text(
                                text = resetTargetDateKey,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { resetTargetDateKey = stepDateKey(resetTargetDateKey, 1) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Rounded.ChevronRight, contentDescription = "Next day")
                                }
                                Surface(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .clickable { showCalendarPickerForReset = !showCalendarPickerForReset },
                                    shape = CircleShape,
                                    color = if (showCalendarPickerForReset) brandColors.gold else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, brandColors.gold)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Rounded.CalendarMonth,
                                            contentDescription = "Pick date from calendar",
                                            tint = if (showCalendarPickerForReset) brandColors.deepBrand else brandColors.gold,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (showCalendarPickerForReset) {
                        MonthCalendarCard(
                            year = currentYear,
                            monthZeroBased = currentMonth,
                            selectedDateKey = resetTargetDateKey,
                            streakDates = streakDates,
                            countOnlyDates = countOnlyDates,
                            onPrevMonth = {
                                if (currentMonth == 0) {
                                    currentMonth = 11; currentYear--
                                } else currentMonth--
                            },
                            onNextMonth = {
                                if (currentMonth == 11) {
                                    currentMonth = 0; currentYear++
                                } else currentMonth++
                            },
                            onSelectDate = { resetTargetDateKey = it }
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            showResetOptions = false
                            onResetDayHistory(zikr.id, resetTargetDateKey)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Reset $resetTargetDateKey")
                    }

                    Button(
                        onClick = {
                            showResetOptions = false
                            onResetHistory(zikr.id)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = MaterialTheme.colorScheme.onError
                        )
                    ) {
                        Text("Reset Complete Overall")
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showResetOptions = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun OverallHistoryScreen(
    zikrList: List<ZikrEntity>,
    allDailyLogsFlow: Flow<List<ZikrDailyLogEntity>>,
    onOpenZikrHistory: (ZikrEntity) -> Unit,
    onClearAllHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val brandColors = LocalSheenColors.current
    val today = remember { Calendar.getInstance() }
    var currentYear by remember { mutableIntStateOf(today.get(Calendar.YEAR)) }
    var currentMonth by remember { mutableIntStateOf(today.get(Calendar.MONTH)) }
    var selectedDateKey by remember {
        mutableStateOf(formatDateKey(today.get(Calendar.YEAR), today.get(Calendar.MONTH), today.get(Calendar.DAY_OF_MONTH)))
    }
    var showWholeMonth by remember { mutableStateOf(false) }
    var showResetConfirm by remember { mutableStateOf(false) }
    var showStreakPopup by remember { mutableStateOf(false) }

    val allLogs by allDailyLogsFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    val streakDates = remember(allLogs) {
        allLogs.groupBy { it.dateKey }
            .filterValues { logs -> logs.sumOf { it.rounds } > 0 }
            .keys
    }
    val countOnlyDates = remember(allLogs, streakDates) {
        allLogs.groupBy { it.dateKey }
            .filter { (k, logs) -> k !in streakDates && logs.sumOf { it.count } > 0 }
            .keys
    }
    val streakDays = remember(streakDates) { calculateRoundStreak(streakDates) }
    val longestRecord = remember(streakDates) { calculateLongestStreak(streakDates) }

    val monthPrefix = String.format(Locale.US, "%04d-%02d", currentYear, currentMonth + 1)
    val filteredLogs = remember(allLogs, selectedDateKey, showWholeMonth, monthPrefix) {
        if (showWholeMonth) {
            allLogs.filter { it.dateKey.startsWith(monthPrefix) }
        } else {
            allLogs.filter { it.dateKey == selectedDateKey }
        }
    }

    val zikrById = remember(zikrList) { zikrList.associateBy { it.id } }
    val countsByZikr = remember(filteredLogs, zikrList) {
        val grouped = filteredLogs.groupBy { it.zikrId }.mapValues { (_, list) -> list.sumOf { it.count } }
        zikrList.map { z -> z.id to (grouped[z.id] ?: 0) }.sortedByDescending { it.second }
    }
    val totalCount = remember(countsByZikr) { countsByZikr.sumOf { it.second } }
    val totalRounds = remember(filteredLogs) { filteredLogs.sumOf { it.rounds } }
    val maxCount = remember(countsByZikr) { (countsByZikr.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        MonthCalendarCard(
            year = currentYear,
            monthZeroBased = currentMonth,
            selectedDateKey = selectedDateKey,
            streakDates = streakDates,
            countOnlyDates = countOnlyDates,
            onPrevMonth = {
                if (currentMonth == 0) {
                    currentMonth = 11; currentYear--
                } else currentMonth--
            },
            onNextMonth = {
                if (currentMonth == 11) {
                    currentMonth = 0; currentYear++
                } else currentMonth++
            },
            onSelectDate = {
                selectedDateKey = it
                showWholeMonth = false
            }
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(false to "Selected Day", true to "Whole Month").forEach { (isMonth, label) ->
                val selected = showWholeMonth == isMonth
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { showWholeMonth = isMonth },
                    shape = RoundedCornerShape(12.dp),
                    color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(
                        width = if (selected) 1.4.dp else 1.dp,
                        color = if (selected) brandColors.gold else brandColors.cardBorder
                    )
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                            ),
                            color = if (selected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, brandColors.cardBorder),
            tonalElevation = 1.dp
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (showWholeMonth) monthTitle(currentYear, currentMonth) else selectedDateKey,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    StreakBadge(
                        streakDays = streakDays,
                        onClick = { showStreakPopup = true }
                    )
                }

                Text(
                    text = "$totalCount",
                    style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
                    color = brandColors.gold
                )

                Text(
                    text = "Rounds: $totalRounds",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (countsByZikr.isEmpty()) {
                    Text(
                        text = "No Zikr items yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .height(148.dp),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        countsByZikr.forEach { (id, count) ->
                            val zikrObj = zikrById[id]
                            val label = zikrObj?.name ?: "Zikr"
                            val fraction = (count.toFloat() / maxCount.toFloat()).coerceIn(0f, 1f)
                            val barHeightDp = if (count > 0) (86f * fraction).coerceAtLeast(10f) else 4f
                            Column(
                                modifier = Modifier
                                    .width(68.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        if (zikrObj != null) onOpenZikrHistory(zikrObj)
                                    }
                                    .padding(vertical = 2.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Bottom
                            ) {
                                if (count > 0) {
                                    Text(
                                        text = count.toString(),
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Visible,
                                        modifier = Modifier.graphicsLayer { rotationZ = -90f }
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                }
                                Box(
                                    modifier = Modifier
                                        .width(26.dp)
                                        .height(barHeightDp.dp)
                                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                        .background(if (count > 0) Color(0xFF38B2AC) else brandColors.trackColor)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }

        OutlinedButton(
            onClick = { showResetConfirm = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(Icons.Rounded.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Reset All History")
        }

        Spacer(modifier = Modifier.height(12.dp))
    }

    if (showStreakPopup) {
        StreakDetailsDialog(
            title = "Overall Streak",
            currentStreakDays = streakDays,
            longestRecord = longestRecord,
            onDismiss = { showStreakPopup = false }
        )
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("Reset All History?") },
            text = { Text("Clear all recorded daily and hourly history across every Zikr?") },
            confirmButton = {
                Button(
                    onClick = {
                        showResetConfirm = false
                        onClearAllHistory()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    )
                ) { Text("Reset All") }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) { Text("Cancel") }
            }
        )
    }
}
