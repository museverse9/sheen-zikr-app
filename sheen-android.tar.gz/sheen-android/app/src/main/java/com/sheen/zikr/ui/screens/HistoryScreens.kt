package com.sheen.zikr.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sheen.zikr.data.local.ZikrDailyLogEntity
import com.sheen.zikr.data.local.ZikrEntity
import com.sheen.zikr.data.local.ZikrHourlyLogEntity
import com.sheen.zikr.ui.components.formatDurationTimer
import com.sheen.zikr.ui.theme.LocalSheenColors
import com.sheen.zikr.ui.theme.SheenEditorialSerif
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private fun formatDateKey(year: Int, monthZeroBased: Int, day: Int): String =
    String.format(Locale.US, "%04d-%02d-%02d", year, monthZeroBased + 1, day)

private fun monthTitle(year: Int, monthZeroBased: Int): String {
    val cal = Calendar.getInstance().apply { set(year, monthZeroBased, 1) }
    return SimpleDateFormat("MMMM yyyy", Locale.US).format(cal.time)
}

private fun calculateRoundStreak(completedRoundDateKeys: Set<String>): Int {
    if (completedRoundDateKeys.isEmpty()) return 0
    val cal = Calendar.getInstance()
    val todayKey = formatDateKey(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
    if (todayKey !in completedRoundDateKeys) {
        cal.add(Calendar.DAY_OF_YEAR, -1)
    }
    var streak = 0
    while (true) {
        val key = formatDateKey(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
        if (key in completedRoundDateKeys) {
            streak++
            cal.add(Calendar.DAY_OF_YEAR, -1)
        } else {
            break
        }
    }
    return streak
}

@Composable
private fun MonthCalendarCard(
    year: Int,
    monthZeroBased: Int,
    selectedDateKey: String,
    streakDates: Set<String>,
    countOnlyDates: Set<String>,
    onPrevMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onSelectDate: (String) -> Unit
) {
    val brandColors = LocalSheenColors.current
    val cal = remember(year, monthZeroBased) {
        Calendar.getInstance().apply { set(year, monthZeroBased, 1) }
    }
    val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 1
    val dayHeaders = listOf("S", "M", "T", "W", "T", "F", "S")

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, brandColors.cardBorder),
        tonalElevation = 1.dp
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onPrevMonth) {
                    Icon(Icons.Rounded.ChevronLeft, contentDescription = "Previous month")
                }
                Text(
                    text = monthTitle(year, monthZeroBased),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = SheenEditorialSerif,
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(onClick = onNextMonth) {
                    Icon(Icons.Rounded.ChevronRight, contentDescription = "Next month")
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                dayHeaders.forEach { d ->
                    Text(
                        text = d,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            val totalCells = firstDayOfWeek + daysInMonth
            val rows = (totalCells + 6) / 7
            for (r in 0 until rows) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                ) {
                    for (c in 0 until 7) {
                        val cellIndex = r * 7 + c
                        val dayNum = cellIndex - firstDayOfWeek + 1
                        if (dayNum in 1..daysInMonth) {
                            val key = formatDateKey(year, monthZeroBased, dayNum)
                            val isSelected = key == selectedDateKey
                            val isStreakDay = key in streakDates
                            val hasCountOnly = !isStreakDay && (key in countOnlyDates)
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            isSelected -> brandColors.gold
                                            isStreakDay -> brandColors.gold.copy(alpha = 0.14f)
                                            else -> MaterialTheme.colorScheme.surface
                                        }
                                    )
                                    .clickable { onSelectDate(key) },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = dayNum.toString(),
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = if (isSelected || isStreakDay) FontWeight.Bold else FontWeight.Normal
                                        ),
                                        color = if (isSelected) brandColors.deepBrand else MaterialTheme.colorScheme.onSurface
                                    )
                                    when {
                                        isStreakDay -> {
                                            Icon(
                                                imageVector = Icons.Rounded.LocalFireDepartment,
                                                contentDescription = "Round completed",
                                                tint = if (isSelected) brandColors.deepBrand else brandColors.gold,
                                                modifier = Modifier.size(11.dp)
                                            )
                                        }
                                        hasCountOnly -> {
                                            Box(
                                                modifier = Modifier
                                                    .size(4.dp)
                                                    .clip(CircleShape)
                                                    .background(
                                                        if (isSelected) brandColors.deepBrand
                                                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
                                                    )
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            Spacer(modifier = Modifier.weight(1f).height(42.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StreakBadge(streakDays: Int, modifier: Modifier = Modifier) {
    val brandColors = LocalSheenColors.current
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(999.dp),
        color = brandColors.gold.copy(alpha = 0.16f),
        border = BorderStroke(1.dp, brandColors.gold.copy(alpha = 0.55f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.LocalFireDepartment,
                contentDescription = "Streak",
                tint = brandColors.gold,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = "${streakDays}d Streak",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                color = brandColors.gold
            )
        }
    }
}

@Composable
fun ZikrHistoryScreen(
    zikr: ZikrEntity,
    observeDailyHistory: (Long) -> Flow<List<ZikrDailyLogEntity>>,
    observeHourly: (Long, String) -> Flow<List<ZikrHourlyLogEntity>>,
    onResetDayHistory: (Long, String) -> Unit,
    onResetHistory: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val brandColors = LocalSheenColors.current
    val today = remember { Calendar.getInstance() }
    var currentYear by remember { mutableIntStateOf(today.get(Calendar.YEAR)) }
    var currentMonth by remember { mutableIntStateOf(today.get(Calendar.MONTH)) }
    var selectedDateKey by remember {
        mutableStateOf(formatDateKey(today.get(Calendar.YEAR), today.get(Calendar.MONTH), today.get(Calendar.DAY_OF_MONTH)))
    }
    var showResetOptions by remember { mutableStateOf(false) }

    val dailyLogs by remember(zikr.id) { observeDailyHistory(zikr.id) }
        .collectAsStateWithLifecycle(initialValue = emptyList())
    val hourlyLogs by remember(zikr.id, selectedDateKey) { observeHourly(zikr.id, selectedDateKey) }
        .collectAsStateWithLifecycle(initialValue = emptyList())

    val streakDates = remember(dailyLogs) { dailyLogs.filter { it.rounds > 0 }.map { it.dateKey }.toSet() }
    val countOnlyDates = remember(dailyLogs) { dailyLogs.filter { it.count > 0 && it.rounds == 0 }.map { it.dateKey }.toSet() }
    val streakDays = remember(streakDates) { calculateRoundStreak(streakDates) }
    val dayLog = remember(dailyLogs, selectedDateKey) { dailyLogs.firstOrNull { it.dateKey == selectedDateKey } }

    val hourlyMap = remember(hourlyLogs) { hourlyLogs.associate { it.hour to it.count } }
    val maxHourCount = remember(hourlyMap) { (hourlyMap.values.maxOrNull() ?: 1).coerceAtLeast(1) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        MonthCalendarCard(
            year = currentYear,
            monthZeroBased = currentMonth,
            selectedDateKey = selectedDateKey,
            streakDates = streakDates,
            countOnlyDates = countOnlyDates,
            onPrevMonth = {
                if (currentMonth == 0) {
                    currentMonth = 11; currentYear--
                } else currentMonth--
            },
            onNextMonth = {
                if (currentMonth == 11) {
                    currentMonth = 0; currentYear++
                } else currentMonth++
            },
            onSelectDate = { selectedDateKey = it }
        )

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, brandColors.cardBorder),
            tonalElevation = 1.dp
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = selectedDateKey,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    StreakBadge(streakDays = streakDays)
                }

                Text(
                    text = "${dayLog?.count ?: 0}",
                    style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
                    color = brandColors.gold
                )

                Text(
                    text = "Rounds: ${dayLog?.rounds ?: 0}",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.onSurface
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .height(176.dp),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (h in 0..23) {
                        val count = hourlyMap[h] ?: 0
                        val fraction = if (count > 0) {
                            (count.toFloat() / maxHourCount.toFloat()).coerceIn(0.14f, 1f)
                        } else {
                            0f
                        }
                        Column(
                            modifier = Modifier.width(34.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Bottom
                        ) {
                            Text(
                                text = if (count > 0) count.toString() else "",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                color = brandColors.gold,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Visible,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .height(114.dp)
                                    .fillMaxWidth(),
                                contentAlignment = Alignment.BottomCenter
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(18.dp)
                                        .height(if (count > 0) (108f * fraction).dp.coerceAtLeast(14.dp) else 3.dp)
                                        .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                        .background(if (count > 0) brandColors.gold else brandColors.trackColor)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = String.format(Locale.US, "%02d", h),
                                style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, brandColors.cardBorder),
            tonalElevation = 1.dp
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Round Timings",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = SheenEditorialSerif,
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = brandColors.gold
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf(
                        "Fastest" to if (zikr.timedRoundsCount > 0) formatDurationTimer(zikr.fastestRoundMs) else "—",
                        "Average" to if (zikr.timedRoundsCount > 0) formatDurationTimer(zikr.averageRoundMs) else "—",
                        "Slowest" to if (zikr.timedRoundsCount > 0) formatDurationTimer(zikr.slowestRoundMs) else "—"
                    ).forEach { (label, value) ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = value,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        OutlinedButton(
            onClick = { showResetOptions = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(Icons.Rounded.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Reset Counter & History")
        }

        Spacer(modifier = Modifier.height(12.dp))
    }

    if (showResetOptions) {
        AlertDialog(
            onDismissRequest = { showResetOptions = false },
            title = { Text("Reset Counter & History") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Choose whether to reset only $selectedDateKey or clear complete overall history and counter for \"${zikr.name}\".",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedButton(
                        onClick = {
                            showResetOptions = false
                            onResetDayHistory(zikr.id, selectedDateKey)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Reset $selectedDateKey Only")
                    }
                    Button(
                        onClick = {
                            showResetOptions = false
                            onResetHistory(zikr.id)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = MaterialTheme.colorScheme.onError
                        )
                    ) {
                        Text("Reset Complete Overall")
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showResetOptions = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun OverallHistoryScreen(
    zikrList: List<ZikrEntity>,
    allDailyLogsFlow: Flow<List<ZikrDailyLogEntity>>,
    onOpenZikrHistory: (ZikrEntity) -> Unit,
    onClearAllHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val brandColors = LocalSheenColors.current
    val today = remember { Calendar.getInstance() }
    var currentYear by remember { mutableIntStateOf(today.get(Calendar.YEAR)) }
    var currentMonth by remember { mutableIntStateOf(today.get(Calendar.MONTH)) }
    var selectedDateKey by remember {
        mutableStateOf(formatDateKey(today.get(Calendar.YEAR), today.get(Calendar.MONTH), today.get(Calendar.DAY_OF_MONTH)))
    }
    var showWholeMonth by remember { mutableStateOf(false) }
    var showResetConfirm by remember { mutableStateOf(false) }

    val allLogs by allDailyLogsFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    val streakDates = remember(allLogs) {
        allLogs.groupBy { it.dateKey }
            .filterValues { logs -> logs.sumOf { it.rounds } > 0 }
            .keys
    }
    val countOnlyDates = remember(allLogs, streakDates) {
        allLogs.groupBy { it.dateKey }
            .filter { (k, logs) -> k !in streakDates && logs.sumOf { it.count } > 0 }
            .keys
    }
    val streakDays = remember(streakDates) { calculateRoundStreak(streakDates) }

    val monthPrefix = String.format(Locale.US, "%04d-%02d", currentYear, currentMonth + 1)
    val filteredLogs = remember(allLogs, selectedDateKey, showWholeMonth, monthPrefix) {
        if (showWholeMonth) {
            allLogs.filter { it.dateKey.startsWith(monthPrefix) }
        } else {
            allLogs.filter { it.dateKey == selectedDateKey }
        }
    }

    val zikrById = remember(zikrList) { zikrList.associateBy { it.id } }
    val countsByZikr = remember(filteredLogs, zikrList) {
        val grouped = filteredLogs.groupBy { it.zikrId }.mapValues { (_, list) -> list.sumOf { it.count } }
        zikrList.map { z -> z.id to (grouped[z.id] ?: 0) }.sortedByDescending { it.second }
    }
    val totalCount = remember(countsByZikr) { countsByZikr.sumOf { it.second } }
    val totalRounds = remember(filteredLogs) { filteredLogs.sumOf { it.rounds } }
    val maxCount = remember(countsByZikr) { (countsByZikr.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        MonthCalendarCard(
            year = currentYear,
            monthZeroBased = currentMonth,
            selectedDateKey = selectedDateKey,
            streakDates = streakDates,
            countOnlyDates = countOnlyDates,
            onPrevMonth = {
                if (currentMonth == 0) {
                    currentMonth = 11; currentYear--
                } else currentMonth--
            },
            onNextMonth = {
                if (currentMonth == 11) {
                    currentMonth = 0; currentYear++
                } else currentMonth++
            },
            onSelectDate = {
                selectedDateKey = it
                showWholeMonth = false
            }
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(false to "Selected Day", true to "Whole Month").forEach { (isMonth, label) ->
                val selected = showWholeMonth == isMonth
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { showWholeMonth = isMonth },
                    shape = RoundedCornerShape(12.dp),
                    color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(
                        width = if (selected) 1.4.dp else 1.dp,
                        color = if (selected) brandColors.gold else brandColors.cardBorder
                    )
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                            ),
                            color = if (selected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, brandColors.cardBorder),
            tonalElevation = 1.dp
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (showWholeMonth) monthTitle(currentYear, currentMonth) else selectedDateKey,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    StreakBadge(streakDays = streakDays)
                }

                Text(
                    text = "$totalCount",
                    style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
                    color = brandColors.gold
                )

                Text(
                    text = "Rounds: $totalRounds",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (countsByZikr.isEmpty()) {
                    Text(
                        text = "No Zikr items yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .height(172.dp),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        countsByZikr.forEach { (id, count) ->
                            val zikrObj = zikrById[id]
                            val label = zikrObj?.name ?: "Zikr"
                            val fraction = (count.toFloat() / maxCount.toFloat()).coerceIn(0f, 1f)
                            Column(
                                modifier = Modifier
                                    .width(68.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        if (zikrObj != null) onOpenZikrHistory(zikrObj)
                                    }
                                    .padding(vertical = 2.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Bottom
                            ) {
                                Text(
                                    text = if (count > 0) count.toString() else "",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = brandColors.gold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .height(110.dp)
                                        .fillMaxWidth(),
                                    contentAlignment = Alignment.BottomCenter
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .width(26.dp)
                                            .height((104f * fraction).dp.coerceAtLeast(if (count > 0) 8.dp else 4.dp))
                                            .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                            .background(if (count > 0) brandColors.gold else brandColors.trackColor)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }

        OutlinedButton(
            onClick = { showResetConfirm = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(Icons.Rounded.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Reset All History")
        }

        Spacer(modifier = Modifier.height(12.dp))
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("Reset All History?") },
            text = { Text("Clear all recorded daily and hourly history across every Zikr?") },
            confirmButton = {
                Button(
                    onClick = {
                        showResetConfirm = false
                        onClearAllHistory()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    )
                ) { Text("Reset All") }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) { Text("Cancel") }
            }
        )
    }
}
