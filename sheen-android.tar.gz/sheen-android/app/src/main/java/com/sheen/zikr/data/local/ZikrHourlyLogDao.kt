package com.sheen.zikr.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ZikrHourlyLogDao {
    @Query("SELECT * FROM zikr_hourly_logs ORDER BY dateKey DESC, hour ASC")
    suspend fun getAll(): List<ZikrHourlyLogEntity>

    @Query("SELECT * FROM zikr_hourly_logs WHERE zikrId = :zikrId AND dateKey = :dateKey ORDER BY hour ASC")
    fun observeForZikrDay(zikrId: Long, dateKey: String): Flow<List<ZikrHourlyLogEntity>>

    @Query("SELECT * FROM zikr_hourly_logs WHERE zikrId = :zikrId AND dateKey = :dateKey AND hour = :hour LIMIT 1")
    suspend fun getForHour(zikrId: Long, dateKey: String, hour: Int): ZikrHourlyLogEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(log: ZikrHourlyLogEntity)

    @Query("DELETE FROM zikr_hourly_logs WHERE zikrId = :zikrId AND dateKey = :dateKey")
    suspend fun deleteForZikrDay(zikrId: Long, dateKey: String)

    @Query("DELETE FROM zikr_hourly_logs WHERE zikrId = :zikrId")
    suspend fun deleteForZikr(zikrId: Long)

    @Query("DELETE FROM zikr_hourly_logs")
    suspend fun deleteAll()
}
