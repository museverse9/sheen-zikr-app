package com.sheen.zikr

import android.app.Application
import com.sheen.zikr.audio.HapticManager
import com.sheen.zikr.audio.SoundManager
import com.sheen.zikr.data.local.SheenDatabase
import com.sheen.zikr.data.local.ZikrRepository
import com.sheen.zikr.data.preferences.UserPreferencesRepository

class SheenApplication : Application() {
    val database: SheenDatabase by lazy { SheenDatabase.getInstance(this) }
    val zikrRepository: ZikrRepository by lazy { ZikrRepository(database.zikrDao(), database.dailyLogDao()) }
    val preferencesRepository: UserPreferencesRepository by lazy { UserPreferencesRepository(this) }
    val soundManager: SoundManager by lazy { SoundManager(this) }
    val hapticManager: HapticManager by lazy { HapticManager(this) }

    override fun onTerminate() {
        super.onTerminate()
        soundManager.release()
    }
}
