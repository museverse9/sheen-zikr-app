package com.sheen.zikr.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "zikr_hourly_logs",
    primaryKeys = ["zikrId", "dateKey", "hour"],
    foreignKeys = [
        ForeignKey(
            entity = ZikrEntity::class,
            parentColumns = ["id"],
            childColumns = ["zikrId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["zikrId", "dateKey"])]
)
data class ZikrHourlyLogEntity(
    val zikrId: Long,
    val dateKey: String, // YYYY-MM-DD
    val hour: Int,       // 0..23
    val count: Int = 0
)
