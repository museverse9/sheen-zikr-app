package com.sheen.zikr.ui.theme

import androidx.compose.ui.graphics.Color

// Signature SHEEN Brand Palette — Deep Emerald, Dark Teal, Rich Gold, Warm Off-White
val SheenEmeraldDeep = Color(0xFF062C2B)
val SheenEmeraldMid = Color(0xFF0D4A45)
val SheenEmeraldSoft = Color(0xFF15615A)
val SheenGold = Color(0xFFD4AF37)
val SheenGoldBright = Color(0xFFF2D27A)
val SheenGoldMuted = Color(0xFFB58E24)
val SheenIvory = Color(0xFFFAF7F2)
val SheenIvorySurface = Color(0xFFF3EEE5)
val SheenInk = Color(0xFF102423)
val SheenInkMuted = Color(0xFF4F6462)

// Dark Surfaces
val SheenDarkBg = Color(0xFF061B1A)
val SheenDarkSurface = Color(0xFF0B2725)
val SheenDarkSurfaceElevated = Color(0xFF113532)
val SheenDarkText = Color(0xFFF5F1E8)
val SheenDarkTextMuted = Color(0xFFA2B8B5)

// Deep Teal Variant
val TealDeep = Color(0xFF07323A)
val TealMid = Color(0xFF0E5360)
val TealChampagne = Color(0xFFE5C88B)

// Midnight Jade Variant
val JadeDeep = Color(0xFF0A2A22)
val JadeMid = Color(0xFF164D3E)
val JadeAmber = Color(0xFFE0A94F)

// Obsidian Gold Variant
val ObsidianBg = Color(0xFF121414)
val ObsidianSurface = Color(0xFF1C2020)
val ObsidianGold = Color(0xFFE6C25A)
