package com.sheen.zikr.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sheen.zikr.R

@Composable
fun SheenLogoMark(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp
) {
    Image(
        painter = painterResource(id = R.drawable.sheen_logo_emblem),
        contentDescription = "Sheen logo",
        contentScale = ContentScale.Crop,
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(percent = 24))
    )
}

fun containsArabicScript(text: String): Boolean {
    return text.any { ch ->
        val code = ch.code
        (code in 0x0600..0x06FF) ||
            (code in 0x0750..0x077F) ||
            (code in 0x08A0..0x08FF) ||
            (code in 0xFB50..0xFDFF) ||
            (code in 0xFE70..0xFEFF)
    }
}

fun formatIntervalLabel(intervalMs: Long): String {
    return if (intervalMs % 1000L == 0L) {
        "${intervalMs / 1000L}s"
    } else {
        String.format("%.1fs", intervalMs / 1000.0)
    }
}

fun formatDurationTimer(elapsedMs: Long): String {
    val totalSeconds = (elapsedMs / 1000L).coerceAtLeast(0L)
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}
