package com.sheen.zikr.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sheen.zikr.ui.theme.SheenEmeraldDeep
import com.sheen.zikr.ui.theme.SheenEmeraldMid
import com.sheen.zikr.ui.theme.SheenGold
import com.sheen.zikr.ui.theme.SheenGoldBright

/**
 * Original SHEEN brand mark: calligraphic Arabic letter ش (Sheen) in gold
 * set within a deep emerald-teal emblem.
 */
@Composable
fun SheenLogoMark(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    showRing: Boolean = true
) {
    val bgBrush = Brush.radialGradient(
        colors = listOf(SheenEmeraldMid, SheenEmeraldDeep)
    )
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(bgBrush)
            .then(
                if (showRing) {
                    Modifier.border(
                        width = (size.value * 0.032f).coerceAtLeast(1f).dp,
                        brush = Brush.linearGradient(listOf(SheenGoldBright, SheenGold)),
                        shape = CircleShape
                    )
                } else {
                    Modifier
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size * 0.86f)) {
            val w = this.size.width
            val h = this.size.height
            fun x(v: Float) = v / 108f * w
            fun y(v: Float) = v / 108f * h

            val sheenStroke = Path().apply {
                moveTo(x(80f), y(44f))
                cubicTo(x(80f), y(53f), x(76f), y(57f), x(71.5f), y(57f))
                cubicTo(x(67f), y(57f), x(65f), y(52f), x(65f), y(46f))
                cubicTo(x(65f), y(54f), x(61f), y(58f), x(57f), y(58f))
                cubicTo(x(53f), y(58f), x(51f), y(53f), x(51f), y(47f))
                cubicTo(x(52f), y(65f), x(45f), y(77f), x(34f), y(77f))
                cubicTo(x(22.5f), y(77f), x(18.5f), y(66f), x(21.5f), y(54f))
            }

            val goldBrush = Brush.linearGradient(
                colors = listOf(SheenGoldBright, SheenGold),
                start = Offset(x(20f), y(25f)),
                end = Offset(x(82f), y(80f))
            )

            drawPath(
                path = sheenStroke,
                brush = goldBrush,
                style = Stroke(
                    width = w * 0.062f,
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )

            fun drawDiamond(cx: Float, cy: Float, r: Float, color: Color) {
                val p = Path().apply {
                    moveTo(x(cx), y(cy - r))
                    lineTo(x(cx + r), y(cy))
                    lineTo(x(cx), y(cy + r))
                    lineTo(x(cx - r), y(cy))
                    close()
                }
                drawPath(path = p, color = color)
            }

            drawDiamond(65.0f, 29.0f, 4.3f, SheenGoldBright)
            drawDiamond(71.8f, 37.2f, 4.3f, SheenGold)
            drawDiamond(58.2f, 37.2f, 4.3f, SheenGold)
        }
    }
}

fun containsArabicScript(text: String): Boolean {
    return text.any { ch ->
        val code = ch.code
        (code in 0x0600..0x06FF) ||
            (code in 0x0750..0x077F) ||
            (code in 0x08A0..0x08FF) ||
            (code in 0xFB50..0xFDFF) ||
            (code in 0xFE70..0xFEFF)
    }
}

fun formatIntervalLabel(intervalMs: Long): String {
    return if (intervalMs % 1000L == 0L) {
        "${intervalMs / 1000L}s"
    } else {
        String.format("%.1fs", intervalMs / 1000.0)
    }
}

fun formatDurationTimer(elapsedMs: Long): String {
    val totalSeconds = (elapsedMs / 1000L).coerceAtLeast(0L)
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}
