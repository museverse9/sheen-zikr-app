package com.sheen.zikr.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sheen.zikr.ui.theme.SheenEmeraldDeep
import com.sheen.zikr.ui.theme.SheenEmeraldMid
import com.sheen.zikr.ui.theme.SheenGold
import com.sheen.zikr.ui.theme.SheenGoldBright

@Composable
fun SheenLogoMark(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    showRing: Boolean = true
) {
    val bgBrush = Brush.radialGradient(
        colors = listOf(SheenEmeraldMid, SheenEmeraldDeep)
    )
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(bgBrush)
            .then(
                if (showRing) {
                    Modifier.border(
                        width = (size.value * 0.036f).coerceAtLeast(1.2f).dp,
                        brush = Brush.linearGradient(listOf(SheenGoldBright, SheenGold)),
                        shape = CircleShape
                    )
                } else {
                    Modifier
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size * 0.88f)) {
            val w = this.size.width
            val h = this.size.height
            fun x(v: Float) = v / 108f * w
            fun y(v: Float) = v / 108f * h

            // Subtle inner hairline ring
            drawCircle(
                color = SheenGold.copy(alpha = 0.35f),
                radius = w * 0.44f,
                style = Stroke(width = w * 0.012f)
            )

            // Stylized calligraphic ش (layered for tapered qalam contrast)
            val goldBrush = Brush.linearGradient(
                colors = listOf(SheenGoldBright, SheenGold),
                start = Offset(x(20f), y(24f)),
                end = Offset(x(84f), y(80f))
            )

            val teethPath = Path().apply {
                moveTo(x(82f), y(42f))
                cubicTo(x(81f), y(51f), x(77f), y(56f), x(72f), y(56f))
                cubicTo(x(68f), y(56f), x(66f), y(51f), x(66.5f), y(44f))
                cubicTo(x(66f), y(52f), x(62f), y(57f), x(57.5f), y(57f))
                cubicTo(x(53.5f), y(57f), x(52f), y(52f), x(52.5f), y(45f))
            }
            drawPath(
                path = teethPath,
                brush = goldBrush,
                style = Stroke(width = w * 0.068f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            val kasaPath = Path().apply {
                moveTo(x(52.5f), y(45f))
                cubicTo(x(54f), y(66f), x(45f), y(79f), x(32.5f), y(79f))
                cubicTo(x(20f), y(79f), x(16f), y(66f), x(20.5f), y(51f))
            }
            drawPath(
                path = kasaPath,
                brush = goldBrush,
                style = Stroke(width = w * 0.076f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            fun drawDiamond(cx: Float, cy: Float, r: Float, color: Color) {
                val p = Path().apply {
                    moveTo(x(cx), y(cy - r * 1.05f))
                    lineTo(x(cx + r * 0.95f), y(cy))
                    lineTo(x(cx), y(cy + r * 1.05f))
                    lineTo(x(cx - r * 0.95f), y(cy))
                    close()
                }
                drawPath(path = p, color = color)
            }

            drawDiamond(66.0f, 27.5f, 4.3f, SheenGoldBright)
            drawDiamond(72.5f, 35.5f, 4.1f, SheenGold)
            drawDiamond(59.5f, 35.5f, 4.1f, SheenGold)
        }
    }
}

fun containsArabicScript(text: String): Boolean {
    return text.any { ch ->
        val code = ch.code
        (code in 0x0600..0x06FF) ||
            (code in 0x0750..0x077F) ||
            (code in 0x08A0..0x08FF) ||
            (code in 0xFB50..0xFDFF) ||
            (code in 0xFE70..0xFEFF)
    }
}

fun formatIntervalLabel(intervalMs: Long): String {
    return if (intervalMs % 1000L == 0L) {
        "${intervalMs / 1000L}s"
    } else {
        String.format("%.1fs", intervalMs / 1000.0)
    }
}

fun formatDurationTimer(elapsedMs: Long): String {
    val totalSeconds = (elapsedMs / 1000L).coerceAtLeast(0L)
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}
