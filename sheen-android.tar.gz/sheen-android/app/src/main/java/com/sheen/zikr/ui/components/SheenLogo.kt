package com.sheen.zikr.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sheen.zikr.ui.theme.SheenEmeraldDeep
import com.sheen.zikr.ui.theme.SheenEmeraldMid
import com.sheen.zikr.ui.theme.SheenGold
import com.sheen.zikr.ui.theme.SheenGoldBright

@Composable
fun SheenLogoMark(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    showRing: Boolean = true
) {
    val bgBrush = Brush.radialGradient(
        colors = listOf(SheenEmeraldMid, SheenEmeraldDeep)
    )
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(bgBrush)
            .then(
                if (showRing) {
                    Modifier.border(
                        width = (size.value * 0.036f).coerceAtLeast(1.2f).dp,
                        brush = Brush.linearGradient(listOf(SheenGoldBright, SheenGold)),
                        shape = CircleShape
                    )
                } else {
                    Modifier
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size * 0.88f)) {
            val w = this.size.width
            val h = this.size.height
            fun x(v: Float) = v / 108f * w
            fun y(v: Float) = v / 108f * h

            val goldBrush = Brush.linearGradient(
                colors = listOf(SheenGoldBright, SheenGold),
                start = Offset(x(84f), y(24f)),
                end = Offset(x(18f), y(82f))
            )

            // Cascading Thuluth teeth
            val teethPath = Path().apply {
                moveTo(x(86f), y(36f))
                cubicTo(x(84f), y(46f), x(79f), y(51f), x(74f), y(51.5f))
                cubicTo(x(70f), y(52f), x(69f), y(47f), x(70f), y(41f))
                cubicTo(x(68.5f), y(49f), x(64f), y(54.5f), x(58.5f), y(55f))
                cubicTo(x(54.5f), y(55.5f), x(53.5f), y(50.5f), x(54.5f), y(44.5f))
            }
            drawPath(
                path = teethPath,
                brush = goldBrush,
                style = Stroke(width = w * 0.062f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            // Generous sweeping kasa bowl with upturned calligraphy finial
            val kasaPath = Path().apply {
                moveTo(x(54.5f), y(44.5f))
                cubicTo(x(57f), y(68f), x(45f), y(83f), x(30f), y(82f))
                cubicTo(x(16f), y(81f), x(12.5f), y(65f), x(21f), y(48f))
                cubicTo(x(22.5f), y(45f), x(24.5f), y(44f), x(25.5f), y(45.5f))
            }
            drawPath(
                path = kasaPath,
                brush = goldBrush,
                style = Stroke(width = w * 0.078f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            fun drawNuqta(cx: Float, cy: Float, r: Float, color: Color) {
                val p = Path().apply {
                    moveTo(x(cx), y(cy - r * 1.15f))
                    lineTo(x(cx + r * 0.85f), y(cy))
                    lineTo(x(cx), y(cy + r * 1.15f))
                    lineTo(x(cx - r * 0.85f), y(cy))
                    close()
                }
                drawPath(path = p, color = color)
            }

            drawNuqta(68.5f, 22.5f, 4.3f, SheenGoldBright)
            drawNuqta(75.5f, 30.5f, 4.0f, SheenGold)
            drawNuqta(61.5f, 30.5f, 4.0f, SheenGold)
        }
    }
}

fun containsArabicScript(text: String): Boolean {
    return text.any { ch ->
        val code = ch.code
        (code in 0x0600..0x06FF) ||
            (code in 0x0750..0x077F) ||
            (code in 0x08A0..0x08FF) ||
            (code in 0xFB50..0xFDFF) ||
            (code in 0xFE70..0xFEFF)
    }
}

fun formatIntervalLabel(intervalMs: Long): String {
    return if (intervalMs % 1000L == 0L) {
        "${intervalMs / 1000L}s"
    } else {
        String.format("%.1fs", intervalMs / 1000.0)
    }
}

fun formatDurationTimer(elapsedMs: Long): String {
    val totalSeconds = (elapsedMs / 1000L).coerceAtLeast(0L)
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}
