package com.sheen.zikr.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ZikrDailyLogDao {
    @Query("SELECT * FROM zikr_daily_logs WHERE zikrId = :zikrId ORDER BY dateKey DESC")
    fun observeForZikr(zikrId: Long): Flow<List<ZikrDailyLogEntity>>

    @Query("SELECT * FROM zikr_daily_logs ORDER BY dateKey DESC")
    fun observeAll(): Flow<List<ZikrDailyLogEntity>>

    @Query("SELECT * FROM zikr_daily_logs WHERE zikrId = :zikrId AND dateKey = :dateKey LIMIT 1")
    suspend fun getForDay(zikrId: Long, dateKey: String): ZikrDailyLogEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(log: ZikrDailyLogEntity)

    @Query("DELETE FROM zikr_daily_logs WHERE zikrId = :zikrId AND dateKey = :dateKey")
    suspend fun deleteForZikrDay(zikrId: Long, dateKey: String)

    @Query("DELETE FROM zikr_daily_logs WHERE zikrId = :zikrId")
    suspend fun deleteForZikr(zikrId: Long)

    @Query("DELETE FROM zikr_daily_logs")
    suspend fun deleteAll()
}
