package com.sheen.zikr.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sheen.zikr.data.local.ZikrEntity
import com.sheen.zikr.ui.components.ZikrEditorDialog
import com.sheen.zikr.ui.components.containsArabicScript
import com.sheen.zikr.ui.theme.LocalSheenColors
import com.sheen.zikr.ui.viewmodel.SheenUiState

@Composable
fun MyZikrScreen(
    state: SheenUiState,
    onSelectZikr: (Long) -> Unit,
    onAddZikr: (String, Int) -> Unit,
    onUpdateZikr: (Long, String, Int) -> Unit,
    onDeleteZikr: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val brandColors = LocalSheenColors.current
    var showAddDialog by remember { mutableStateOf(false) }
    var editingZikr by remember { mutableStateOf<ZikrEntity?>(null) }
    var deletingZikr by remember { mutableStateOf<ZikrEntity?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        if (state.zikrList.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Your Zikr List is Empty",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Add any Zikr with a name and target repetition count to curate your routine.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(items = state.zikrList, key = { it.id }) { item ->
                    val isSelected = item.id == state.selectedZikr?.id
                    val isArabic = containsArabicScript(item.name)

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectZikr(item.id) },
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) brandColors.gold else brandColors.cardBorder
                        ),
                        tonalElevation = if (isSelected) 3.dp else 1.dp
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    if (isSelected) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Rounded.CheckCircle,
                                                contentDescription = "Selected",
                                                tint = brandColors.gold,
                                                modifier = Modifier.height(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "ACTIVE",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = brandColors.gold,
                                                letterSpacing = 1.sp
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                    }

                                    CompositionLocalProvider(
                                        LocalLayoutDirection provides if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
                                    ) {
                                        Text(
                                            text = item.name,
                                            style = if (isArabic) {
                                                MaterialTheme.typography.titleLarge.copy(
                                                    fontSize = 22.sp,
                                                    lineHeight = 32.sp
                                                )
                                            } else {
                                                MaterialTheme.typography.titleLarge
                                            },
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }

                                IconButton(onClick = { editingZikr = item }) {
                                    Icon(
                                        imageVector = Icons.Rounded.Edit,
                                        contentDescription = "Edit Zikr",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { deletingZikr = item }) {
                                    Icon(
                                        imageVector = Icons.Rounded.DeleteOutline,
                                        contentDescription = "Delete Zikr",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            LinearProgressIndicator(
                                progress = { item.progressFraction },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(999.dp)),
                                color = if (item.isTargetReached) brandColors.gold else MaterialTheme.colorScheme.primary,
                                trackColor = brandColors.trackColor
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${item.currentCount} / ${item.targetCount}",
                                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${item.progressPercent}% • Remaining ${item.remainingCount}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { showAddDialog = true },
            icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
            text = { Text("Add Zikr") },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        )
    }

    if (showAddDialog) {
        ZikrEditorDialog(
            title = "New Zikr",
            confirmLabel = "Add",
            onDismiss = { showAddDialog = false },
            onConfirm = { name, target ->
                showAddDialog = false
                onAddZikr(name, target)
            }
        )
    }

    editingZikr?.let { targetItem ->
        ZikrEditorDialog(
            title = "Edit Zikr",
            initialName = targetItem.name,
            initialTarget = targetItem.targetCount,
            confirmLabel = "Update",
            onDismiss = { editingZikr = null },
            onConfirm = { name, target ->
                editingZikr = null
                onUpdateZikr(targetItem.id, name, target)
            }
        )
    }

    deletingZikr?.let { targetItem ->
        AlertDialog(
            onDismissRequest = { deletingZikr = null },
            title = { Text("Delete Zikr?") },
            text = { Text("Remove "${targetItem.name}" and its saved count permanently?") },
            confirmButton = {
                Button(
                    onClick = {
                        deletingZikr = null
                        onDeleteZikr(targetItem.id)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    )
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingZikr = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
