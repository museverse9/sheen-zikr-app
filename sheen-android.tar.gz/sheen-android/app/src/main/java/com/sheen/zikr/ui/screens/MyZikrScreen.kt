package com.sheen.zikr.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sheen.zikr.data.local.ZikrEntity
import com.sheen.zikr.ui.components.ZikrEditorDialog
import com.sheen.zikr.ui.components.containsArabicScript
import com.sheen.zikr.ui.theme.LocalSheenColors
import com.sheen.zikr.ui.viewmodel.SheenUiState

@Composable
fun MyZikrScreen(
    state: SheenUiState,
    onSelectZikr: (Long) -> Unit,
    onOpenZikrHistory: (ZikrEntity) -> Unit,
    onAddZikr: (String, Int) -> Unit,
    onUpdateZikr: (Long, String, Int) -> Unit,
    onDeleteZikr: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val brandColors = LocalSheenColors.current
    var showAddDialog by remember { mutableStateOf(false) }
    var editingZikr by remember { mutableStateOf<ZikrEntity?>(null) }
    var deletingZikr by remember { mutableStateOf<ZikrEntity?>(null) }

    // Most recited automatically rises to the top; top 3 with counts > 0 earn 3, 2, 1 fires
    val rankedList = remember(state.zikrList) {
        state.zikrList.sortedWith(
            compareByDescending<ZikrEntity> { it.currentCount }.thenBy { it.sortOrder }
        )
    }

    Box(modifier = modifier.fillMaxSize()) {
        if (rankedList.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Your Zikr List is Empty",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Add any Zikr with a name and target repetition count to curate your routine.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(items = rankedList, key = { _, item -> item.id }) { index, item ->
                    val isSelected = item.id == state.selectedZikr?.id
                    val isArabic = containsArabicScript(item.name)
                    val fireCount = if (item.currentCount > 0 && index < 3) 3 - index else 0

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectZikr(item.id) },
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) brandColors.gold else brandColors.cardBorder
                        ),
                        tonalElevation = if (isSelected) 3.dp else 1.dp
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    if (isSelected || fireCount > 0) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            if (isSelected) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(
                                                        imageVector = Icons.Rounded.CheckCircle,
                                                        contentDescription = "Selected",
                                                        tint = brandColors.gold,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(3.dp))
                                                    Text(
                                                        text = "ACTIVE",
                                                        style = MaterialTheme.typography.labelMedium,
                                                        color = brandColors.gold,
                                                        letterSpacing = 1.sp
                                                    )
                                                }
                                            }
                                            if (fireCount > 0) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    repeat(fireCount) {
                                                        Icon(
                                                            imageVector = Icons.Rounded.LocalFireDepartment,
                                                            contentDescription = "Top Zikr",
                                                            tint = brandColors.gold,
                                                            modifier = Modifier.size(15.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                    }

                                    CompositionLocalProvider(
                                        LocalLayoutDirection provides if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
                                    ) {
                                        Text(
                                            text = item.name,
                                            style = if (isArabic) {
                                                MaterialTheme.typography.headlineMedium.copy(
                                                    fontSize = 24.sp,
                                                    lineHeight = 34.sp
                                                )
                                            } else {
                                                MaterialTheme.typography.headlineMedium.copy(
                                                    fontFamily = FontFamily.Serif,
                                                    fontSize = 20.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    letterSpacing = 0.3.sp
                                                )
                                            },
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }

                                IconButton(onClick = { onOpenZikrHistory(item) }) {
                                    Icon(
                                        imageVector = Icons.Rounded.Info,
                                        contentDescription = "Zikr history & stats",
                                        tint = brandColors.gold
                                    )
                                }
                                IconButton(onClick = { editingZikr = item }) {
                                    Icon(
                                        imageVector = Icons.Rounded.Edit,
                                        contentDescription = "Edit Zikr",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { deletingZikr = item }) {
                                    Icon(
                                        imageVector = Icons.Rounded.DeleteOutline,
                                        contentDescription = "Delete Zikr",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            LinearProgressIndicator(
                                progress = { item.progressFraction },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(999.dp)),
                                color = if (item.rounds > 0) brandColors.gold else MaterialTheme.colorScheme.primary,
                                trackColor = brandColors.trackColor
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Rounds: ${item.rounds}  •  Total: ${item.currentCount}",
                                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${item.lapCount} / ${item.targetCount}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { showAddDialog = true },
            icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
            text = { Text("Add Zikr") },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        )
    }

    if (showAddDialog) {
        ZikrEditorDialog(
            title = "New Zikr",
            confirmLabel = "Add",
            onDismiss = { showAddDialog = false },
            onConfirm = { name, target ->
                showAddDialog = false
                onAddZikr(name, target)
            }
        )
    }

    editingZikr?.let { targetItem ->
        ZikrEditorDialog(
            title = "Edit Zikr",
            initialName = targetItem.name,
            initialTarget = targetItem.targetCount,
            confirmLabel = "Update",
            onDismiss = { editingZikr = null },
            onConfirm = { name, target ->
                editingZikr = null
                onUpdateZikr(targetItem.id, name, target)
            }
        )
    }

    deletingZikr?.let { targetItem ->
        AlertDialog(
            onDismissRequest = { deletingZikr = null },
            title = { Text("Delete Zikr?") },
            text = { Text("Remove \"${targetItem.name}\" and its saved count permanently?") },
            confirmButton = {
                Button(
                    onClick = {
                        deletingZikr = null
                        onDeleteZikr(targetItem.id)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    )
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { deletingZikr = null }) { Text("Cancel") }
            }
        )
    }
}
