package com.sheen.zikr.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ZikrDao {
    @Query("SELECT * FROM zikr_items ORDER BY sortOrder ASC, createdAt ASC")
    fun observeAll(): Flow<List<ZikrEntity>>

    @Query("SELECT * FROM zikr_items WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): ZikrEntity?

    @Query("SELECT COUNT(*) FROM zikr_items")
    suspend fun getCount(): Int

    @Query("SELECT COALESCE(MAX(sortOrder), -1) FROM zikr_items")
    suspend fun getMaxSortOrder(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: ZikrEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ZikrEntity>)

    @Update
    suspend fun update(item: ZikrEntity)

    @Query("UPDATE zikr_items SET currentCount = :currentCount, completedRounds = :completedRounds, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateProgress(
        id: Long,
        currentCount: Int,
        completedRounds: Int,
        updatedAt: Long = System.currentTimeMillis()
    )

    @Query("UPDATE zikr_items SET name = :name, targetCount = :targetCount, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateDetails(
        id: Long,
        name: String,
        targetCount: Int,
        updatedAt: Long = System.currentTimeMillis()
    )

    @Query("DELETE FROM zikr_items WHERE id = :id")
    suspend fun deleteById(id: Long)
}
