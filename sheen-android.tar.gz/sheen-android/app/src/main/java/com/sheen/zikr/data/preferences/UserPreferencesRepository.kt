package com.sheen.zikr.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.sheenDataStore: DataStore<Preferences> by preferencesDataStore(name = "sheen_preferences")

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val SELECTED_ZIKR_ID = longPreferencesKey("selected_zikr_id")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val ACCENT_PALETTE = stringPreferencesKey("accent_palette")
        val COUNTER_FONT_STYLE = stringPreferencesKey("counter_font_style")
        val COUNTER_FONT_SIZE = stringPreferencesKey("counter_font_size")
        val COUNT_SOUND_ENABLED = booleanPreferencesKey("count_sound_enabled")
        val COMPLETION_SOUND_ENABLED = booleanPreferencesKey("completion_sound_enabled")
        val SELECTED_SOUND = stringPreferencesKey("selected_sound")
        val SOUND_VOLUME = floatPreferencesKey("sound_volume")
        val HAPTIC_ENABLED = booleanPreferencesKey("haptic_enabled")
        val AUTO_INTERVAL_MS = longPreferencesKey("auto_interval_ms")
        val KEEP_SCREEN_ON = booleanPreferencesKey("keep_screen_on")
    }

    val preferencesFlow: Flow<UserPreferences> = context.sheenDataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { prefs ->
            UserPreferences(
                selectedZikrId = prefs[Keys.SELECTED_ZIKR_ID] ?: -1L,
                themeMode = ThemeMode.fromName(prefs[Keys.THEME_MODE]),
                accentPalette = AccentPalette.fromName(prefs[Keys.ACCENT_PALETTE]),
                counterFontStyle = CounterFontStyle.fromName(prefs[Keys.COUNTER_FONT_STYLE]),
                counterFontSize = CounterFontSize.fromName(prefs[Keys.COUNTER_FONT_SIZE]),
                countSoundEnabled = prefs[Keys.COUNT_SOUND_ENABLED] ?: true,
                completionSoundEnabled = prefs[Keys.COMPLETION_SOUND_ENABLED] ?: true,
                selectedSound = CountSoundType.fromName(prefs[Keys.SELECTED_SOUND]),
                soundVolume = (prefs[Keys.SOUND_VOLUME] ?: 0.85f).coerceIn(0f, 1f),
                hapticEnabled = prefs[Keys.HAPTIC_ENABLED] ?: true,
                autoIntervalMs = (prefs[Keys.AUTO_INTERVAL_MS] ?: 2000L).coerceIn(500L, 300_000L),
                keepScreenOn = prefs[Keys.KEEP_SCREEN_ON] ?: true
            )
        }

    suspend fun setSelectedZikrId(id: Long) {
        context.sheenDataStore.edit { it[Keys.SELECTED_ZIKR_ID] = id }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.sheenDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setAccentPalette(palette: AccentPalette) {
        context.sheenDataStore.edit { it[Keys.ACCENT_PALETTE] = palette.name }
    }

    suspend fun setCounterFontStyle(style: CounterFontStyle) {
        context.sheenDataStore.edit { it[Keys.COUNTER_FONT_STYLE] = style.name }
    }

    suspend fun setCounterFontSize(size: CounterFontSize) {
        context.sheenDataStore.edit { it[Keys.COUNTER_FONT_SIZE] = size.name }
    }

    suspend fun setCountSoundEnabled(enabled: Boolean) {
        context.sheenDataStore.edit { it[Keys.COUNT_SOUND_ENABLED] = enabled }
    }

    suspend fun setCompletionSoundEnabled(enabled: Boolean) {
        context.sheenDataStore.edit { it[Keys.COMPLETION_SOUND_ENABLED] = enabled }
    }

    suspend fun setSelectedSound(sound: CountSoundType) {
        context.sheenDataStore.edit { it[Keys.SELECTED_SOUND] = sound.name }
    }

    suspend fun setSoundVolume(volume: Float) {
        context.sheenDataStore.edit { it[Keys.SOUND_VOLUME] = volume.coerceIn(0f, 1f) }
    }

    suspend fun setHapticEnabled(enabled: Boolean) {
        context.sheenDataStore.edit { it[Keys.HAPTIC_ENABLED] = enabled }
    }

    suspend fun setAutoIntervalMs(intervalMs: Long) {
        context.sheenDataStore.edit { it[Keys.AUTO_INTERVAL_MS] = intervalMs.coerceIn(500L, 300_000L) }
    }

    suspend fun setKeepScreenOn(enabled: Boolean) {
        context.sheenDataStore.edit { it[Keys.KEEP_SCREEN_ON] = enabled }
    }
}
