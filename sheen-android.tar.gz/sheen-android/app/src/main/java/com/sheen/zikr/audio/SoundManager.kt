package com.sheen.zikr.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import com.sheen.zikr.R
import com.sheen.zikr.data.preferences.CountSoundType

class SoundManager(context: Context) {

    private val soundPool: SoundPool
    private val soundIds = mutableMapOf<CountSoundType, Int>()
    private val completionSoundId: Int
    private val loadedIds = mutableSetOf<Int>()

    init {
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(attributes)
            .build()

        soundPool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) {
                synchronized(loadedIds) { loadedIds.add(sampleId) }
            }
        }

        val appContext = context.applicationContext
        soundIds[CountSoundType.SOFT_WOOD] = soundPool.load(appContext, R.raw.click_soft, 1)
        soundIds[CountSoundType.WOODEN_TASBIH] = soundPool.load(appContext, R.raw.click_tasbih, 1)
        soundIds[CountSoundType.CRYSTAL_TICK] = soundPool.load(appContext, R.raw.click_crystal, 1)
        soundIds[CountSoundType.WATER_DROP] = soundPool.load(appContext, R.raw.click_drop, 1)
        soundIds[CountSoundType.SOFT_BELL] = soundPool.load(appContext, R.raw.click_bell, 1)
        soundIds[CountSoundType.GENTLE_PULSE] = soundPool.load(appContext, R.raw.click_pulse, 1)
        completionSoundId = soundPool.load(appContext, R.raw.complete_chime, 1)
    }

    fun playCountSound(type: CountSoundType, volume: Float) {
        val id = soundIds[type] ?: return
        val vol = volume.coerceIn(0f, 1f)
        if (vol <= 0f) return
        val isReady = synchronized(loadedIds) { loadedIds.contains(id) }
        if (isReady) {
            soundPool.play(id, vol, vol, 1, 0, 1.0f)
        }
    }

    fun playCompletionSound(volume: Float) {
        val vol = volume.coerceIn(0f, 1f)
        if (vol <= 0f) return
        val isReady = synchronized(loadedIds) { loadedIds.contains(completionSoundId) }
        if (isReady) {
            soundPool.play(completionSoundId, vol, vol, 2, 0, 1.0f)
        }
    }

    fun release() {
        soundPool.release()
    }
}
