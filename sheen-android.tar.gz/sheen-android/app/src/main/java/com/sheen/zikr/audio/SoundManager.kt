package com.sheen.zikr.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.SoundPool
import com.sheen.zikr.data.preferences.CountSoundType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

class SoundManager(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // USAGE_MEDIA + CONTENT_TYPE_MUSIC uses Android's full-strength media output path
    // so sounds stay loud in noisy environments like a kitchen.
    private val mediaAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(6)
        .setAudioAttributes(mediaAttributes)
        .build()

    private val sampleRate = 22050
    private val toneIds = mutableMapOf<CountSoundType, Int>()
    private var completionSoundId: Int = 0
    private var milestoneHundredSoundId: Int = 0
    private var loadedCount = 0

    init {
        soundPool.setOnLoadCompleteListener { _, _, status ->
            if (status == 0) loadedCount++
        }
        scope.launch {
            CountSoundType.entries.forEach { type ->
                val pcm = synthesizeCountTone(type)
                val id = loadPcmToSoundPool(pcm)
                if (id > 0) toneIds[type] = id
            }
            completionSoundId = loadPcmToSoundPool(synthesizeCompletionChime())
            milestoneHundredSoundId = loadPcmToSoundPool(synthesizeHundredMilestoneChime())
        }
    }

    /**
     * Lifts volume strongly across low-to-mid slider positions while keeping 0f completely silent
     * and reaching full 1.0f maximum output for kitchen-level audibility.
     */
    private fun effectiveGain(volume: Float): Float {
        val clamped = volume.coerceIn(0f, 1f)
        if (clamped <= 0f) return 0f
        return (0.72f + 0.28f * clamped.toDouble().pow(0.35).toFloat()).coerceIn(0f, 1f)
    }

    fun playCountSound(type: CountSoundType, volume: Float) {
        val gain = effectiveGain(volume)
        if (gain <= 0f) return
        val id = toneIds[type]
        if (id != null && id > 0) {
            soundPool.play(id, gain, gain, 3, 0, 1.0f)
        }
    }

    fun playCompletionSound(volume: Float) {
        val gain = effectiveGain(volume)
        if (gain <= 0f) return
        if (completionSoundId > 0) {
            soundPool.play(completionSoundId, gain, gain, 3, 0, 1.0f)
        }
    }

    fun playHundredMilestoneSound(volume: Float) {
        val gain = effectiveGain(volume)
        if (gain <= 0f) return
        if (milestoneHundredSoundId > 0) {
            soundPool.play(milestoneHundredSoundId, gain, gain, 3, 0, 1.0f)
        }
    }

    fun release() {
        soundPool.release()
    }

    private fun synthesizeCountTone(type: CountSoundType): ByteArray {
        return when (type) {
            CountSoundType.WATER -> renderWaterPop(durationMs = 95)
            CountSoundType.WOOD -> renderWoodBlock(durationMs = 85)
            CountSoundType.DRUMBEAT -> renderDrumBeat(durationMs = 125)
            CountSoundType.PIANO -> renderPianoNote(durationMs = 165)
            CountSoundType.BELL -> renderBellStrike(durationMs = 195)
            CountSoundType.TASBIH -> renderTasbihBead(durationMs = 70)
        }
    }

    private fun renderWaterPop(durationMs: Int): ByteArray {
        val count = (sampleRate * durationMs) / 1000
        val out = ShortArray(count)
        var phase = 0.0
        for (i in 0 until count) {
            val p = i.toDouble() / count.coerceAtLeast(1)
            val t = i.toDouble() / sampleRate
            val freq = 360.0 + 820.0 * (p.pow(1.5))
            phase += 2.0 * PI * freq / sampleRate
            val env = sin(PI * p.pow(0.6)) * exp(-p * 1.9)
            val bubble = sin(phase) + 0.45 * sin(2.0 * phase) + 0.25 * sin(2.0 * PI * 1520.0 * t) * exp(-t * 36.0)
            out[i] = saturateToShort(bubble * env * 3.1)
        }
        return shortsToPcmBytes(out)
    }

    private fun renderWoodBlock(durationMs: Int): ByteArray {
        val count = (sampleRate * durationMs) / 1000
        val out = ShortArray(count)
        for (i in 0 until count) {
            val t = i.toDouble() / sampleRate
            val env = (1.0 - exp(-t * 750.0)) * exp(-t * 30.0)
            val f1 = 520.0
            val f2 = 1320.0
            val f3 = 2280.0
            val body = 1.05 * sin(2.0 * PI * f1 * t) +
                0.65 * sin(2.0 * PI * f2 * t) * exp(-t * 45.0) +
                0.45 * sin(2.0 * PI * f3 * t) * exp(-t * 75.0)
            out[i] = saturateToShort(body * env * 3.4)
        }
        return shortsToPcmBytes(out)
    }

    private fun renderDrumBeat(durationMs: Int): ByteArray {
        val count = (sampleRate * durationMs) / 1000
        val out = ShortArray(count)
        var pitchPhase = 0.0
        for (i in 0 until count) {
            val t = i.toDouble() / sampleRate
            val p = i.toDouble() / count.coerceAtLeast(1)
            val freq = 92.0 + 170.0 * exp(-t * 34.0)
            pitchPhase += 2.0 * PI * freq / sampleRate
            val thumpEnv = (1.0 - exp(-t * 800.0)) * exp(-t * 18.0) * (1.0 - (p.pow(4.5)).coerceIn(0.0, 1.0))
            val snapEnv = exp(-t * 110.0)
            val wave = 1.25 * sin(pitchPhase) + 0.55 * sin(2.0 * pitchPhase) + 0.70 * sin(2.0 * PI * 1050.0 * t) * snapEnv
            out[i] = saturateToShort(wave * thumpEnv * 3.5)
        }
        return shortsToPcmBytes(out)
    }

    private fun renderPianoNote(durationMs: Int): ByteArray {
        val count = (sampleRate * durationMs) / 1000
        val out = ShortArray(count)
        val baseFreq = 587.33 // D5 bright cutting piano note
        for (i in 0 until count) {
            val t = i.toDouble() / sampleRate
            val hammerAttack = 1.0 - exp(-t * 550.0)
            val decay = exp(-t * 9.5)
            val env = hammerAttack * decay
            val h1 = 1.05 * sin(2.0 * PI * baseFreq * t)
            val h2 = 0.65 * sin(2.0 * PI * (baseFreq * 2.0) * t) * exp(-t * 13.0)
            val h3 = 0.40 * sin(2.0 * PI * (baseFreq * 3.0) * t) * exp(-t * 20.0)
            val h4 = 0.25 * sin(2.0 * PI * (baseFreq * 4.0) * t) * exp(-t * 28.0)
            out[i] = saturateToShort((h1 + h2 + h3 + h4) * env * 3.15)
        }
        return shortsToPcmBytes(out)
    }

    private fun renderBellStrike(durationMs: Int): ByteArray {
        val count = (sampleRate * durationMs) / 1000
        val out = ShortArray(count)
        val fundamental = 880.0 // A5 crisp clear bell
        for (i in 0 until count) {
            val t = i.toDouble() / sampleRate
            val strike = 1.0 - exp(-t * 600.0)
            val ringEnv = strike * exp(-t * 8.0)
            val p1 = 1.05 * sin(2.0 * PI * fundamental * t)
            val p2 = 0.72 * sin(2.0 * PI * (fundamental * 2.0) * t) * exp(-t * 11.5)
            val p3 = 0.52 * sin(2.0 * PI * (fundamental * 2.756) * t) * exp(-t * 18.0)
            val p4 = 0.32 * sin(2.0 * PI * (fundamental * 4.07) * t) * exp(-t * 28.0)
            out[i] = saturateToShort((p1 + p2 + p3 + p4) * ringEnv * 3.15)
        }
        return shortsToPcmBytes(out)
    }

    private fun renderTasbihBead(durationMs: Int): ByteArray {
        val count = (sampleRate * durationMs) / 1000
        val out = ShortArray(count)
        for (i in 0 until count) {
            val t = i.toDouble() / sampleRate
            val env = (1.0 - exp(-t * 750.0)) * exp(-t * 36.0)
            val bead = 1.00 * sin(2.0 * PI * 410.0 * t) +
                0.75 * sin(2.0 * PI * 1120.0 * t) * exp(-t * 52.0) +
                0.45 * sin(2.0 * PI * 1980.0 * t) * exp(-t * 80.0)
            out[i] = saturateToShort(bead * env * 3.45)
        }
        return shortsToPcmBytes(out)
    }

    private fun synthesizeCompletionChime(): ByteArray {
        val notes = listOf(587.33, 739.99, 880.0, 1174.66)
        val noteSamples = (sampleRate * 0.13).toInt()
        val totalSamples = noteSamples * notes.size + (sampleRate * 0.18).toInt()
        val out = ShortArray(totalSamples)

        notes.forEachIndexed { idx, freq ->
            val offset = idx * noteSamples
            val len = minOf(noteSamples + (sampleRate * 0.15).toInt(), totalSamples - offset)
            for (i in 0 until len) {
                val t = i.toDouble() / sampleRate
                val env = (1.0 - exp(-t * 280.0)) * exp(-t * 6.5)
                val sample = (1.00 * sin(2.0 * PI * freq * t) + 0.45 * sin(4.0 * PI * freq * t) + 0.25 * sin(6.0 * PI * freq * t)) * env * 2.75
                val mixed = out[offset + i].toDouble() / Short.MAX_VALUE + sample
                out[offset + i] = saturateToShort(mixed)
            }
        }
        return shortsToPcmBytes(out)
    }

    private fun synthesizeHundredMilestoneChime(): ByteArray {
        val notes = listOf(659.25, 987.77, 1318.51)
        val noteSamples = (sampleRate * 0.11).toInt()
        val totalSamples = noteSamples * notes.size + (sampleRate * 0.16).toInt()
        val out = ShortArray(totalSamples)

        notes.forEachIndexed { idx, freq ->
            val offset = idx * noteSamples
            val len = minOf(noteSamples + (sampleRate * 0.13).toInt(), totalSamples - offset)
            for (i in 0 until len) {
                val t = i.toDouble() / sampleRate
                val env = (1.0 - exp(-t * 320.0)) * exp(-t * 7.2)
                val sample = (1.00 * sin(2.0 * PI * freq * t) + 0.50 * sin(4.0 * PI * freq * t)) * env * 2.85
                val mixed = out[offset + i].toDouble() / Short.MAX_VALUE + sample
                out[offset + i] = saturateToShort(mixed)
            }
        }
        return shortsToPcmBytes(out)
    }

    /**
     * High-drive ~1.6x boosted soft saturation so perceived loudness stays strong in noisy rooms
     * while avoiding harsh digital clipping.
     */
    private fun saturateToShort(value: Double): Short {
        val drive = 2.0
        val shaped = tanh(value * drive) / tanh(drive)
        return (shaped * Short.MAX_VALUE).toInt()
            .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            .toShort()
    }

    private fun shortsToPcmBytes(samples: ShortArray): ByteArray {
        val bytes = ByteArray(samples.size * 2)
        for (i in samples.indices) {
            val s = samples[i].toInt()
            bytes[i * 2] = (s and 0xFF).toByte()
            bytes[i * 2 + 1] = ((s ushr 8) and 0xFF).toByte()
        }
        return bytes
    }

    private fun loadPcmToSoundPool(pcmData: ByteArray): Int {
        return try {
            val tempFile = File.createTempFile("sheen_tone_", ".wav", appContext.cacheDir)
            writeWavFile(tempFile, pcmData, sampleRate)
            val id = soundPool.load(tempFile.absolutePath, 1)
            tempFile.deleteOnExit()
            id
        } catch (_: Exception) {
            0
        }
    }

    private fun writeWavFile(file: File, pcm: ByteArray, rate: Int) {
        val totalDataLen = pcm.size + 36
        val byteRate = rate * 2
        file.outputStream().use { fos ->
            fos.write("RIFF".toByteArray())
            fos.write(intToLittleEndian(totalDataLen))
            fos.write("WAVEfmt ".toByteArray())
            fos.write(intToLittleEndian(16))
            fos.write(shortToLittleEndian(1))
            fos.write(shortToLittleEndian(1))
            fos.write(intToLittleEndian(rate))
            fos.write(intToLittleEndian(byteRate))
            fos.write(shortToLittleEndian(2))
            fos.write(shortToLittleEndian(16))
            fos.write("data".toByteArray())
            fos.write(intToLittleEndian(pcm.size))
            fos.write(pcm)
        }
    }

    private fun intToLittleEndian(v: Int): ByteArray = byteArrayOf(
        (v and 0xFF).toByte(),
        ((v ushr 8) and 0xFF).toByte(),
        ((v ushr 16) and 0xFF).toByte(),
        ((v ushr 24) and 0xFF).toByte()
    )

    private fun shortToLittleEndian(v: Int): ByteArray = byteArrayOf(
        (v and 0xFF).toByte(),
        ((v ushr 8) and 0xFF).toByte()
    )

    fun playDirectFallback(type: CountSoundType, volume: Float) {
        val clampedVol = effectiveGain(volume)
        if (clampedVol <= 0f) return
        scope.launch {
            val pcm = synthesizeCountTone(type)
            try {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(mediaAttributes)
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(pcm.size.coerceAtLeast(1024))
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.setVolume(clampedVol)
                track.write(pcm, 0, pcm.size)
                track.play()
                delay(200L)
                track.stop()
                track.release()
            } catch (_: Exception) {
            }
        }
    }
}
