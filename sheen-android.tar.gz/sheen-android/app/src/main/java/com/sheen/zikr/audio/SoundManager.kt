package com.sheen.zikr.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.SoundPool
import com.sheen.zikr.data.preferences.CountSoundType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class SoundManager(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(6)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val sampleRate = 22050
    private val toneIds = mutableMapOf<CountSoundType, Int>()
    private var completionSoundId: Int = 0
    private var milestoneHundredSoundId: Int = 0
    private var loadedCount = 0

    init {
        soundPool.setOnLoadCompleteListener { _, _, status ->
            if (status == 0) loadedCount++
        }
        scope.launch {
            CountSoundType.entries.forEach { type ->
                val pcm = synthesizeCountTone(type)
                val id = loadPcmToSoundPool(pcm)
                if (id > 0) toneIds[type] = id
            }
            completionSoundId = loadPcmToSoundPool(synthesizeCompletionChime())
            milestoneHundredSoundId = loadPcmToSoundPool(synthesizeHundredMilestoneChime())
        }
    }

    private fun effectiveGain(volume: Float): Float {
        val clamped = volume.coerceIn(0f, 1f)
        if (clamped <= 0f) return 0f
        // Perceptual boost so low-to-mid settings stay clearly audible without exceeding 1.0f
        return kotlin.math.sqrt(clamped.toDouble()).toFloat().coerceIn(0f, 1f)
    }

    fun playCountSound(type: CountSoundType, volume: Float) {
        val gain = effectiveGain(volume)
        if (gain <= 0f) return
        val id = toneIds[type]
        if (id != null && id > 0) {
            soundPool.play(id, gain, gain, 1, 0, 1.0f)
        }
    }

    fun playCompletionSound(volume: Float) {
        val gain = effectiveGain(volume)
        if (gain <= 0f) return
        if (completionSoundId > 0) {
            soundPool.play(completionSoundId, gain, gain, 2, 0, 1.0f)
        }
    }

    fun playHundredMilestoneSound(volume: Float) {
        val gain = effectiveGain(volume)
        if (gain <= 0f) return
        if (milestoneHundredSoundId > 0) {
            soundPool.play(milestoneHundredSoundId, gain, gain, 2, 0, 1.0f)
        }
    }

    fun release() {
        soundPool.release()
    }

    private fun synthesizeCountTone(type: CountSoundType): ByteArray {
        return when (type) {
            CountSoundType.SOFT_WOOD -> renderTone(durationMs = 55, freqHz = 420.0, overtoneFreq = 840.0, decay = 26.0, amplitude = 0.88)
            CountSoundType.WOODEN_TASBIH -> renderTone(durationMs = 65, freqHz = 320.0, overtoneFreq = 640.0, decay = 28.0, amplitude = 0.94)
            CountSoundType.CRYSTAL_TICK -> renderTone(durationMs = 45, freqHz = 780.0, overtoneFreq = 1560.0, decay = 36.0, amplitude = 0.82)
            CountSoundType.WATER_DROP -> renderTone(durationMs = 60, freqHz = 480.0, overtoneFreq = 960.0, decay = 28.0, amplitude = 0.86)
            CountSoundType.SOFT_BELL -> renderTone(durationMs = 100, freqHz = 560.0, overtoneFreq = 1120.0, decay = 18.0, amplitude = 0.84)
            CountSoundType.GENTLE_PULSE -> renderTone(durationMs = 65, freqHz = 250.0, overtoneFreq = 500.0, decay = 22.0, amplitude = 0.92)
        }
    }

    private fun synthesizeCompletionChime(): ByteArray {
        val notes = listOf(440.0, 554.37, 659.25)
        val noteSamples = (sampleRate * 0.13).toInt()
        val totalSamples = noteSamples * notes.size + (sampleRate * 0.16).toInt()
        val out = ShortArray(totalSamples)

        notes.forEachIndexed { idx, freq ->
            val offset = idx * noteSamples
            val len = minOf(noteSamples + (sampleRate * 0.12).toInt(), totalSamples - offset)
            for (i in 0 until len) {
                val t = i.toDouble() / sampleRate
                val fadeOut = if (i > len - (sampleRate * 0.025).toInt()) {
                    ((len - i).toDouble() / (sampleRate * 0.025)).coerceIn(0.0, 1.0)
                } else {
                    1.0
                }
                val env = (1.0 - exp(-t * 75.0)) * exp(-t * 9.0) * fadeOut
                val sample = (0.85 * sin(2.0 * PI * freq * t) + 0.15 * sin(4.0 * PI * freq * t)) * env * 0.88
                val cur = out[offset + i].toInt() + (sample * Short.MAX_VALUE).toInt()
                out[offset + i] = cur.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
        }
        return shortsToPcmBytes(out)
    }

    private fun synthesizeHundredMilestoneChime(): ByteArray {
        val notes = listOf(587.33, 783.99)
        val noteSamples = (sampleRate * 0.11).toInt()
        val totalSamples = noteSamples * notes.size + (sampleRate * 0.14).toInt()
        val out = ShortArray(totalSamples)

        notes.forEachIndexed { idx, freq ->
            val offset = idx * noteSamples
            val len = minOf(noteSamples + (sampleRate * 0.10).toInt(), totalSamples - offset)
            for (i in 0 until len) {
                val t = i.toDouble() / sampleRate
                val fadeOut = if (i > len - (sampleRate * 0.025).toInt()) {
                    ((len - i).toDouble() / (sampleRate * 0.025)).coerceIn(0.0, 1.0)
                } else {
                    1.0
                }
                val env = (1.0 - exp(-t * 85.0)) * exp(-t * 10.0) * fadeOut
                val sample = (0.85 * sin(2.0 * PI * freq * t) + 0.15 * sin(4.0 * PI * freq * t)) * env * 0.90
                val cur = out[offset + i].toInt() + (sample * Short.MAX_VALUE).toInt()
                out[offset + i] = cur.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
        }
        return shortsToPcmBytes(out)
    }

    private fun renderTone(
        durationMs: Int,
        freqHz: Double,
        overtoneFreq: Double,
        decay: Double,
        amplitude: Double
    ): ByteArray {
        val count = (sampleRate * durationMs) / 1000
        val out = ShortArray(count)
        val tailSamples = (sampleRate * 0.012).toInt().coerceAtMost(count / 3)
        for (i in 0 until count) {
            val t = i.toDouble() / sampleRate
            val attack = 1.0 - exp(-t * 140.0)
            val tailFade = if (i >= count - tailSamples && tailSamples > 0) {
                ((count - i).toDouble() / tailSamples).coerceIn(0.0, 1.0)
            } else {
                1.0
            }
            val env = attack * exp(-t * decay) * tailFade
            val wave = 0.88 * sin(2.0 * PI * freqHz * t) + 0.12 * sin(2.0 * PI * overtoneFreq * t)
            val valShort = (wave * env * amplitude * Short.MAX_VALUE).toInt()
            out[i] = valShort.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return shortsToPcmBytes(out)
    }

    private fun shortsToPcmBytes(samples: ShortArray): ByteArray {
        val bytes = ByteArray(samples.size * 2)
        for (i in samples.indices) {
            val s = samples[i].toInt()
            bytes[i * 2] = (s and 0xFF).toByte()
            bytes[i * 2 + 1] = ((s ushr 8) and 0xFF).toByte()
        }
        return bytes
    }

    private fun loadPcmToSoundPool(pcmData: ByteArray): Int {
        return try {
            val tempFile = File.createTempFile("sheen_tone_", ".wav", appContext.cacheDir)
            writeWavFile(tempFile, pcmData, sampleRate)
            val id = soundPool.load(tempFile.absolutePath, 1)
            tempFile.deleteOnExit()
            id
        } catch (_: Exception) {
            0
        }
    }

    private fun writeWavFile(file: File, pcm: ByteArray, rate: Int) {
        val totalDataLen = pcm.size + 36
        val byteRate = rate * 2
        file.outputStream().use { fos ->
            fos.write("RIFF".toByteArray())
            fos.write(intToLittleEndian(totalDataLen))
            fos.write("WAVEfmt ".toByteArray())
            fos.write(intToLittleEndian(16))
            fos.write(shortToLittleEndian(1))
            fos.write(shortToLittleEndian(1))
            fos.write(intToLittleEndian(rate))
            fos.write(intToLittleEndian(byteRate))
            fos.write(shortToLittleEndian(2))
            fos.write(shortToLittleEndian(16))
            fos.write("data".toByteArray())
            fos.write(intToLittleEndian(pcm.size))
            fos.write(pcm)
        }
    }

    private fun intToLittleEndian(v: Int): ByteArray = byteArrayOf(
        (v and 0xFF).toByte(),
        ((v ushr 8) and 0xFF).toByte(),
        ((v ushr 16) and 0xFF).toByte(),
        ((v ushr 24) and 0xFF).toByte()
    )

    private fun shortToLittleEndian(v: Int): ByteArray = byteArrayOf(
        (v and 0xFF).toByte(),
        ((v ushr 8) and 0xFF).toByte()
    )

    fun playDirectFallback(type: CountSoundType, volume: Float) {
        val clampedVol = effectiveGain(volume)
        if (clampedVol <= 0f) return
        scope.launch {
            val pcm = synthesizeCountTone(type)
            try {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(pcm.size.coerceAtLeast(1024))
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.setVolume(clampedVol)
                track.write(pcm, 0, pcm.size)
                track.play()
                delay(140L)
                track.stop()
                track.release()
            } catch (_: Exception) {
            }
        }
    }
}
