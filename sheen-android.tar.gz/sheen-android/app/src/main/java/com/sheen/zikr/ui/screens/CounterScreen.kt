package com.sheen.zikr.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.FormatListBulleted
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.sheen.zikr.BuildConfig
import com.sheen.zikr.ui.components.AutoCounterSetupDialog
import com.sheen.zikr.ui.components.CircularProgressCounter
import com.sheen.zikr.ui.components.SheenLogoMark
import com.sheen.zikr.ui.components.ZikrEditorDialog
import com.sheen.zikr.ui.components.containsArabicScript
import com.sheen.zikr.ui.components.formatDurationTimer
import com.sheen.zikr.ui.components.formatIntervalLabel
import com.sheen.zikr.ui.theme.LocalSheenColors
import com.sheen.zikr.ui.theme.SheenEditorialSerif
import com.sheen.zikr.ui.viewmodel.AutoCountStatus
import com.sheen.zikr.ui.viewmodel.SheenUiState

@Composable
fun CounterScreen(
    state: SheenUiState,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onReset: () -> Unit,
    onStartAutoWithInterval: (Long) -> Unit,
    onPauseAuto: () -> Unit,
    onResumeAuto: () -> Unit,
    onStopAuto: () -> Unit,
    onToggleStopwatch: () -> Unit,
    onResetStopwatch: () -> Unit,
    onToggleSound: (Boolean) -> Unit,
    onToggleHaptic: (Boolean) -> Unit,
    onUpdateZikr: (Long, String, Int) -> Unit,
    onAddZikrClick: () -> Unit,
    onOpenMyZikr: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val brandColors = LocalSheenColors.current
    val selectedZikr = state.selectedZikr
    val prefs = state.preferences
    val autoState = state.autoCount
    val stopwatch = state.stopwatch

    var showResetDialog by remember { mutableStateOf(false) }
    var showAutoDialog by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. TOP BAR: Tappable Option 5 Sheen Logo (left) | Stopwatch Pill (center) | Edit Zikr (right)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SheenLogoMark(
                    size = 42.dp,
                    modifier = Modifier.clickable { showAboutDialog = true }
                )

                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = brandColors.dockBg,
                    border = BorderStroke(1.dp, brandColors.cardBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onToggleStopwatch,
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = if (stopwatch.isRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = if (stopwatch.isRunning) "Pause stopwatch" else "Start stopwatch",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = formatDurationTimer(stopwatch.elapsedMs),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 0.8.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                        IconButton(
                            onClick = onResetStopwatch,
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = "Reset stopwatch",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                IconButton(
                    onClick = { if (selectedZikr != null) showEditDialog = true },
                    enabled = selectedZikr != null
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Edit,
                        contentDescription = "Edit current Zikr",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // 2. ZIKR NAME (centered editorial serif, tappable to switch Zikr)
            if (selectedZikr != null) {
                val isArabic = containsArabicScript(selectedZikr.name)
                CompositionLocalProvider(
                    LocalLayoutDirection provides if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
                ) {
                    Text(
                        text = selectedZikr.name,
                        style = if (isArabic) {
                            MaterialTheme.typography.headlineMedium.copy(fontSize = 27.sp)
                        } else {
                            MaterialTheme.typography.headlineMedium.copy(
                                fontFamily = SheenEditorialSerif,
                                fontWeight = FontWeight.SemiBold
                            )
                        },
                        color = MaterialTheme.colorScheme.onBackground,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onOpenMyZikr)
                            .padding(horizontal = 8.dp)
                    )
                }
            } else {
                Text(
                    text = "Tap + to add your first Zikr",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }

            // 3. SYMMETRICAL UTILITY ROW: [ A (left) | Perfectly Centered Round/Paused Pill (center) | Sound & Vibration (right) ]
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
            ) {
                // Left: Auto-Counter trigger or active pill
                Box(modifier = Modifier.align(Alignment.CenterStart)) {
                    when (autoState.status) {
                        AutoCountStatus.STOPPED -> {
                            Surface(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .clickable(enabled = selectedZikr != null) { showAutoDialog = true },
                                shape = CircleShape,
                                color = brandColors.dockBg,
                                border = BorderStroke(1.5.dp, brandColors.cardBorder)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "A",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = brandColors.gold
                                    )
                                }
                            }
                        }

                        AutoCountStatus.RUNNING, AutoCountStatus.PAUSED -> {
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = MaterialTheme.colorScheme.primaryContainer,
                                border = BorderStroke(1.dp, brandColors.gold)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = {
                                            if (autoState.status == AutoCountStatus.RUNNING) onPauseAuto()
                                            else onResumeAuto()
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (autoState.status == AutoCountStatus.RUNNING) {
                                                Icons.Rounded.Pause
                                            } else {
                                                Icons.Rounded.PlayArrow
                                            },
                                            contentDescription = "Pause or resume auto count",
                                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Text(
                                        text = if (autoState.status == AutoCountStatus.PAUSED) {
                                            "Paused"
                                        } else {
                                            formatIntervalLabel(prefs.autoIntervalMs)
                                        },
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                    IconButton(
                                        onClick = onStopAuto,
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Stop,
                                            contentDescription = "Stop auto count",
                                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Dead-Center: Round Completed pill or Auto Paused notice
                Box(modifier = Modifier.align(Alignment.Center)) {
                    AnimatedVisibility(
                        visible = state.roundBanner != null || (autoState.pausedNotice != null && autoState.status != AutoCountStatus.RUNNING),
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        val banner = state.roundBanner
                        if (banner != null) {
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.2.dp, brandColors.gold),
                                shadowElevation = 2.dp
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.AutoAwesome,
                                        contentDescription = null,
                                        tint = brandColors.gold,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "Round ${banner.roundNumber} completed",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1
                                    )
                                }
                            }
                        } else if (autoState.pausedNotice != null && autoState.status == AutoCountStatus.STOPPED) {
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = brandColors.gold.copy(alpha = 0.16f),
                                border = BorderStroke(1.dp, brandColors.gold.copy(alpha = 0.5f))
                            ) {
                                Text(
                                    text = autoState.pausedNotice,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = brandColors.gold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                // Right: Sound & Vibration toggles
                Row(
                    modifier = Modifier.align(Alignment.CenterEnd),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    IconButton(onClick = { onToggleSound(!prefs.countSoundEnabled) }) {
                        Icon(
                            imageVector = if (prefs.countSoundEnabled) {
                                Icons.AutoMirrored.Rounded.VolumeUp
                            } else {
                                Icons.AutoMirrored.Rounded.VolumeOff
                            },
                            contentDescription = "Toggle count sound",
                            tint = if (prefs.countSoundEnabled) brandColors.gold else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
                        )
                    }
                    IconButton(onClick = { onToggleHaptic(!prefs.hapticEnabled) }) {
                        Icon(
                            imageVector = Icons.Rounded.Vibration,
                            contentDescription = "Toggle vibration",
                            tint = if (prefs.hapticEnabled) brandColors.gold else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
                        )
                    }
                }
            }

            // 4. FOCAL LARGE CIRCULAR COUNTER
            if (selectedZikr != null) {
                CircularProgressCounter(
                    currentCount = selectedZikr.currentCount,
                    progressFraction = selectedZikr.progressFraction,
                    progressPercent = selectedZikr.progressPercent,
                    fontStyle = prefs.counterFontStyle,
                    fontSize = prefs.counterFontSize,
                    autoTickProgress = autoState.nextTickProgress,
                    isAutoRunning = autoState.status == AutoCountStatus.RUNNING,
                    onTapCount = onIncrement
                )
            } else {
                Spacer(modifier = Modifier.height(220.dp))
            }

            // 5. ROUNDS (left) & LAP COUNT / TARGET (right)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Rounds: ",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = (selectedZikr?.rounds ?: 0).toString(),
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = brandColors.gold
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Count: ",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${selectedZikr?.lapCount ?: 0}",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = brandColors.gold
                    )
                    Text(
                        text = " / ${selectedZikr?.targetCount ?: 0}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // 6. COMPACT BOTTOM DOCK
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                color = brandColors.dockBg,
                border = BorderStroke(1.dp, brandColors.cardBorder),
                tonalElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if ((selectedZikr?.currentCount ?: 0) > 0) showResetDialog = true
                        },
                        enabled = (selectedZikr?.currentCount ?: 0) > 0 || autoState.status != AutoCountStatus.STOPPED
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Reset counter",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    IconButton(
                        onClick = onDecrement,
                        enabled = (selectedZikr?.currentCount ?: 0) > 0
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Remove,
                            contentDescription = "Decrement count",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Surface(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onAddZikrClick),
                        shape = CircleShape,
                        color = brandColors.gold,
                        shadowElevation = 4.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Rounded.Add,
                                contentDescription = "Add new Zikr",
                                tint = brandColors.deepBrand,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }

                    IconButton(onClick = onOpenMyZikr) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.FormatListBulleted,
                            contentDescription = "My Zikr list",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    IconButton(onClick = onOpenSettings) {
                        Icon(
                            imageVector = Icons.Rounded.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }

    if (showAboutDialog) {
        Dialog(onDismissRequest = { showAboutDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, brandColors.cardBorder),
                tonalElevation = 6.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 26.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    SheenLogoMark(size = 84.dp)
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Sheen",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontFamily = SheenEditorialSerif,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.6.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Your Zikr. Your Rhythm. Your Routine.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = brandColors.gold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Version ${BuildConfig.VERSION_NAME}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    TextButton(onClick = { showAboutDialog = false }) {
                        Text("Close")
                    }
                }
            }
        }
    }

    if (showResetDialog && selectedZikr != null) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset Counter?") },
            text = { Text("Reset the count and rounds for \"${selectedZikr.name}\" back to 0?") },
            confirmButton = {
                Button(
                    onClick = {
                        showResetDialog = false
                        onReset()
                    }
                ) { Text("Reset") }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showAutoDialog) {
        AutoCounterSetupDialog(
            initialIntervalMs = prefs.autoIntervalMs,
            onDismiss = { showAutoDialog = false },
            onStartAuto = { intervalMs ->
                showAutoDialog = false
                onStartAutoWithInterval(intervalMs)
            }
        )
    }

    if (showEditDialog && selectedZikr != null) {
        ZikrEditorDialog(
            title = "Edit Zikr",
            initialName = selectedZikr.name,
            initialTarget = selectedZikr.targetCount,
            confirmLabel = "Update",
            onDismiss = { showEditDialog = false },
            onConfirm = { name, target ->
                showEditDialog = false
                onUpdateZikr(selectedZikr.id, name, target)
            }
        )
    }
}
