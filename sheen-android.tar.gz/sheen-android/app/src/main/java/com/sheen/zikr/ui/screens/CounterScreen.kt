package com.sheen.zikr.ui.screens

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.FormatListBulleted
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.AutoMode
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sheen.zikr.data.local.ZikrDailyLogEntity
import com.sheen.zikr.ui.components.AutoCounterSetupDialog
import com.sheen.zikr.ui.components.CircularProgressCounter
import com.sheen.zikr.ui.components.SheenLogoMark
import com.sheen.zikr.ui.components.ZikrEditorDialog
import com.sheen.zikr.ui.components.containsArabicScript
import com.sheen.zikr.ui.components.formatDurationTimer
import com.sheen.zikr.ui.components.formatIntervalLabel
import com.sheen.zikr.ui.theme.LocalSheenColors
import com.sheen.zikr.ui.theme.SheenDuaCursiveItalicFont
import com.sheen.zikr.ui.theme.SheenEditorialSerif
import com.sheen.zikr.ui.theme.SheenIndoPakBoldFont
import com.sheen.zikr.ui.viewmodel.AutoCountStatus
import com.sheen.zikr.ui.viewmodel.DuaLibrary
import com.sheen.zikr.ui.viewmodel.SheenUiState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import java.util.Calendar
import java.util.Locale

@Composable
fun CounterScreen(
    state: SheenUiState,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onReset: () -> Unit,
    onResetRounds: () -> Unit,
    onResetDayHistory: (Long, String) -> Unit,
    observeDailyHistory: (Long) -> Flow<List<ZikrDailyLogEntity>>,
    onStartAutoWithInterval: (Long) -> Unit,
    onPauseAuto: () -> Unit,
    onResumeAuto: () -> Unit,
    onStopAuto: () -> Unit,
    onToggleStopwatch: () -> Unit,
    onResetStopwatch: () -> Unit,
    onCycleZikr: (Int) -> Unit,
    onToggleDimming: () -> Unit,
    onToggleSound: (Boolean) -> Unit,
    onToggleHaptic: (Boolean) -> Unit,
    onUpdateZikr: (Long, String, Int) -> Unit,
    onAddZikrClick: () -> Unit,
    onOpenMyZikr: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val brandColors = LocalSheenColors.current
    val selectedZikr = state.selectedZikr
    val prefs = state.preferences
    val autoState = state.autoCount
    val stopwatch = state.stopwatch
    val canCycle = state.zikrList.size > 1

    val nowCal = remember { Calendar.getInstance() }
    val todayKey = remember {
        String.format(
            Locale.US,
            "%04d-%02d-%02d",
            nowCal.get(Calendar.YEAR),
            nowCal.get(Calendar.MONTH) + 1,
            nowCal.get(Calendar.DAY_OF_MONTH)
        )
    }
    val monthKeyPrefix = remember {
        String.format(
            Locale.US,
            "%04d-%02d",
            nowCal.get(Calendar.YEAR),
            nowCal.get(Calendar.MONTH) + 1
        )
    }
    val zikrDailyLogs by remember(selectedZikr?.id) {
        if (selectedZikr != null) observeDailyHistory(selectedZikr.id)
        else flowOf(emptyList())
    }.collectAsStateWithLifecycle(initialValue = emptyList())

    val dayCountValue = remember(zikrDailyLogs, todayKey, selectedZikr?.currentCount) {
        zikrDailyLogs.firstOrNull { it.dateKey == todayKey }?.count ?: (selectedZikr?.currentCount ?: 0)
    }
    val monthCountValue = remember(zikrDailyLogs, monthKeyPrefix, selectedZikr?.currentCount) {
        val sum = zikrDailyLogs.filter { it.dateKey.startsWith(monthKeyPrefix) }.sumOf { it.count }
        if (sum > 0) sum else (selectedZikr?.currentCount ?: 0)
    }
    val dayRoundsValue = remember(zikrDailyLogs, todayKey, selectedZikr?.rounds) {
        zikrDailyLogs.firstOrNull { it.dateKey == todayKey }?.rounds ?: (selectedZikr?.rounds ?: 0)
    }
    val monthRoundsValue = remember(zikrDailyLogs, monthKeyPrefix, selectedZikr?.rounds) {
        val sum = zikrDailyLogs.filter { it.dateKey.startsWith(monthKeyPrefix) }.sumOf { it.rounds }
        if (sum > 0) sum else (selectedZikr?.rounds ?: 0)
    }

    // false = Month, true = Day; clicking either Rounds or Count toggles both
    var showDayPeriod by remember { mutableStateOf(false) }

    var showResetDialog by remember { mutableStateOf(false) }
    var showAutoDialog by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var duaSeed by remember { mutableIntStateOf(0) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    SheenLogoMark(
                        size = 42.dp,
                        modifier = Modifier.clickable {
                            duaSeed = ((selectedZikr?.currentCount ?: 0) + (selectedZikr?.rounds ?: 0) + duaSeed + 1)
                            showAboutDialog = true
                        }
                    )

                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = brandColors.dockBg,
                        border = BorderStroke(1.dp, brandColors.cardBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = onToggleStopwatch,
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = if (stopwatch.isRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    contentDescription = if (stopwatch.isRunning) "Pause stopwatch" else "Start stopwatch",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Text(
                                text = formatDurationTimer(stopwatch.elapsedMs),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    letterSpacing = 0.8.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                            IconButton(
                                onClick = onResetStopwatch,
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = "Reset stopwatch",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = { if (selectedZikr != null) showEditDialog = true },
                        enabled = selectedZikr != null
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Edit,
                            contentDescription = "Edit current Zikr",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = state.roundBanner != null,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        val banner = state.roundBanner
                        if (banner != null) {
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.2.dp, brandColors.gold),
                                shadowElevation = 2.dp
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.AutoAwesome,
                                        contentDescription = null,
                                        tint = brandColors.gold,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = "Round ${banner.roundNumber} completed",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = { onCycleZikr(-1) },
                        enabled = canCycle,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowLeft,
                            contentDescription = "Previous Zikr",
                            tint = if (canCycle) brandColors.gold else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.25f),
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    if (selectedZikr != null) {
                        val isArabic = containsArabicScript(selectedZikr.name)
                        CompositionLocalProvider(
                            LocalLayoutDirection provides if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
                        ) {
                            Text(
                                text = selectedZikr.name,
                                style = if (isArabic) {
                                    MaterialTheme.typography.headlineMedium.copy(
                                        fontFamily = SheenIndoPakBoldFont,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 27.sp
                                    )
                                } else {
                                    MaterialTheme.typography.headlineMedium.copy(
                                        fontFamily = SheenEditorialSerif,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                },
                                color = MaterialTheme.colorScheme.onBackground,
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable(onClick = onOpenMyZikr)
                                    .padding(horizontal = 6.dp)
                            )
                        }
                    } else {
                        Text(
                            text = "Tap + to add your first Zikr",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    IconButton(
                        onClick = { onCycleZikr(1) },
                        enabled = canCycle,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                            contentDescription = "Next Zikr",
                            tint = if (canCycle) brandColors.gold else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.25f),
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        when (autoState.status) {
                            AutoCountStatus.STOPPED -> {
                                Surface(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .clickable(enabled = selectedZikr != null) { showAutoDialog = true },
                                    shape = CircleShape,
                                    color = brandColors.dockBg,
                                    border = BorderStroke(1.5.dp, brandColors.cardBorder)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Rounded.AutoMode,
                                            contentDescription = "Auto counter",
                                            tint = brandColors.gold,
                                            modifier = Modifier.size(19.dp)
                                        )
                                    }
                                }
                            }

                            AutoCountStatus.RUNNING, AutoCountStatus.PAUSED -> {
                                Surface(
                                    shape = RoundedCornerShape(999.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    border = BorderStroke(1.dp, brandColors.gold)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(
                                            onClick = {
                                                if (autoState.status == AutoCountStatus.RUNNING) onPauseAuto()
                                                else onResumeAuto()
                                            },
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (autoState.status == AutoCountStatus.RUNNING) {
                                                    Icons.Rounded.Pause
                                                } else {
                                                    Icons.Rounded.PlayArrow
                                                },
                                                contentDescription = "Pause or resume auto count",
                                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                                modifier = Modifier.size(17.dp)
                                            )
                                        }
                                        Text(
                                            text = if (autoState.status == AutoCountStatus.PAUSED) {
                                                "Paused"
                                            } else {
                                                formatIntervalLabel(prefs.autoIntervalMs)
                                            },
                                            style = MaterialTheme.typography.labelLarge,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                        IconButton(
                                            onClick = onStopAuto,
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Stop,
                                                contentDescription = "Stop auto count",
                                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                                modifier = Modifier.size(17.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        IconButton(
                            onClick = onToggleDimming,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                imageVector = if (state.isDimmed) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                                contentDescription = "Toggle screen dimming",
                                tint = if (state.isDimmed) brandColors.gold else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        IconButton(onClick = { onToggleSound(!prefs.countSoundEnabled) }) {
                            Icon(
                                imageVector = if (prefs.countSoundEnabled) {
                                    Icons.AutoMirrored.Rounded.VolumeUp
                                } else {
                                    Icons.AutoMirrored.Rounded.VolumeOff
                                },
                                contentDescription = "Toggle count sound",
                                tint = if (prefs.countSoundEnabled) brandColors.gold else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
                            )
                        }
                        IconButton(onClick = { onToggleHaptic(!prefs.hapticEnabled) }) {
                            Icon(
                                imageVector = Icons.Rounded.Vibration,
                                contentDescription = "Toggle vibration",
                                tint = if (prefs.hapticEnabled) brandColors.gold else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
                            )
                        }
                    }
                }
            }

            if (selectedZikr != null) {
                CircularProgressCounter(
                    currentCount = selectedZikr.displayLapCount,
                    targetCount = selectedZikr.targetCount,
                    progressFraction = selectedZikr.progressFraction,
                    progressPercent = selectedZikr.progressPercent,
                    fontStyle = prefs.counterFontStyle,
                    fontSize = prefs.counterFontSize,
                    autoTickProgress = autoState.nextTickProgress,
                    isAutoRunning = autoState.status == AutoCountStatus.RUNNING,
                    onTapCount = onIncrement
                )
            } else {
                Spacer(modifier = Modifier.height(220.dp))
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val roundLabel = if (showDayPeriod) "Daily Round: " else "Monthly Round: "
                val countLabel = if (showDayPeriod) "Daily Count: " else "Monthly Count: "
                val roundsValue = if (showDayPeriod) dayRoundsValue else monthRoundsValue
                val countValue = if (showDayPeriod) dayCountValue else monthCountValue

                val countDigits = countValue.toString().length
                val countValueSize = when {
                    countDigits >= 7 -> 15.sp
                    countDigits >= 5 -> 17.sp
                    else -> 20.sp
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .weight(0.45f, fill = false)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showDayPeriod = !showDayPeriod }
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = roundLabel,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontSize = 15.sp,
                                lineHeight = 20.sp,
                                platformStyle = androidx.compose.ui.text.PlatformTextStyle(includeFontPadding = false)
                            ),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "$roundsValue",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontSize = 17.sp,
                                lineHeight = 20.sp,
                                fontWeight = FontWeight.Bold,
                                platformStyle = androidx.compose.ui.text.PlatformTextStyle(includeFontPadding = false)
                            ),
                            color = brandColors.gold,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .weight(0.55f, fill = false)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showDayPeriod = !showDayPeriod }
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = countLabel,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontSize = 15.sp,
                                lineHeight = 20.sp,
                                platformStyle = androidx.compose.ui.text.PlatformTextStyle(includeFontPadding = false)
                            ),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "$countValue",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontSize = countValueSize,
                                lineHeight = 20.sp,
                                fontWeight = FontWeight.Bold,
                                platformStyle = androidx.compose.ui.text.PlatformTextStyle(includeFontPadding = false)
                            ),
                            color = brandColors.gold,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    color = brandColors.dockBg,
                    border = BorderStroke(1.dp, brandColors.cardBorder),
                    tonalElevation = 2.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                if ((selectedZikr?.rounds ?: 0) > 0 || (selectedZikr?.currentCount ?: 0) > 0) {
                                    showResetDialog = true
                                }
                            },
                            enabled = (selectedZikr?.rounds ?: 0) > 0 || (selectedZikr?.currentCount ?: 0) > 0
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = "Reset current round",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        IconButton(
                            onClick = onDecrement,
                            enabled = (selectedZikr?.currentCount ?: 0) > 0
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Remove,
                                contentDescription = "Decrement count",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Surface(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .clickable(onClick = onAddZikrClick),
                            shape = CircleShape,
                            color = brandColors.gold,
                            shadowElevation = 4.dp
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Rounded.Add,
                                    contentDescription = "Add new Zikr",
                                    tint = brandColors.deepBrand,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }

                        IconButton(onClick = onOpenMyZikr) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.FormatListBulleted,
                                contentDescription = "My Zikr list",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        IconButton(onClick = onOpenSettings) {
                            Icon(
                                imageVector = Icons.Rounded.Settings,
                                contentDescription = "Settings",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        if (state.isDimmed) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f))
            )
        }
    }

    if (showAboutDialog) {
        val activeDua = remember(duaSeed) { DuaLibrary.duaForTick(duaSeed) }
        val isDuaArabic = containsArabicScript(activeDua)
        Dialog(
            onDismissRequest = { showAboutDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { showAboutDialog = false }
                    .padding(horizontal = 24.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {},
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, brandColors.cardBorder),
                    tonalElevation = 6.dp
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        IconButton(
                            onClick = { showAboutDialog = false },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(10.dp)
                                .size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Dismiss",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp, vertical = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            SheenLogoMark(size = 82.dp)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Sheen",
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontFamily = SheenEditorialSerif,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.6.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Your Zikr. Your Rhythm. Your Routine.",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                color = brandColors.gold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            CompositionLocalProvider(
                                LocalLayoutDirection provides if (isDuaArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
                            ) {
                                Text(
                                    text = activeDua,
                                    style = if (isDuaArabic) {
                                        MaterialTheme.typography.bodyLarge.copy(
                                            fontFamily = SheenIndoPakBoldFont,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp,
                                            lineHeight = 28.sp
                                        )
                                    } else {
                                        MaterialTheme.typography.bodyMedium.copy(
                                            fontFamily = SheenDuaCursiveItalicFont,
                                            fontStyle = FontStyle.Italic,
                                            fontSize = 14.sp,
                                            lineHeight = 20.sp
                                        )
                                    },
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showResetDialog && selectedZikr != null) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset Round?") },
            text = { Text("Reset the current round to 0 for \"${selectedZikr.name}\"?") },
            confirmButton = {
                Button(
                    onClick = {
                        showResetDialog = false
                        onResetRounds()
                    }
                ) { Text("Reset") }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showAutoDialog) {
        AutoCounterSetupDialog(
            initialIntervalMs = prefs.autoIntervalMs,
            onDismiss = { showAutoDialog = false },
            onStartAuto = { intervalMs ->
                showAutoDialog = false
                onStartAutoWithInterval(intervalMs)
            }
        )
    }

    if (showEditDialog && selectedZikr != null) {
        ZikrEditorDialog(
            title = "Edit Zikr",
            initialName = selectedZikr.name,
            initialTarget = selectedZikr.targetCount,
            confirmLabel = "Update",
            onDismiss = { showEditDialog = false },
            onConfirm = { name, target ->
                showEditDialog = false
                onUpdateZikr(selectedZikr.id, name, target)
            }
        )
    }
}
