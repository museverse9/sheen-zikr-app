package com.sheen.zikr.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sheen.zikr.ui.components.CircularProgressCounter
import com.sheen.zikr.ui.components.CustomIntervalDialog
import com.sheen.zikr.ui.components.containsArabicScript
import com.sheen.zikr.ui.components.formatDurationTimer
import com.sheen.zikr.ui.components.formatIntervalLabel
import com.sheen.zikr.ui.theme.LocalSheenColors
import com.sheen.zikr.ui.viewmodel.AutoCountStatus
import com.sheen.zikr.ui.viewmodel.SheenUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CounterScreen(
    state: SheenUiState,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onReset: () -> Unit,
    onStartAuto: () -> Unit,
    onPauseAuto: () -> Unit,
    onResumeAuto: () -> Unit,
    onStopAuto: () -> Unit,
    onIntervalSelected: (Long) -> Unit,
    onToggleSound: (Boolean) -> Unit,
    onOpenMyZikr: () -> Unit,
    onAddZikrClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val brandColors = LocalSheenColors.current
    val selectedZikr = state.selectedZikr
    val prefs = state.preferences
    val autoState = state.autoCount

    var showResetDialog by remember { mutableStateOf(false) }
    var showCustomIntervalDialog by remember { mutableStateOf(false) }

    if (selectedZikr == null) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "No Zikr Selected",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Create your first Zikr with a name and target repetitions to begin counting.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(onClick = onAddZikrClick) {
                Icon(Icons.Rounded.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Create Zikr")
            }
        }
        return
    }

    val isArabic = containsArabicScript(selectedZikr.name)
    val presetIntervals = listOf(1000L, 2000L, 3000L, 4000L, 5000L)
    val isCustomInterval = prefs.autoIntervalMs !in presetIntervals

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Selected Zikr Selector Pill
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpenMyZikr),
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, brandColors.cardBorder),
            tonalElevation = 1.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "CURRENT ZIKR",
                        style = MaterialTheme.typography.labelMedium,
                        color = brandColors.gold,
                        letterSpacing = 1.1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    CompositionLocalProvider(
                        LocalLayoutDirection provides if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
                    ) {
                        Text(
                            text = selectedZikr.name,
                            style = if (isArabic) {
                                MaterialTheme.typography.headlineMedium.copy(
                                    fontSize = 26.sp,
                                    lineHeight = 38.sp
                                )
                            } else {
                                MaterialTheme.typography.headlineMedium
                            },
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { onToggleSound(!prefs.countSoundEnabled) }) {
                        Icon(
                            imageVector = if (prefs.countSoundEnabled) {
                                Icons.AutoMirrored.Rounded.VolumeUp
                            } else {
                                Icons.AutoMirrored.Rounded.VolumeOff
                            },
                            contentDescription = if (prefs.countSoundEnabled) "Mute count sound" else "Enable count sound",
                            tint = if (prefs.countSoundEnabled) brandColors.gold else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowDown,
                        contentDescription = "Switch Zikr",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(22.dp))

        // Main Focal Circular Counter
        CircularProgressCounter(
            currentCount = selectedZikr.currentCount,
            targetCount = selectedZikr.targetCount,
            progressFraction = selectedZikr.progressFraction,
            isTargetReached = selectedZikr.isTargetReached,
            fontStyle = prefs.counterFontStyle,
            fontSize = prefs.counterFontSize,
            autoTickProgress = autoState.nextTickProgress,
            isAutoRunning = autoState.status == AutoCountStatus.RUNNING,
            onTapCount = onIncrement
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Progress & Remaining Summary Strip
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                MetricItem(
                    label = "Progress",
                    value = "${selectedZikr.progressPercent}%"
                )
                MetricItem(
                    label = "Remaining",
                    value = selectedZikr.remainingCount.toString()
                )
                MetricItem(
                    label = if (autoState.elapsedSessionMs > 0L) "Timer" else "Target",
                    value = if (autoState.elapsedSessionMs > 0L) {
                        formatDurationTimer(autoState.elapsedSessionMs)
                    } else {
                        selectedZikr.targetCount.toString()
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Manual Controls Row (-1, Count, Reset)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilledTonalIconButton(
                onClick = onDecrement,
                enabled = selectedZikr.currentCount > 0,
                modifier = Modifier.size(54.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Remove,
                    contentDescription = "Decrement count"
                )
            }

            Button(
                onClick = onIncrement,
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Count",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                )
            }

            FilledTonalIconButton(
                onClick = {
                    if (selectedZikr.currentCount > 0) {
                        showResetDialog = true
                    }
                },
                enabled = selectedZikr.currentCount > 0 || autoState.status != AutoCountStatus.STOPPED,
                modifier = Modifier.size(54.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = "Reset count"
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Automatic Hands-Free Counting Card
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, brandColors.cardBorder),
            tonalElevation = 1.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Timer,
                            contentDescription = null,
                            tint = brandColors.gold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Hands-Free Auto Count",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = when (autoState.status) {
                            AutoCountStatus.RUNNING -> MaterialTheme.colorScheme.primaryContainer
                            AutoCountStatus.PAUSED -> brandColors.gold.copy(alpha = 0.18f)
                            AutoCountStatus.STOPPED -> MaterialTheme.colorScheme.surfaceVariant
                        }
                    ) {
                        Text(
                            text = when (autoState.status) {
                                AutoCountStatus.RUNNING -> "Every ${formatIntervalLabel(prefs.autoIntervalMs)}"
                                AutoCountStatus.PAUSED -> "Paused • ${formatIntervalLabel(prefs.autoIntervalMs)}"
                                AutoCountStatus.STOPPED -> "Every ${formatIntervalLabel(prefs.autoIntervalMs)}"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = when (autoState.status) {
                                AutoCountStatus.RUNNING -> MaterialTheme.colorScheme.onPrimaryContainer
                                AutoCountStatus.PAUSED -> brandColors.gold
                                AutoCountStatus.STOPPED -> MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                AnimatedVisibility(visible = autoState.status == AutoCountStatus.PAUSED && autoState.pausedByLifecycle) {
                    Text(
                        text = "Paused automatically when leaving SHEEN. Tap Resume when ready.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = brandColors.gold,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    presetIntervals.forEach { ms ->
                        FilterChip(
                            selected = prefs.autoIntervalMs == ms,
                            onClick = { onIntervalSelected(ms) },
                            label = { Text(formatIntervalLabel(ms)) }
                        )
                    }
                    FilterChip(
                        selected = isCustomInterval,
                        onClick = { showCustomIntervalDialog = true },
                        label = {
                            Text(
                                if (isCustomInterval) {
                                    "Custom (${formatIntervalLabel(prefs.autoIntervalMs)})"
                                } else {
                                    "Custom"
                                }
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Rounded.Tune,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Start / Pause / Resume / Stop Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    when (autoState.status) {
                        AutoCountStatus.STOPPED -> {
                            FilledTonalButton(
                                onClick = onStartAuto,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Start Auto Counting")
                            }
                        }

                        AutoCountStatus.RUNNING -> {
                            Button(
                                onClick = onPauseAuto,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Rounded.Pause, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Pause")
                            }
                            OutlinedButton(
                                onClick = onStopAuto,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Rounded.Stop, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Stop")
                            }
                        }

                        AutoCountStatus.PAUSED -> {
                            Button(
                                onClick = onResumeAuto,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Resume")
                            }
                            OutlinedButton(
                                onClick = onStopAuto,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Rounded.Stop, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Stop")
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset Counter?") },
            text = {
                Text("Reset the count for \"${selectedZikr.name}\" back to 0?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResetDialog = false
                        onReset()
                    }
                ) {
                    Text("Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showCustomIntervalDialog) {
        CustomIntervalDialog(
            currentIntervalMs = prefs.autoIntervalMs,
            onDismiss = { showCustomIntervalDialog = false },
            onConfirm = { newMs ->
                showCustomIntervalDialog = false
                onIntervalSelected(newMs)
            }
        )
    }
}

@Composable
private fun MetricItem(
    label: String,
    value: String
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
