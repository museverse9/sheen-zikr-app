package com.sheen.zikr.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ZikrEditorDialog(
    title: String,
    initialName: String = "",
    initialTarget: Int = 33,
    confirmLabel: String = "Save",
    onDismiss: () -> Unit,
    onConfirm: (name: String, target: Int) -> Unit
) {
    var name by remember(initialName) { mutableStateOf(initialName) }
    var targetText by remember(initialTarget) { mutableStateOf(initialTarget.toString()) }
    var nameError by remember { mutableStateOf<String?>(null) }
    var targetError by remember { mutableStateOf<String?>(null) }

    val quickTargets = listOf(33, 100, 313, 1000)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                val isArabic = containsArabicScript(name)
                CompositionLocalProvider(
                    LocalLayoutDirection provides if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
                ) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = {
                            name = it
                            nameError = null
                        },
                        label = { Text("Zikr Name") },
                        placeholder = { Text("e.g. سُبْحَانَ اللَّهِ or SubhanAllah") },
                        isError = nameError != null,
                        supportingText = nameError?.let { msg -> { Text(msg) } },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = targetText,
                    onValueChange = { input ->
                        if (input.all { it.isDigit() } && input.length <= 6) {
                            targetText = input
                            targetError = null
                        }
                    },
                    label = { Text("Target Repetitions") },
                    placeholder = { Text("33") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = targetError != null,
                    supportingText = targetError?.let { msg -> { Text(msg) } },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    quickTargets.forEach { preset ->
                        FilterChip(
                            selected = targetText == preset.toString(),
                            onClick = {
                                targetText = preset.toString()
                                targetError = null
                            },
                            label = { Text(preset.toString()) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val trimmed = name.trim()
                    val parsedTarget = targetText.toIntOrNull()
                    var valid = true
                    if (trimmed.isEmpty()) {
                        nameError = "Please enter a Zikr name"
                        valid = false
                    }
                    if (parsedTarget == null || parsedTarget <= 0) {
                        targetError = "Enter a number greater than 0"
                        valid = false
                    }
                    if (valid && parsedTarget != null) {
                        onConfirm(trimmed, parsedTarget)
                    }
                }
            ) {
                Text(confirmLabel)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun CustomIntervalDialog(
    currentIntervalMs: Long,
    onDismiss: () -> Unit,
    onConfirm: (Long) -> Unit
) {
    val initialSeconds = if (currentIntervalMs % 1000L == 0L) {
        (currentIntervalMs / 1000L).toString()
    } else {
        String.format("%.1f", currentIntervalMs / 1000.0)
    }
    var secondsText by remember { mutableStateOf(initialSeconds) }
    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Custom Interval",
                style = MaterialTheme.typography.headlineMedium
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Set how many seconds between each automatic count (0.5 to 300 seconds).",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = secondsText,
                    onValueChange = { input ->
                        if (input.matches(Regex("^\\d*\\.?\\d{0,1}$"))) {
                            secondsText = input
                            errorText = null
                        }
                    },
                    label = { Text("Seconds") },
                    placeholder = { Text("e.g. 2.5 or 10") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    isError = errorText != null,
                    supportingText = errorText?.let { msg -> { Text(msg) } },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val secs = secondsText.toDoubleOrNull()
                    if (secs == null || secs < 0.5 || secs > 300.0) {
                        errorText = "Enter a value between 0.5 and 300"
                    } else {
                        onConfirm((secs * 1000.0).toLong())
                    }
                }
            ) {
                Text("Apply")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
