package com.sheen.zikr.ui.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.widget.RemoteViews
import com.sheen.zikr.R
import com.sheen.zikr.SheenApplication
import com.sheen.zikr.data.local.ZikrDailyLogEntity
import com.sheen.zikr.data.local.ZikrEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SheenWidgetActions {
    const val ACTION_INCREMENT = "com.sheen.zikr.widget.ACTION_INCREMENT"
    const val ACTION_PREV_ZIKR = "com.sheen.zikr.widget.ACTION_PREV_ZIKR"
    const val ACTION_NEXT_ZIKR = "com.sheen.zikr.widget.ACTION_NEXT_ZIKR"
    const val ACTION_TOGGLE_AUTO = "com.sheen.zikr.widget.ACTION_TOGGLE_AUTO"
    const val ACTION_AUTO_TICK = "com.sheen.zikr.widget.ACTION_AUTO_TICK"
}

private object WidgetAutoPrefs {
    private const val PREF_NAME = "sheen_widget_auto_prefs"
    private const val KEY_ENABLED = "auto_enabled"
    private const val KEY_INTERVAL_IDX = "auto_interval_idx"

    // Quick home-screen auto intervals: 1s, 2s, 3s, 5s
    val intervalsMs = longArrayOf(1000L, 2000L, 3000L, 5000L)

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun intervalMs(context: Context): Long {
        val idx = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_INTERVAL_IDX, 0).coerceIn(0, intervalsMs.lastIndex)
        return intervalsMs[idx]
    }

    fun cycleInterval(context: Context): Long {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val curIdx = prefs.getInt(KEY_INTERVAL_IDX, 0)
        val nextIdx = (curIdx + 1) % intervalsMs.size
        prefs.edit().putInt(KEY_INTERVAL_IDX, nextIdx).apply()
        return intervalsMs[nextIdx]
    }
}

private fun buildActionIntent(context: Context, action: String): PendingIntent {
    val intent = Intent(context, SheenWidgetReceiver::class.java).apply {
        this.action = action
    }
    return PendingIntent.getBroadcast(
        context,
        action.hashCode(),
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

private fun scheduleWidgetAutoAlarm(context: Context, intervalMs: Long) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
    val pi = buildActionIntent(context, SheenWidgetActions.ACTION_AUTO_TICK)
    alarmManager.cancel(pi)
    alarmManager.setExactAndAllowWhileIdle(
        AlarmManager.ELAPSED_REALTIME_WAKEUP,
        SystemClock.elapsedRealtime() + intervalMs,
        pi
    )
}

private fun cancelWidgetAutoAlarm(context: Context) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
    val pi = buildActionIntent(context, SheenWidgetActions.ACTION_AUTO_TICK)
    alarmManager.cancel(pi)
}

fun refreshAllSheenWidgets(context: Context) {
    val app = context.applicationContext as? SheenApplication ?: return
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    scope.launch {
        val zikrList: List<ZikrEntity> = runCatching { app.zikrRepository.allZikr.first() }.getOrDefault(emptyList())
        val prefs = runCatching { app.preferencesRepository.preferencesFlow.first() }.getOrNull()
        val logs: List<ZikrDailyLogEntity> = runCatching { app.zikrRepository.allDailyLogs.first() }.getOrDefault(emptyList())

        val selected = zikrList.firstOrNull { it.id == prefs?.selectedZikrId } ?: zikrList.firstOrNull()
        val autoEnabled = WidgetAutoPrefs.isEnabled(context)
        val autoSec = (WidgetAutoPrefs.intervalMs(context) / 1000L).coerceAtLeast(1L)
        val autoLabel = if (autoEnabled) "Auto: ${autoSec}s (Tap)" else "Auto: Off"

        val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val todayCounts = logs.filter { it.dateKey == todayKey }
            .groupBy { it.zikrId }
            .mapValues { (_, list) -> list.sumOf { it.count } }

        val top3 = zikrList
            .map { z -> z.name to (todayCounts[z.id] ?: 0) }
            .sortedByDescending { it.second }
            .take(3)

        val appWidgetManager = AppWidgetManager.getInstance(context)

        // Update 2x2 widgets
        val ids2x2 = appWidgetManager.getAppWidgetIds(ComponentName(context, SheenWidget2x2Provider::class.java))
        if (ids2x2.isNotEmpty()) {
            val rv2x2 = RemoteViews(context.packageName, R.layout.widget_sheen_2x2).apply {
                setTextViewText(R.id.tv_zikr_title, selected?.name ?: "Sheen")
                setTextViewText(R.id.tv_counter_value, (selected?.displayLapCount ?: 0).toString())
                setTextViewText(R.id.btn_auto_toggle, autoLabel)
                setOnClickPendingIntent(R.id.btn_prev_zikr, buildActionIntent(context, SheenWidgetActions.ACTION_PREV_ZIKR))
                setOnClickPendingIntent(R.id.btn_next_zikr, buildActionIntent(context, SheenWidgetActions.ACTION_NEXT_ZIKR))
                setOnClickPendingIntent(R.id.tv_counter_value, buildActionIntent(context, SheenWidgetActions.ACTION_INCREMENT))
                setOnClickPendingIntent(R.id.btn_auto_toggle, buildActionIntent(context, SheenWidgetActions.ACTION_TOGGLE_AUTO))
            }
            appWidgetManager.updateAppWidget(ids2x2, rv2x2)
        }

        // Update 4x2 widgets
        val ids4x2 = appWidgetManager.getAppWidgetIds(ComponentName(context, SheenWidget4x2Provider::class.java))
        if (ids4x2.isNotEmpty()) {
            val line1 = top3.getOrNull(0)?.let { "1. ${it.first} : ${it.second}" } ?: "1. — : 0"
            val line2 = top3.getOrNull(1)?.let { "2. ${it.first} : ${it.second}" } ?: "2. — : 0"
            val line3 = top3.getOrNull(2)?.let { "3. ${it.first} : ${it.second}" } ?: "3. — : 0"

            val rv4x2 = RemoteViews(context.packageName, R.layout.widget_sheen_4x2).apply {
                setTextViewText(R.id.tv_zikr_title_4x2, selected?.name ?: "Sheen")
                setTextViewText(R.id.tv_counter_value_4x2, (selected?.displayLapCount ?: 0).toString())
                setTextViewText(R.id.btn_auto_toggle_4x2, autoLabel)
                setTextViewText(R.id.tv_day_stats_header, "$todayKey • Top 3")
                setTextViewText(R.id.tv_top_zikr_1, line1)
                setTextViewText(R.id.tv_top_zikr_2, line2)
                setTextViewText(R.id.tv_top_zikr_3, line3)

                setOnClickPendingIntent(R.id.btn_prev_zikr_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_PREV_ZIKR))
                setOnClickPendingIntent(R.id.btn_next_zikr_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_NEXT_ZIKR))
                setOnClickPendingIntent(R.id.tv_counter_value_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_INCREMENT))
                setOnClickPendingIntent(R.id.btn_auto_toggle_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_TOGGLE_AUTO))
            }
            appWidgetManager.updateAppWidget(ids4x2, rv4x2)
        }
    }
}

class SheenWidget2x2Provider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        refreshAllSheenWidgets(context)
    }

    override fun onEnabled(context: Context) {
        refreshAllSheenWidgets(context)
    }
}

class SheenWidget4x2Provider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        refreshAllSheenWidgets(context)
    }

    override fun onEnabled(context: Context) {
        refreshAllSheenWidgets(context)
    }
}

class SheenWidgetReceiver : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return
        val app = context.applicationContext as? SheenApplication ?: return
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        when (action) {
            SheenWidgetActions.ACTION_INCREMENT, SheenWidgetActions.ACTION_AUTO_TICK -> {
                scope.launch {
                    val list = runCatching { app.zikrRepository.allZikr.first() }.getOrDefault(emptyList())
                    val prefs = runCatching { app.preferencesRepository.preferencesFlow.first() }.getOrNull()
                    val cur = list.firstOrNull { it.id == prefs?.selectedZikrId } ?: list.firstOrNull()
                    if (cur != null) {
                        val nextCount = cur.currentCount + 1
                        val nextRounds = if (cur.targetCount > 0) nextCount / cur.targetCount else 0
                        val roundDelta = if (nextRounds > cur.rounds) 1 else 0
                        app.zikrRepository.updateProgress(
                            id = cur.id,
                            currentCount = nextCount,
                            completedRounds = nextRounds,
                            dailyCountDelta = 1,
                            dailyRoundDelta = roundDelta
                        )
                    }
                    refreshAllSheenWidgets(context)
                    if (action == SheenWidgetActions.ACTION_AUTO_TICK && WidgetAutoPrefs.isEnabled(context)) {
                        scheduleWidgetAutoAlarm(context, WidgetAutoPrefs.intervalMs(context))
                    }
                }
            }

            SheenWidgetActions.ACTION_PREV_ZIKR, SheenWidgetActions.ACTION_NEXT_ZIKR -> {
                val delta = if (action == SheenWidgetActions.ACTION_PREV_ZIKR) -1 else 1
                scope.launch {
                    val list = runCatching { app.zikrRepository.allZikr.first() }.getOrDefault(emptyList())
                    if (list.size > 1) {
                        val prefs = runCatching { app.preferencesRepository.preferencesFlow.first() }.getOrNull()
                        val curIdx = list.indexOfFirst { it.id == prefs?.selectedZikrId }.coerceAtLeast(0)
                        val nextIdx = ((curIdx + delta) % list.size + list.size) % list.size
                        app.preferencesRepository.setSelectedZikrId(list[nextIdx].id)
                    }
                    refreshAllSheenWidgets(context)
                }
            }

            SheenWidgetActions.ACTION_TOGGLE_AUTO -> {
                val wasEnabled = WidgetAutoPrefs.isEnabled(context)
                if (!wasEnabled) {
                    WidgetAutoPrefs.setEnabled(context, true)
                    val interval = WidgetAutoPrefs.intervalMs(context)
                    scheduleWidgetAutoAlarm(context, interval)
                } else {
                    val curInterval = WidgetAutoPrefs.intervalMs(context)
                    if (curInterval < WidgetAutoPrefs.intervalsMs.last()) {
                        val nextInterval = WidgetAutoPrefs.cycleInterval(context)
                        scheduleWidgetAutoAlarm(context, nextInterval)
                    } else {
                        WidgetAutoPrefs.setEnabled(context, false)
                        WidgetAutoPrefs.cycleInterval(context) // wraps back to first interval for next enable
                        cancelWidgetAutoAlarm(context)
                    }
                }
                refreshAllSheenWidgets(context)
            }
        }
    }
}
