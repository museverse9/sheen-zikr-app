package com.sheen.zikr.ui.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.RemoteViews
import com.sheen.zikr.R
import com.sheen.zikr.SheenApplication
import com.sheen.zikr.data.local.ZikrDailyLogEntity
import com.sheen.zikr.data.local.ZikrEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SheenWidgetActions {
    const val ACTION_INCREMENT = "com.sheen.zikr.widget.ACTION_INCREMENT"
    const val ACTION_PREV_ZIKR = "com.sheen.zikr.widget.ACTION_PREV_ZIKR"
    const val ACTION_NEXT_ZIKR = "com.sheen.zikr.widget.ACTION_NEXT_ZIKR"
    const val ACTION_AUTO_DEC = "com.sheen.zikr.widget.ACTION_AUTO_DEC"
    const val ACTION_AUTO_INC = "com.sheen.zikr.widget.ACTION_AUTO_INC"
    const val ACTION_AUTO_TOGGLE = "com.sheen.zikr.widget.ACTION_AUTO_TOGGLE"
    const val ACTION_AUTO_TICK = "com.sheen.zikr.widget.ACTION_AUTO_TICK"
}

private object WidgetAutoPrefs {
    private const val PREF_NAME = "sheen_widget_auto_prefs"
    private const val KEY_ENABLED = "auto_enabled"
    private const val KEY_DELAY_MS = "auto_delay_ms"
    private const val KEY_RUN_TOKEN = "auto_run_token"

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, enabled).commit()
    }

    fun delayMs(context: Context): Long {
        val v = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getLong(KEY_DELAY_MS, 2000L)
        return v.coerceIn(500L, 60_000L)
    }

    fun setDelayMs(context: Context, ms: Long) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putLong(KEY_DELAY_MS, ms.coerceIn(500L, 60_000L)).commit()
    }

    fun nextRunToken(context: Context): Long {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val next = prefs.getLong(KEY_RUN_TOKEN, 0L) + 1L
        prefs.edit().putLong(KEY_RUN_TOKEN, next).commit()
        return next
    }

    fun currentRunToken(context: Context): Long =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getLong(KEY_RUN_TOKEN, 0L)
}

private object WidgetAutoTicker {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var activeRunnable: Runnable? = null

    fun start(context: Context, delayMs: Long) {
        stop(context)
        val appCtx = context.applicationContext
        val token = WidgetAutoPrefs.nextRunToken(appCtx)
        WidgetAutoPrefs.setEnabled(appCtx, true)

        scheduleBackupAlarm(appCtx, delayMs, token)

        val runnable = object : Runnable {
            override fun run() {
                if (!WidgetAutoPrefs.isEnabled(appCtx) || WidgetAutoPrefs.currentRunToken(appCtx) != token) {
                    return
                }
                val interval = WidgetAutoPrefs.delayMs(appCtx)
                val app = appCtx as? SheenApplication ?: return
                CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                    val roundCompleted = incrementActiveZikrFromWidget(app)
                    if (roundCompleted) {
                        WidgetAutoPrefs.setEnabled(appCtx, false)
                        cancelBackupAlarm(appCtx)
                    } else if (WidgetAutoPrefs.isEnabled(appCtx) && WidgetAutoPrefs.currentRunToken(appCtx) == token) {
                        scheduleBackupAlarm(appCtx, interval, token)
                        mainHandler.postDelayed(this@Runnable, interval)
                    }
                    refreshAllSheenWidgets(appCtx)
                }
            }
        }
        activeRunnable = runnable
        mainHandler.postDelayed(runnable, delayMs)
    }

    fun stop(context: Context) {
        val appCtx = context.applicationContext
        WidgetAutoPrefs.setEnabled(appCtx, false)
        WidgetAutoPrefs.nextRunToken(appCtx)
        activeRunnable?.let { mainHandler.removeCallbacks(it) }
        activeRunnable = null
        cancelBackupAlarm(appCtx)
    }

    fun scheduleBackupAlarm(context: Context, delayMs: Long, token: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val pi = buildActionIntent(context, SheenWidgetActions.ACTION_AUTO_TICK, token)
        alarmManager.cancel(pi)
        val triggerAt = SystemClock.elapsedRealtime() + delayMs.coerceIn(500L, 60_000L)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi)
            } else {
                alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi)
            }
        } catch (_: SecurityException) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi)
            } else {
                alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi)
            }
        }
    }

    private fun cancelBackupAlarm(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val pi = buildActionIntent(context, SheenWidgetActions.ACTION_AUTO_TICK)
        alarmManager.cancel(pi)
    }
}

private fun formatWidgetDelay(ms: Long): String {
    val tenths = (ms / 100L).toInt()
    return if (tenths % 10 == 0) {
        "${tenths / 10}s"
    } else {
        String.format(Locale.US, "%.1fs", ms / 1000.0)
    }
}

private fun stepDelayDown(currentMs: Long): Long {
    return when {
        currentMs > 10_000L -> (currentMs - 5_000L).coerceAtLeast(10_000L)
        currentMs > 5_000L -> (currentMs - 1_000L).coerceAtLeast(5_000L)
        else -> (currentMs - 500L).coerceAtLeast(500L)
    }
}

private fun stepDelayUp(currentMs: Long): Long {
    return when {
        currentMs < 5_000L -> (currentMs + 500L).coerceAtMost(5_000L)
        currentMs < 10_000L -> (currentMs + 1_000L).coerceAtMost(10_000L)
        else -> (currentMs + 5_000L).coerceAtMost(60_000L)
    }
}

private fun buildActionIntent(
    context: Context,
    action: String,
    token: Long = 0L
): PendingIntent {
    val intent = Intent(context, SheenWidget2x2Provider::class.java).apply {
        `package` = context.packageName
        this.action = action
        if (token > 0L) {
            putExtra("extra_run_token", token)
        }
    }
    val reqCode = when (action) {
        SheenWidgetActions.ACTION_INCREMENT -> 9101
        SheenWidgetActions.ACTION_PREV_ZIKR -> 9102
        SheenWidgetActions.ACTION_NEXT_ZIKR -> 9103
        SheenWidgetActions.ACTION_AUTO_DEC -> 9104
        SheenWidgetActions.ACTION_AUTO_INC -> 9105
        SheenWidgetActions.ACTION_AUTO_TOGGLE -> 9106
        SheenWidgetActions.ACTION_AUTO_TICK -> 9107
        else -> 9199
    }
    return PendingIntent.getBroadcast(
        context,
        reqCode,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

private fun applyAutoTimerControls(
    rv: RemoteViews,
    delayMs: Long,
    isEnabled: Boolean,
    decId: Int,
    delayId: Int,
    incId: Int,
    toggleId: Int
) {
    rv.setTextViewText(delayId, formatWidgetDelay(delayMs))
    rv.setTextViewText(toggleId, if (isEnabled) "⏸" else "▶")
    rv.setInt(
        toggleId,
        "setBackgroundResource",
        if (isEnabled) R.drawable.widget_opt_active else R.drawable.widget_opt_idle
    )
    rv.setTextColor(
        toggleId,
        if (isEnabled) 0xFF062422.toInt() else 0xFFD4AF37.toInt()
    )
    rv.setInt(decId, "setBackgroundResource", R.drawable.widget_opt_idle)
    rv.setInt(incId, "setBackgroundResource", R.drawable.widget_opt_idle)
    rv.setInt(delayId, "setBackgroundResource", R.drawable.widget_opt_idle)
}

private fun isGoalMilestoneCount(count: Int): Boolean {
    if (count <= 0) return false
    if (count == 33 || count == 66 || count == 99) return true
    return count >= 100 && count % 100 == 0
}

private suspend fun incrementActiveZikrFromWidget(app: SheenApplication): Boolean {
    val list = runCatching { app.zikrRepository.allZikr.first() }.getOrDefault(emptyList())
    val prefs = runCatching { app.preferencesRepository.preferencesFlow.first() }.getOrNull()
    val cur = list.firstOrNull { it.id == prefs?.selectedZikrId } ?: list.firstOrNull() ?: return false

    val nextCount = cur.currentCount + 1
    val completedRoundNow = cur.targetCount > 0 && nextCount % cur.targetCount == 0
    val nextRounds = if (cur.targetCount > 0) nextCount / cur.targetCount else 0
    val roundDelta = if (completedRoundNow) 1 else 0

    app.zikrRepository.updateProgress(
        id = cur.id,
        currentCount = nextCount,
        completedRounds = nextRounds,
        dailyCountDelta = 1,
        dailyRoundDelta = roundDelta
    )

    if (prefs != null) {
        val hitMilestone = isGoalMilestoneCount(nextCount)
        if (hitMilestone) {
            if (prefs.countSoundEnabled || prefs.completionSoundEnabled) {
                app.soundManager.playHundredMilestoneSound(prefs.soundVolume)
            }
            if (prefs.hapticEnabled) {
                app.hapticManager.hundredMilestone()
            }
        } else if (completedRoundNow) {
            if (prefs.completionSoundEnabled) {
                app.soundManager.playCompletionSound(prefs.soundVolume)
            }
            if (prefs.hapticEnabled) {
                app.hapticManager.roundComplete()
            }
        } else {
            if (prefs.countSoundEnabled) {
                app.soundManager.playCountSound(prefs.selectedSound, prefs.soundVolume)
            }
            if (prefs.hapticEnabled) {
                app.hapticManager.tick()
            }
        }
    }

    return completedRoundNow
}

fun refreshAllSheenWidgets(context: Context) {
    val app = context.applicationContext as? SheenApplication ?: return
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    scope.launch {
        val zikrList: List<ZikrEntity> = runCatching { app.zikrRepository.allZikr.first() }.getOrDefault(emptyList())
        val prefs = runCatching { app.preferencesRepository.preferencesFlow.first() }.getOrNull()
        val logs: List<ZikrDailyLogEntity> = runCatching { app.zikrRepository.allDailyLogs.first() }.getOrDefault(emptyList())

        val selected = zikrList.firstOrNull { it.id == prefs?.selectedZikrId } ?: zikrList.firstOrNull()
        val delayMs = WidgetAutoPrefs.delayMs(context)
        val autoEnabled = WidgetAutoPrefs.isEnabled(context)

        val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val todayCounts = logs.filter { it.dateKey == todayKey }
            .groupBy { it.zikrId }
            .mapValues { (_, list) -> list.sumOf { it.count } }

        val rankedTop3 = zikrList
            .map { z ->
                val dayCount = todayCounts[z.id] ?: 0
                Pair(z.name, dayCount)
            }
            .sortedByDescending { it.second }
            .take(3)

        val appWidgetManager = AppWidgetManager.getInstance(context)

        val ids2x2 = runCatching {
            appWidgetManager.getAppWidgetIds(ComponentName(context, SheenWidget2x2Provider::class.java))
        }.getOrDefault(intArrayOf())
        if (ids2x2.isNotEmpty()) {
            val rv2x2 = RemoteViews(context.packageName, R.layout.widget_sheen_2x2).apply {
                setTextViewText(R.id.tv_zikr_title, selected?.name ?: "Sheen")
                setTextViewText(R.id.tv_counter_value, (selected?.displayLapCount ?: 0).toString())
                applyAutoTimerControls(
                    this, delayMs, autoEnabled,
                    R.id.btn_auto_dec, R.id.tv_auto_delay, R.id.btn_auto_inc, R.id.btn_auto_toggle
                )
                setOnClickPendingIntent(R.id.btn_prev_zikr, buildActionIntent(context, SheenWidgetActions.ACTION_PREV_ZIKR))
                setOnClickPendingIntent(R.id.btn_next_zikr, buildActionIntent(context, SheenWidgetActions.ACTION_NEXT_ZIKR))
                setOnClickPendingIntent(R.id.tv_counter_value, buildActionIntent(context, SheenWidgetActions.ACTION_INCREMENT))
                setOnClickPendingIntent(R.id.btn_auto_dec, buildActionIntent(context, SheenWidgetActions.ACTION_AUTO_DEC))
                setOnClickPendingIntent(R.id.btn_auto_inc, buildActionIntent(context, SheenWidgetActions.ACTION_AUTO_INC))
                setOnClickPendingIntent(R.id.btn_auto_toggle, buildActionIntent(context, SheenWidgetActions.ACTION_AUTO_TOGGLE))
            }
            appWidgetManager.updateAppWidget(ids2x2, rv2x2)
        }

        val ids4x2 = runCatching {
            appWidgetManager.getAppWidgetIds(ComponentName(context, SheenWidget4x2Provider::class.java))
        }.getOrDefault(intArrayOf())
        if (ids4x2.isNotEmpty()) {
            fun formatTopEntry(idx: Int): String {
                val entry = rankedTop3.getOrNull(idx) ?: return "— : 0"
                val fires = if (entry.second > 0) "🔥".repeat((3 - idx).coerceAtLeast(1)) + " " else ""
                return "‎$fires${entry.first}‎ : ${entry.second}"
            }

            val rv4x2 = RemoteViews(context.packageName, R.layout.widget_sheen_4x2).apply {
                setTextViewText(R.id.tv_zikr_title_4x2, selected?.name ?: "Sheen")
                setTextViewText(R.id.tv_counter_value_4x2, (selected?.displayLapCount ?: 0).toString())
                applyAutoTimerControls(
                    this, delayMs, autoEnabled,
                    R.id.btn_auto_dec_4x2, R.id.tv_auto_delay_4x2, R.id.btn_auto_inc_4x2, R.id.btn_auto_toggle_4x2
                )
                setTextViewText(R.id.tv_day_stats_header, "$todayKey • Top 3")
                setTextViewText(R.id.tv_top_zikr_1, formatTopEntry(0))
                setTextViewText(R.id.tv_top_zikr_2, formatTopEntry(1))
                setTextViewText(R.id.tv_top_zikr_3, formatTopEntry(2))

                setOnClickPendingIntent(R.id.btn_prev_zikr_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_PREV_ZIKR))
                setOnClickPendingIntent(R.id.btn_next_zikr_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_NEXT_ZIKR))
                setOnClickPendingIntent(R.id.tv_counter_value_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_INCREMENT))
                setOnClickPendingIntent(R.id.btn_auto_dec_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_AUTO_DEC))
                setOnClickPendingIntent(R.id.btn_auto_inc_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_AUTO_INC))
                setOnClickPendingIntent(R.id.btn_auto_toggle_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_AUTO_TOGGLE))
            }
            appWidgetManager.updateAppWidget(ids4x2, rv4x2)
        }
    }
}

class SheenWidget2x2Provider : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val act = intent.action ?: return
        if (act == AppWidgetManager.ACTION_APPWIDGET_UPDATE || act == AppWidgetManager.ACTION_APPWIDGET_ENABLED) {
            return
        }
        handleWidgetAction(context, intent)
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        refreshAllSheenWidgets(context)
    }

    override fun onEnabled(context: Context) {
        refreshAllSheenWidgets(context)
    }

    override fun onDisabled(context: Context) {
        WidgetAutoTicker.stop(context)
    }
}

class SheenWidget4x2Provider : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val act = intent.action ?: return
        if (act == AppWidgetManager.ACTION_APPWIDGET_UPDATE || act == AppWidgetManager.ACTION_APPWIDGET_ENABLED) {
            return
        }
        handleWidgetAction(context, intent)
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        refreshAllSheenWidgets(context)
    }

    override fun onEnabled(context: Context) {
        refreshAllSheenWidgets(context)
    }

    override fun onDisabled(context: Context) {
        WidgetAutoTicker.stop(context)
    }
}

private fun handleWidgetAction(context: Context, intent: Intent) {
    val action = intent.action ?: return
    val app = context.applicationContext as? SheenApplication ?: return
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    when (action) {
        SheenWidgetActions.ACTION_INCREMENT -> {
            WidgetAutoTicker.stop(context)
            scope.launch {
                incrementActiveZikrFromWidget(app)
                refreshAllSheenWidgets(context)
            }
        }

        SheenWidgetActions.ACTION_PREV_ZIKR, SheenWidgetActions.ACTION_NEXT_ZIKR -> {
            val delta = if (action == SheenWidgetActions.ACTION_PREV_ZIKR) -1 else 1
            WidgetAutoTicker.stop(context)
            scope.launch {
                val list = runCatching { app.zikrRepository.allZikr.first() }.getOrDefault(emptyList())
                if (list.size > 1) {
                    val prefs = runCatching { app.preferencesRepository.preferencesFlow.first() }.getOrNull()
                    val curIdx = list.indexOfFirst { it.id == prefs?.selectedZikrId }.coerceAtLeast(0)
                    val nextIdx = ((curIdx + delta) % list.size + list.size) % list.size
                    app.preferencesRepository.setSelectedZikrId(list[nextIdx].id)
                }
                refreshAllSheenWidgets(context)
            }
        }

        SheenWidgetActions.ACTION_AUTO_DEC -> {
            val nextDelay = stepDelayDown(WidgetAutoPrefs.delayMs(context))
            WidgetAutoPrefs.setDelayMs(context, nextDelay)
            if (WidgetAutoPrefs.isEnabled(context)) {
                WidgetAutoTicker.start(context, nextDelay)
            }
            refreshAllSheenWidgets(context)
        }

        SheenWidgetActions.ACTION_AUTO_INC -> {
            val nextDelay = stepDelayUp(WidgetAutoPrefs.delayMs(context))
            WidgetAutoPrefs.setDelayMs(context, nextDelay)
            if (WidgetAutoPrefs.isEnabled(context)) {
                WidgetAutoTicker.start(context, nextDelay)
            }
            refreshAllSheenWidgets(context)
        }

        SheenWidgetActions.ACTION_AUTO_TOGGLE -> {
            if (WidgetAutoPrefs.isEnabled(context)) {
                WidgetAutoTicker.stop(context)
                refreshAllSheenWidgets(context)
            } else {
                val delayMs = WidgetAutoPrefs.delayMs(context)
                WidgetAutoTicker.start(context, delayMs)
                refreshAllSheenWidgets(context)
            }
        }

        SheenWidgetActions.ACTION_AUTO_TICK -> {
            if (!WidgetAutoPrefs.isEnabled(context)) {
                WidgetAutoTicker.stop(context)
                refreshAllSheenWidgets(context)
                return
            }
            val delayMs = WidgetAutoPrefs.delayMs(context)
            val token = WidgetAutoPrefs.currentRunToken(context)
            scope.launch {
                val roundCompleted = incrementActiveZikrFromWidget(app)
                if (roundCompleted) {
                    WidgetAutoTicker.stop(context)
                } else if (WidgetAutoPrefs.isEnabled(context)) {
                    WidgetAutoTicker.scheduleBackupAlarm(context, delayMs, token)
                }
                refreshAllSheenWidgets(context)
            }
        }
    }
}
