package com.sheen.zikr.ui.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.widget.RemoteViews
import com.sheen.zikr.R
import com.sheen.zikr.SheenApplication
import com.sheen.zikr.data.local.ZikrDailyLogEntity
import com.sheen.zikr.data.local.ZikrEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SheenWidgetActions {
    const val ACTION_INCREMENT = "com.sheen.zikr.widget.ACTION_INCREMENT"
    const val ACTION_PREV_ZIKR = "com.sheen.zikr.widget.ACTION_PREV_ZIKR"
    const val ACTION_NEXT_ZIKR = "com.sheen.zikr.widget.ACTION_NEXT_ZIKR"
    const val ACTION_SET_AUTO_SEC = "com.sheen.zikr.widget.ACTION_SET_AUTO_SEC"
    const val EXTRA_AUTO_SEC = "extra_auto_sec"
    const val EXTRA_AUTO_SLOT_IDX = "extra_auto_slot_idx"
    const val ACTION_AUTO_TICK = "com.sheen.zikr.widget.ACTION_AUTO_TICK"
}

private object WidgetAutoPrefs {
    private const val PREF_NAME = "sheen_widget_auto_prefs"
    private const val KEY_ENABLED = "auto_enabled"
    private const val KEY_ACTIVE_SEC = "active_auto_sec"
    private const val KEY_OPTIONS_CSV = "options_auto_csv"

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun activeSec(context: Context): Int {
        val v = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).getInt(KEY_ACTIVE_SEC, 5)
        return v.coerceIn(1, 120)
    }

    fun setActiveSec(context: Context, sec: Int) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putInt(KEY_ACTIVE_SEC, sec.coerceIn(1, 120)).apply()
    }

    fun optionsSec(context: Context): List<Int> {
        val csv = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_OPTIONS_CSV, "3,5,7") ?: "3,5,7"
        val parsed = csv.split(",").mapNotNull { it.trim().toIntOrNull()?.coerceIn(1, 120) }
        return if (parsed.size >= 3) parsed.take(3) else listOf(3, 5, 7)
    }

    fun setOptionsSec(context: Context, opts: List<Int>, selectedSec: Int) {
        val cleanOpts = if (opts.size >= 3) opts.take(3).map { it.coerceIn(1, 120) } else listOf(3, 5, 7)
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_OPTIONS_CSV, cleanOpts.joinToString(","))
            .putInt(KEY_ACTIVE_SEC, selectedSec.coerceIn(1, 120))
            .apply()
    }
}

fun syncWidgetAutoConfigFromApp(context: Context, options: List<Int>, activeSec: Int) {
    WidgetAutoPrefs.setOptionsSec(context, options, activeSec)
    refreshAllSheenWidgets(context)
}

private fun buildActionIntent(
    context: Context,
    action: String,
    sec: Int? = null,
    slotIdx: Int? = null
): PendingIntent {
    val intent = Intent(context, SheenWidgetReceiver::class.java).apply {
        this.action = action
        if (sec != null) {
            putExtra(SheenWidgetActions.EXTRA_AUTO_SEC, sec)
        }
        if (slotIdx != null) {
            putExtra(SheenWidgetActions.EXTRA_AUTO_SLOT_IDX, slotIdx)
        }
    }
    val reqCode = when {
        slotIdx != null -> 9000 + slotIdx * 137
        action == SheenWidgetActions.ACTION_INCREMENT -> 9101
        action == SheenWidgetActions.ACTION_PREV_ZIKR -> 9102
        action == SheenWidgetActions.ACTION_NEXT_ZIKR -> 9103
        action == SheenWidgetActions.ACTION_AUTO_TICK -> 9104
        else -> 9199
    }
    return PendingIntent.getBroadcast(
        context,
        reqCode,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

private fun scheduleWidgetAutoAlarm(context: Context, intervalSec: Int) {
    runCatching {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val pi = buildActionIntent(context, SheenWidgetActions.ACTION_AUTO_TICK)
        alarmManager.cancel(pi)
        val delayMs = (intervalSec.coerceIn(1, 120)) * 1000L
        alarmManager.set(
            AlarmManager.ELAPSED_REALTIME_WAKEUP,
            SystemClock.elapsedRealtime() + delayMs,
            pi
        )
    }
}

private fun cancelWidgetAutoAlarm(context: Context) {
    runCatching {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val pi = buildActionIntent(context, SheenWidgetActions.ACTION_AUTO_TICK)
        alarmManager.cancel(pi)
    }
}

private fun applyAutoOptionStates(
    rv: RemoteViews,
    options: List<Int>,
    activeSec: Int,
    isEnabled: Boolean,
    opt1Id: Int,
    opt2Id: Int,
    opt3Id: Int
) {
    val ids = intArrayOf(opt1Id, opt2Id, opt3Id)
    for (i in 0..2) {
        val sec = options.getOrElse(i) { listOf(3, 5, 7)[i] }
        val isThisActive = isEnabled && (activeSec == sec)
        rv.setTextViewText(ids[i], "${sec}s")
        rv.setInt(
            ids[i],
            "setBackgroundResource",
            if (isThisActive) R.drawable.widget_opt_active else R.drawable.widget_opt_idle
        )
        rv.setTextColor(
            ids[i],
            if (isThisActive) 0xFF062422.toInt() else 0xFFE2D9C5.toInt()
        )
    }
}

private fun isGoalMilestoneCount(count: Int): Boolean {
    if (count <= 0) return false
    if (count == 33 || count == 66 || count == 99) return true
    return count >= 100 && count % 100 == 0
}

private suspend fun incrementActiveZikrFromWidget(app: SheenApplication): Boolean {
    val list = runCatching { app.zikrRepository.allZikr.first() }.getOrDefault(emptyList())
    val prefs = runCatching { app.preferencesRepository.preferencesFlow.first() }.getOrNull()
    val cur = list.firstOrNull { it.id == prefs?.selectedZikrId } ?: list.firstOrNull() ?: return false

    val nextCount = cur.currentCount + 1
    val completedRoundNow = cur.targetCount > 0 && nextCount % cur.targetCount == 0
    val nextRounds = if (cur.targetCount > 0) nextCount / cur.targetCount else 0
    val roundDelta = if (completedRoundNow) 1 else 0

    app.zikrRepository.updateProgress(
        id = cur.id,
        currentCount = nextCount,
        completedRounds = nextRounds,
        dailyCountDelta = 1,
        dailyRoundDelta = roundDelta
    )

    if (prefs != null) {
        val hitMilestone = isGoalMilestoneCount(nextCount)
        if (hitMilestone) {
            if (prefs.countSoundEnabled || prefs.completionSoundEnabled) {
                app.soundManager.playHundredMilestoneSound(prefs.soundVolume)
            }
            if (prefs.hapticEnabled) {
                app.hapticManager.hundredMilestone()
            }
        } else if (completedRoundNow) {
            if (prefs.completionSoundEnabled) {
                app.soundManager.playCompletionSound(prefs.soundVolume)
            }
            if (prefs.hapticEnabled) {
                app.hapticManager.roundComplete()
            }
        } else {
            if (prefs.countSoundEnabled) {
                app.soundManager.playCountSound(prefs.selectedSound, prefs.soundVolume)
            }
            if (prefs.hapticEnabled) {
                app.hapticManager.tick()
            }
        }
    }

    return completedRoundNow
}

fun refreshAllSheenWidgets(context: Context) {
    val app = context.applicationContext as? SheenApplication ?: return
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    scope.launch {
        val zikrList: List<ZikrEntity> = runCatching { app.zikrRepository.allZikr.first() }.getOrDefault(emptyList())
        val prefs = runCatching { app.preferencesRepository.preferencesFlow.first() }.getOrNull()
        val logs: List<ZikrDailyLogEntity> = runCatching { app.zikrRepository.allDailyLogs.first() }.getOrDefault(emptyList())

        val options = prefs?.widgetAutoOptionsSec?.take(3)?.takeIf { it.size == 3 } ?: WidgetAutoPrefs.optionsSec(context)
        val activeSec = prefs?.widgetAutoIntervalSec ?: WidgetAutoPrefs.activeSec(context)
        WidgetAutoPrefs.setOptionsSec(context, options, activeSec)

        val selected = zikrList.firstOrNull { it.id == prefs?.selectedZikrId } ?: zikrList.firstOrNull()
        val autoEnabled = WidgetAutoPrefs.isEnabled(context)

        val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val todayCounts = logs.filter { it.dateKey == todayKey }
            .groupBy { it.zikrId }
            .mapValues { (_, list) -> list.sumOf { it.count } }

        val rankedTop3 = zikrList
            .map { z ->
                val dayCount = todayCounts[z.id] ?: 0
                Pair(z.name, dayCount)
            }
            .sortedByDescending { it.second }
            .take(3)

        val appWidgetManager = AppWidgetManager.getInstance(context)

        val ids2x2 = runCatching {
            appWidgetManager.getAppWidgetIds(ComponentName(context, SheenWidget2x2Provider::class.java))
        }.getOrDefault(intArrayOf())
        if (ids2x2.isNotEmpty()) {
            val rv2x2 = RemoteViews(context.packageName, R.layout.widget_sheen_2x2).apply {
                setTextViewText(R.id.tv_zikr_title, selected?.name ?: "Sheen")
                setTextViewText(R.id.tv_counter_value, (selected?.displayLapCount ?: 0).toString())
                applyAutoOptionStates(
                    this, options, activeSec, autoEnabled,
                    R.id.btn_auto_opt_1, R.id.btn_auto_opt_2, R.id.btn_auto_opt_3
                )
                setOnClickPendingIntent(R.id.btn_prev_zikr, buildActionIntent(context, SheenWidgetActions.ACTION_PREV_ZIKR))
                setOnClickPendingIntent(R.id.btn_next_zikr, buildActionIntent(context, SheenWidgetActions.ACTION_NEXT_ZIKR))
                setOnClickPendingIntent(R.id.tv_counter_value, buildActionIntent(context, SheenWidgetActions.ACTION_INCREMENT))
                setOnClickPendingIntent(R.id.btn_auto_opt_1, buildActionIntent(context, SheenWidgetActions.ACTION_SET_AUTO_SEC, options[0], 0))
                setOnClickPendingIntent(R.id.btn_auto_opt_2, buildActionIntent(context, SheenWidgetActions.ACTION_SET_AUTO_SEC, options[1], 1))
                setOnClickPendingIntent(R.id.btn_auto_opt_3, buildActionIntent(context, SheenWidgetActions.ACTION_SET_AUTO_SEC, options[2], 2))
            }
            appWidgetManager.updateAppWidget(ids2x2, rv2x2)
        }

        val ids4x2 = runCatching {
            appWidgetManager.getAppWidgetIds(ComponentName(context, SheenWidget4x2Provider::class.java))
        }.getOrDefault(intArrayOf())
        if (ids4x2.isNotEmpty()) {
            fun formatTopEntry(idx: Int): String {
                val entry = rankedTop3.getOrNull(idx) ?: return "— : 0"
                val fires = if (entry.second > 0) "🔥".repeat((3 - idx).coerceAtLeast(1)) + " " else ""
                return "‎$fires${entry.first}‎ : ${entry.second}"
            }

            val rv4x2 = RemoteViews(context.packageName, R.layout.widget_sheen_4x2).apply {
                setTextViewText(R.id.tv_zikr_title_4x2, selected?.name ?: "Sheen")
                setTextViewText(R.id.tv_counter_value_4x2, (selected?.displayLapCount ?: 0).toString())
                applyAutoOptionStates(
                    this, options, activeSec, autoEnabled,
                    R.id.btn_auto_opt_1_4x2, R.id.btn_auto_opt_2_4x2, R.id.btn_auto_opt_3_4x2
                )
                setTextViewText(R.id.tv_day_stats_header, "$todayKey • Top 3")
                setTextViewText(R.id.tv_top_zikr_1, formatTopEntry(0))
                setTextViewText(R.id.tv_top_zikr_2, formatTopEntry(1))
                setTextViewText(R.id.tv_top_zikr_3, formatTopEntry(2))

                setOnClickPendingIntent(R.id.btn_prev_zikr_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_PREV_ZIKR))
                setOnClickPendingIntent(R.id.btn_next_zikr_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_NEXT_ZIKR))
                setOnClickPendingIntent(R.id.tv_counter_value_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_INCREMENT))
                setOnClickPendingIntent(R.id.btn_auto_opt_1_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_SET_AUTO_SEC, options[0], 0))
                setOnClickPendingIntent(R.id.btn_auto_opt_2_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_SET_AUTO_SEC, options[1], 1))
                setOnClickPendingIntent(R.id.btn_auto_opt_3_4x2, buildActionIntent(context, SheenWidgetActions.ACTION_SET_AUTO_SEC, options[2], 2))
            }
            appWidgetManager.updateAppWidget(ids4x2, rv4x2)
        }
    }
}

class SheenWidget2x2Provider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        refreshAllSheenWidgets(context)
    }

    override fun onEnabled(context: Context) {
        refreshAllSheenWidgets(context)
    }
}

class SheenWidget4x2Provider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        refreshAllSheenWidgets(context)
    }

    override fun onEnabled(context: Context) {
        refreshAllSheenWidgets(context)
    }
}

class SheenWidgetReceiver : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return
        val app = context.applicationContext as? SheenApplication ?: return
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        when (action) {
            SheenWidgetActions.ACTION_INCREMENT -> {
                // Tapping directly on the counter stops any active widget auto timer, matching main app
                WidgetAutoPrefs.setEnabled(context, false)
                cancelWidgetAutoAlarm(context)
                scope.launch {
                    incrementActiveZikrFromWidget(app)
                    refreshAllSheenWidgets(context)
                }
            }

            SheenWidgetActions.ACTION_AUTO_TICK -> {
                scope.launch {
                    if (!WidgetAutoPrefs.isEnabled(context)) {
                        cancelWidgetAutoAlarm(context)
                        refreshAllSheenWidgets(context)
                        return@launch
                    }
                    val roundCompleted = incrementActiveZikrFromWidget(app)
                    if (roundCompleted) {
                        WidgetAutoPrefs.setEnabled(context, false)
                        cancelWidgetAutoAlarm(context)
                    } else {
                        scheduleWidgetAutoAlarm(context, WidgetAutoPrefs.activeSec(context))
                    }
                    refreshAllSheenWidgets(context)
                }
            }

            SheenWidgetActions.ACTION_PREV_ZIKR, SheenWidgetActions.ACTION_NEXT_ZIKR -> {
                val delta = if (action == SheenWidgetActions.ACTION_PREV_ZIKR) -1 else 1
                WidgetAutoPrefs.setEnabled(context, false)
                cancelWidgetAutoAlarm(context)
                scope.launch {
                    val list = runCatching { app.zikrRepository.allZikr.first() }.getOrDefault(emptyList())
                    if (list.size > 1) {
                        val prefs = runCatching { app.preferencesRepository.preferencesFlow.first() }.getOrNull()
                        val curIdx = list.indexOfFirst { it.id == prefs?.selectedZikrId }.coerceAtLeast(0)
                        val nextIdx = ((curIdx + delta) % list.size + list.size) % list.size
                        app.preferencesRepository.setSelectedZikrId(list[nextIdx].id)
                    }
                    refreshAllSheenWidgets(context)
                }
            }

            SheenWidgetActions.ACTION_SET_AUTO_SEC -> {
                val slotIdx = intent.getIntExtra(SheenWidgetActions.EXTRA_AUTO_SLOT_IDX, -1)
                val latestOptions = WidgetAutoPrefs.optionsSec(context)
                val chosenSec = if (slotIdx in 0..2) {
                    latestOptions[slotIdx]
                } else {
                    intent.getIntExtra(SheenWidgetActions.EXTRA_AUTO_SEC, WidgetAutoPrefs.activeSec(context))
                }.coerceIn(1, 120)

                val wasEnabled = WidgetAutoPrefs.isEnabled(context)
                val curSec = WidgetAutoPrefs.activeSec(context)

                if (wasEnabled && curSec == chosenSec) {
                    WidgetAutoPrefs.setEnabled(context, false)
                    cancelWidgetAutoAlarm(context)
                    refreshAllSheenWidgets(context)
                } else {
                    WidgetAutoPrefs.setActiveSec(context, chosenSec)
                    WidgetAutoPrefs.setEnabled(context, true)
                    scope.launch {
                        runCatching { app.preferencesRepository.setWidgetAutoIntervalSec(chosenSec) }
                        val roundCompleted = incrementActiveZikrFromWidget(app)
                        if (roundCompleted) {
                            WidgetAutoPrefs.setEnabled(context, false)
                            cancelWidgetAutoAlarm(context)
                        } else {
                            scheduleWidgetAutoAlarm(context, chosenSec)
                        }
                        refreshAllSheenWidgets(context)
                    }
                }
            }
        }
    }
}
