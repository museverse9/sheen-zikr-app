package com.sheen.zikr.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "zikr_daily_logs",
    primaryKeys = ["zikrId", "dateKey"],
    foreignKeys = [
        ForeignKey(
            entity = ZikrEntity::class,
            parentColumns = ["id"],
            childColumns = ["zikrId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["zikrId"])]
)
data class ZikrDailyLogEntity(
    val zikrId: Long,
    val dateKey: String, // YYYY-MM-DD local date starting 00:00
    val count: Int = 0,
    val rounds: Int = 0,
    val updatedAt: Long = System.currentTimeMillis()
)
