package com.sheen.zikr.data.local

import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ZikrRepository(
    private val dao: ZikrDao,
    private val dailyLogDao: ZikrDailyLogDao
) {

    val allZikr: Flow<List<ZikrEntity>> = dao.observeAll()

    fun observeHistory(zikrId: Long): Flow<List<ZikrDailyLogEntity>> =
        dailyLogDao.observeForZikr(zikrId)

    private fun todayDateKey(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date())
    }

    suspend fun ensureStarterDataIfEmpty() {
        if (dao.getCount() == 0) {
            val now = System.currentTimeMillis()
            dao.insertAll(
                listOf(
                    ZikrEntity(
                        name = "سُبْحَانَ اللَّهِ",
                        targetCount = 33,
                        currentCount = 0,
                        sortOrder = 0,
                        createdAt = now,
                        updatedAt = now
                    ),
                    ZikrEntity(
                        name = "الْحَمْدُ لِلَّهِ",
                        targetCount = 33,
                        currentCount = 0,
                        sortOrder = 1,
                        createdAt = now + 1,
                        updatedAt = now + 1
                    ),
                    ZikrEntity(
                        name = "اللَّهُ أَكْبَرُ",
                        targetCount = 34,
                        currentCount = 0,
                        sortOrder = 2,
                        createdAt = now + 2,
                        updatedAt = now + 2
                    )
                )
            )
        }
    }

    suspend fun addZikr(name: String, targetCount: Int): Long {
        val nextOrder = dao.getMaxSortOrder() + 1
        val now = System.currentTimeMillis()
        return dao.insert(
            ZikrEntity(
                name = name.trim(),
                targetCount = targetCount.coerceAtLeast(1),
                currentCount = 0,
                completedRounds = 0,
                sortOrder = nextOrder,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun updateZikr(id: Long, name: String, targetCount: Int) {
        dao.updateDetails(
            id = id,
            name = name.trim(),
            targetCount = targetCount.coerceAtLeast(1),
            updatedAt = System.currentTimeMillis()
        )
    }

    suspend fun updateProgress(
        id: Long,
        currentCount: Int,
        completedRounds: Int,
        dailyCountDelta: Int = 0,
        dailyRoundDelta: Int = 0
    ) {
        val now = System.currentTimeMillis()
        dao.updateProgress(
            id = id,
            currentCount = currentCount.coerceAtLeast(0),
            completedRounds = completedRounds.coerceAtLeast(0),
            updatedAt = now
        )
        if (dailyCountDelta != 0 || dailyRoundDelta != 0) {
            val dateKey = todayDateKey()
            val existing = dailyLogDao.getForDay(id, dateKey)
            val nextDailyCount = ((existing?.count ?: 0) + dailyCountDelta).coerceAtLeast(0)
            val nextDailyRounds = ((existing?.rounds ?: 0) + dailyRoundDelta).coerceAtLeast(0)
            dailyLogDao.upsert(
                ZikrDailyLogEntity(
                    zikrId = id,
                    dateKey = dateKey,
                    count = nextDailyCount,
                    rounds = nextDailyRounds,
                    updatedAt = now
                )
            )
        }
    }

    suspend fun deleteZikr(id: Long) {
        dao.deleteById(id)
    }
}
