package com.sheen.zikr.data.local

import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ZikrRepository(
    private val dao: ZikrDao,
    private val dailyLogDao: ZikrDailyLogDao,
    private val hourlyLogDao: ZikrHourlyLogDao
) {

    val allZikr: Flow<List<ZikrEntity>> = dao.observeAll()
    val allDailyLogs: Flow<List<ZikrDailyLogEntity>> = dailyLogDao.observeAll()

    fun observeHistory(zikrId: Long): Flow<List<ZikrDailyLogEntity>> =
        dailyLogDao.observeForZikr(zikrId)

    fun observeHourly(zikrId: Long, dateKey: String): Flow<List<ZikrHourlyLogEntity>> =
        hourlyLogDao.observeForZikrDay(zikrId, dateKey)

    private fun todayDateKey(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date())
    }

    private fun currentHour(): Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    suspend fun ensureStarterDataIfEmpty() {
        if (dao.getCount() == 0) {
            val now = System.currentTimeMillis()
            dao.insertAll(
                listOf(
                    ZikrEntity(name = "سُبْحَانَ اللَّهِ", targetCount = 33, sortOrder = 0, createdAt = now, updatedAt = now),
                    ZikrEntity(name = "الْحَمْدُ لِلَّهِ", targetCount = 33, sortOrder = 1, createdAt = now + 1, updatedAt = now + 1),
                    ZikrEntity(name = "اللَّهُ أَكْبَرُ", targetCount = 34, sortOrder = 2, createdAt = now + 2, updatedAt = now + 2)
                )
            )
        }
    }

    suspend fun addZikr(name: String, targetCount: Int): Long {
        val nextOrder = dao.getMaxSortOrder() + 1
        val now = System.currentTimeMillis()
        return dao.insert(
            ZikrEntity(
                name = name.trim(),
                targetCount = targetCount.coerceAtLeast(1),
                currentCount = 0,
                completedRounds = 0,
                sortOrder = nextOrder,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun updateZikr(id: Long, name: String, targetCount: Int) {
        dao.updateDetails(
            id = id,
            name = name.trim(),
            targetCount = targetCount.coerceAtLeast(1),
            updatedAt = System.currentTimeMillis()
        )
    }

    suspend fun updateProgress(
        id: Long,
        currentCount: Int,
        completedRounds: Int,
        dailyCountDelta: Int = 0,
        dailyRoundDelta: Int = 0
    ) {
        val now = System.currentTimeMillis()
        dao.updateProgress(
            id = id,
            currentCount = currentCount.coerceAtLeast(0),
            completedRounds = completedRounds.coerceAtLeast(0),
            updatedAt = now
        )
        if (dailyCountDelta != 0 || dailyRoundDelta != 0) {
            val dateKey = todayDateKey()
            val existing = dailyLogDao.getForDay(id, dateKey)
            val nextDailyCount = ((existing?.count ?: 0) + dailyCountDelta).coerceAtLeast(0)
            val nextDailyRounds = ((existing?.rounds ?: 0) + dailyRoundDelta).coerceAtLeast(0)
            dailyLogDao.upsert(
                ZikrDailyLogEntity(
                    zikrId = id,
                    dateKey = dateKey,
                    count = nextDailyCount,
                    rounds = nextDailyRounds,
                    updatedAt = now
                )
            )

            if (dailyCountDelta != 0) {
                val hr = currentHour()
                val existingHr = hourlyLogDao.getForHour(id, dateKey, hr)
                val nextHrCount = ((existingHr?.count ?: 0) + dailyCountDelta).coerceAtLeast(0)
                hourlyLogDao.upsert(
                    ZikrHourlyLogEntity(
                        zikrId = id,
                        dateKey = dateKey,
                        hour = hr,
                        count = nextHrCount
                    )
                )
            }
        }
    }

    suspend fun saveStopwatchElapsed(id: Long, elapsedMs: Long) {
        dao.updateStopwatchElapsed(id, elapsedMs.coerceAtLeast(0L))
    }

    suspend fun recordRoundTiming(id: Long, durationMs: Long) {
        val safeDuration = durationMs.coerceAtLeast(1000L)
        val existing = dao.getById(id) ?: return
        val nextCount = existing.timedRoundsCount + 1
        val nextTotal = existing.totalRoundDurationMs + safeDuration
        val nextFastest = if (existing.fastestRoundMs == 0L) safeDuration else minOf(existing.fastestRoundMs, safeDuration)
        val nextSlowest = maxOf(existing.slowestRoundMs, safeDuration)
        dao.recordCompletedRoundTiming(
            id = id,
            fastestMs = nextFastest,
            slowestMs = nextSlowest,
            totalDurationMs = nextTotal,
            timedRoundsCount = nextCount
        )
    }

    suspend fun clearHistoryForZikrDay(zikrId: Long, dateKey: String) {
        val dayLog = dailyLogDao.getForDay(zikrId, dateKey)
        dailyLogDao.deleteForZikrDay(zikrId, dateKey)
        hourlyLogDao.deleteForZikrDay(zikrId, dateKey)
        if (dayLog != null && dayLog.count > 0) {
            val zikr = dao.getById(zikrId)
            if (zikr != null) {
                val nextCount = (zikr.currentCount - dayLog.count).coerceAtLeast(0)
                val nextRounds = if (zikr.targetCount > 0) nextCount / zikr.targetCount else 0
                dao.updateProgress(
                    id = zikrId,
                    currentCount = nextCount,
                    completedRounds = nextRounds,
                    updatedAt = System.currentTimeMillis()
                )
            }
        }
    }

    suspend fun clearHistoryForZikr(zikrId: Long) {
        dailyLogDao.deleteForZikr(zikrId)
        hourlyLogDao.deleteForZikr(zikrId)
        dao.updateProgress(id = zikrId, currentCount = 0, completedRounds = 0, updatedAt = System.currentTimeMillis())
        dao.resetTimings(zikrId)
    }

    suspend fun clearAllHistory() {
        dailyLogDao.deleteAll()
        hourlyLogDao.deleteAll()
    }

    suspend fun deleteZikr(id: Long) {
        dao.deleteById(id)
    }
}
