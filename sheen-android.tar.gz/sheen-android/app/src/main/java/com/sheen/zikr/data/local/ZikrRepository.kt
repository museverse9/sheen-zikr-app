package com.sheen.zikr.data.local

import kotlinx.coroutines.flow.Flow

class ZikrRepository(private val dao: ZikrDao) {

    val allZikr: Flow<List<ZikrEntity>> = dao.observeAll()

    suspend fun ensureStarterDataIfEmpty() {
        if (dao.getCount() == 0) {
            val now = System.currentTimeMillis()
            dao.insertAll(
                listOf(
                    ZikrEntity(
                        name = "سُبْحَانَ اللَّهِ",
                        targetCount = 33,
                        currentCount = 0,
                        sortOrder = 0,
                        createdAt = now,
                        updatedAt = now
                    ),
                    ZikrEntity(
                        name = "الْحَمْدُ لِلَّهِ",
                        targetCount = 33,
                        currentCount = 0,
                        sortOrder = 1,
                        createdAt = now + 1,
                        updatedAt = now + 1
                    ),
                    ZikrEntity(
                        name = "اللَّهُ أَكْبَرُ",
                        targetCount = 34,
                        currentCount = 0,
                        sortOrder = 2,
                        createdAt = now + 2,
                        updatedAt = now + 2
                    )
                )
            )
        }
    }

    suspend fun addZikr(name: String, targetCount: Int): Long {
        val nextOrder = dao.getMaxSortOrder() + 1
        val now = System.currentTimeMillis()
        return dao.insert(
            ZikrEntity(
                name = name.trim(),
                targetCount = targetCount.coerceAtLeast(1),
                currentCount = 0,
                completedRounds = 0,
                sortOrder = nextOrder,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun updateZikr(id: Long, name: String, targetCount: Int) {
        dao.updateDetails(
            id = id,
            name = name.trim(),
            targetCount = targetCount.coerceAtLeast(1),
            updatedAt = System.currentTimeMillis()
        )
    }

    suspend fun updateProgress(id: Long, currentCount: Int, completedRounds: Int) {
        dao.updateProgress(
            id = id,
            currentCount = currentCount.coerceAtLeast(0),
            completedRounds = completedRounds.coerceAtLeast(0),
            updatedAt = System.currentTimeMillis()
        )
    }

    suspend fun deleteZikr(id: Long) {
        dao.deleteById(id)
    }
}
