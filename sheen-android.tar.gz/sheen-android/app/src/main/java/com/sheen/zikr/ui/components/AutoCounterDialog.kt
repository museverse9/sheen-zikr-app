package com.sheen.zikr.ui.components

import android.os.SystemClock
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.sheen.zikr.ui.theme.LocalSheenColors

@Composable
fun AutoCounterSetupDialog(
    initialIntervalMs: Long,
    onDismiss: () -> Unit,
    onStartAuto: (Long) -> Unit
) {
    val brandColors = LocalSheenColors.current
    var selectedTab by remember { mutableStateOf(0) } // 0 = Touch, 1 = Timer
    var delayMs by remember { mutableLongStateOf(initialIntervalMs.coerceIn(300L, 300_000L)) }
    val tapTimestamps = remember { mutableStateListOf<Long>() }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, brandColors.cardBorder),
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Top 2-Tab Bar (Touch | Timer)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    listOf("Touch", "Timer").forEachIndexed { idx, label ->
                        val isSelected = selectedTab == idx
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable { selectedTab = idx }
                                .padding(vertical = 14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 22.dp, vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Setup Auto Counter",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    if (selectedTab == 0) {
                        // TOUCH TAB — Tap 3 times at desired rhythm
                        Text(
                            text = "Set your auto count delay by tapping below 3 times with your desired speed",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(22.dp))

                        Surface(
                            modifier = Modifier
                                .size(116.dp)
                                .clip(CircleShape)
                                .clickable {
                                    val now = SystemClock.elapsedRealtime()
                                    tapTimestamps.add(now)
                                    if (tapTimestamps.size >= 3) {
                                        val d1 = tapTimestamps[1] - tapTimestamps[0]
                                        val d2 = tapTimestamps[2] - tapTimestamps[1]
                                        val avg = ((d1 + d2) / 2L).coerceIn(300L, 300_000L)
                                        tapTimestamps.clear()
                                        onStartAuto(avg)
                                    }
                                },
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(3.dp, brandColors.gold)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = tapTimestamps.size.toString(),
                                    fontSize = 36.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = brandColors.gold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        TextButton(onClick = onDismiss) {
                            Text("Cancel")
                        }
                    } else {
                        // TIMER TAB — Fine & coarse adjustment (-1s, -0.1s, +0.1s, +1s)
                        Text(
                            text = "Set your auto count delay in seconds",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { delayMs = (delayMs - 1000L).coerceAtLeast(300L) }) {
                                Text("−1", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            }
                            TextButton(onClick = { delayMs = (delayMs - 100L).coerceAtLeast(300L) }) {
                                Text("−.1", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = String.format("%.1f", delayMs / 1000.0),
                                    fontSize = 34.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = brandColors.gold
                                )
                                Text(
                                    text = "seconds",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            TextButton(onClick = { delayMs = (delayMs + 100L).coerceAtMost(300_000L) }) {
                                Text("+.1", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            }
                            TextButton(onClick = { delayMs = (delayMs + 1000L).coerceAtMost(300_000L) }) {
                                Text("+1", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(22.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = onDismiss,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text("Cancel")
                            }
                            Button(
                                onClick = { onStartAuto(delayMs) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = brandColors.gold,
                                    contentColor = brandColors.deepBrand
                                )
                            ) {
                                Text("Start", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }
    }
}
