package com.sheen.zikr.data.preferences

enum class ThemeMode(val label: String) {
    SYSTEM("System"),
    LIGHT("Light"),
    DARK("Dark");

    companion object {
        fun fromName(name: String?): ThemeMode =
            entries.firstOrNull { it.name == name } ?: SYSTEM
    }
}

enum class AccentPalette(val label: String) {
    EMERALD_GOLD("Emerald Gold"),
    CRIMSON_GOLD("Crimson Gold"),
    INDIGO_GOLD("Indigo Gold"),
    OBSIDIAN_GOLD("Obsidian Gold");

    companion object {
        fun fromName(name: String?): AccentPalette = when (name) {
            "ROYAL_INDIGO", "INDIGO_GOLD" -> INDIGO_GOLD
            else -> entries.firstOrNull { it.name == name } ?: EMERALD_GOLD
        }
    }
}

enum class CounterFontStyle(val label: String) {
    ROYAL_SERIF("Playfair Display"),
    HERITAGE("Neue Helvetica"),
    CALLIGRAPHIC("Cormorant Garamond"),
    GEOMETRIC("Futura PT");

    companion object {
        fun fromName(name: String?): CounterFontStyle = when (name) {
            "CLASSIC_SERIF", "ROYAL_SERIF", "PLAYFAIR_DISPLAY" -> ROYAL_SERIF
            "HERITAGE", "NEUE_HELVETICA" -> HERITAGE
            "CALLIGRAPHIC", "BOLD_DISPLAY", "CORMORANT_GARAMOND" -> CALLIGRAPHIC
            "GEOMETRIC", "FUTURA_PT" -> GEOMETRIC
            else -> ROYAL_SERIF
        }
    }
}

enum class CounterFontSize(val label: String, val spValue: Float) {
    STANDARD("Standard", 58f),
    LARGE("Large", 74f),
    EXTRA_LARGE("Extra Large", 90f);

    companion object {
        fun fromName(name: String?): CounterFontSize =
            entries.firstOrNull { it.name == name } ?: LARGE
    }
}

enum class CountSoundType(val label: String) {
    SOFT_WOOD("Soft Bead"),
    WOODEN_TASBIH("Wooden Tasbih"),
    CRYSTAL_TICK("Crystal Tick"),
    WATER_DROP("Water Drop"),
    SOFT_BELL("Soft Bell"),
    GENTLE_PULSE("Gentle Pulse");

    companion object {
        fun fromName(name: String?): CountSoundType =
            entries.firstOrNull { it.name == name } ?: SOFT_WOOD
    }
}

data class UserPreferences(
    val selectedZikrId: Long = -1L,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accentPalette: AccentPalette = AccentPalette.EMERALD_GOLD,
    val counterFontStyle: CounterFontStyle = CounterFontStyle.ROYAL_SERIF,
    val counterFontSize: CounterFontSize = CounterFontSize.LARGE,
    val countSoundEnabled: Boolean = true,
    val completionSoundEnabled: Boolean = true,
    val selectedSound: CountSoundType = CountSoundType.SOFT_WOOD,
    val soundVolume: Float = 0.85f,
    val hapticEnabled: Boolean = true,
    val volumeButtonsEnabled: Boolean = true,
    val autoIntervalMs: Long = 2000L,
    val keepScreenOn: Boolean = true
)
