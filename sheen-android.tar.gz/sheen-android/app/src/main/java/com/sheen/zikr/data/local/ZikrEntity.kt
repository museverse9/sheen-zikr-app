package com.sheen.zikr.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "zikr_items")
data class ZikrEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val targetCount: Int,
    val currentCount: Int = 0,
    val completedRounds: Int = 0,
    val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val rounds: Int
        get() = if (targetCount <= 0) 0 else currentCount / targetCount

    val lapCount: Int
        get() = if (targetCount <= 0) currentCount else currentCount % targetCount

    val progressFraction: Float
        get() = if (targetCount <= 0) 0f else (lapCount.toFloat() / targetCount.toFloat()).coerceIn(0f, 1f)

    val progressPercent: Int
        get() = (progressFraction * 100f).toInt().coerceIn(0, 100)

    val remainingCount: Int
        get() = if (targetCount <= 0) 0 else (targetCount - lapCount).coerceAtLeast(0)

    val isTargetReached: Boolean
        get() = targetCount > 0 && currentCount > 0 && currentCount % targetCount == 0
}
