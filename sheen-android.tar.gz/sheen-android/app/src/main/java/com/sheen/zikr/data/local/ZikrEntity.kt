package com.sheen.zikr.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "zikr_items")
data class ZikrEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val targetCount: Int,
    val currentCount: Int = 0,
    val completedRounds: Int = 0,
    val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val currentRoundElapsedMs: Long = 0L,
    val fastestRoundMs: Long = 0L,
    val slowestRoundMs: Long = 0L,
    val totalRoundDurationMs: Long = 0L,
    val timedRoundsCount: Int = 0
) {
    val rounds: Int
        get() = if (targetCount <= 0) 0 else currentCount / targetCount

    /**
     * Lap counter shown in the big circle:
     * When currentCount > 0 and is an exact multiple of targetCount (e.g., 33 or 100),
     * displays `targetCount` (33 / 100) so the round visibly ends at 33/100;
     * on the very next press, currentCount becomes 34 / 101 and this returns 1.
     */
    val displayLapCount: Int
        get() {
            if (targetCount <= 0) return currentCount
            val mod = currentCount % targetCount
            return if (currentCount > 0 && mod == 0) targetCount else mod
        }

    val lapCount: Int
        get() = if (targetCount <= 0) currentCount else currentCount % targetCount

    val progressFraction: Float
        get() = if (targetCount <= 0) 0f else (displayLapCount.toFloat() / targetCount.toFloat()).coerceIn(0f, 1f)

    val progressPercent: Int
        get() = (progressFraction * 100f).toInt().coerceIn(0, 100)

    val remainingCount: Int
        get() = if (targetCount <= 0) 0 else (targetCount - displayLapCount).coerceAtLeast(0)

    val isTargetReached: Boolean
        get() = targetCount > 0 && currentCount > 0 && currentCount % targetCount == 0

    val averageRoundMs: Long
        get() = if (timedRoundsCount <= 0) 0L else totalRoundDurationMs / timedRoundsCount
}
