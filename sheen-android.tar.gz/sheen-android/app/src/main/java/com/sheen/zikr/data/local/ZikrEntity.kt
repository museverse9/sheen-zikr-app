package com.sheen.zikr.data.local

import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey

@Entity(tableName = "zikr_items")
data class ZikrEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val targetCount: Int,
    val currentCount: Int = 0,
    val completedRounds: Int = 0,
    val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val currentRoundElapsedMs: Long = 0L,
    val fastestRoundMs: Long = 0L,
    val slowestRoundMs: Long = 0L,
    val totalRoundDurationMs: Long = 0L,
    val timedRoundsCount: Int = 0
) {
    @Ignore
    var isRoundResetAtBoundary: Boolean = false

    val rounds: Int
        get() = if (targetCount <= 0) 0 else maxOf(completedRounds, currentCount / targetCount)

    /**
     * Lap counter shown in the big circle:
     * - When currentCount == 0 or isRoundResetAtBoundary is true -> 0
     * - When currentCount > 0 and is an exact multiple of targetCount -> targetCount (33 / 100)
     * - Next tap increments currentCount, clearing isRoundResetAtBoundary and rolling over to 1
     */
    val displayLapCount: Int
        get() {
            if (currentCount <= 0 || isRoundResetAtBoundary) return 0
            if (targetCount <= 0) return currentCount
            val mod = currentCount % targetCount
            return if (mod == 0) targetCount else mod
        }

    val lapCount: Int
        get() = if (targetCount <= 0) currentCount else currentCount % targetCount

    val progressFraction: Float
        get() = if (targetCount <= 0) 0f else (displayLapCount.toFloat() / targetCount.toFloat()).coerceIn(0f, 1f)

    val progressPercent: Int
        get() = (progressFraction * 100f).toInt().coerceIn(0, 100)

    val remainingCount: Int
        get() = if (targetCount <= 0) 0 else (targetCount - displayLapCount).coerceAtLeast(0)

    val isTargetReached: Boolean
        get() = targetCount > 0 && currentCount > 0 && currentCount % targetCount == 0

    val averageRoundMs: Long
        get() = if (timedRoundsCount <= 0) 0L else totalRoundDurationMs / timedRoundsCount
}
