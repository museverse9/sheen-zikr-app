package com.sheen.zikr.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.sheen.zikr.R
import com.sheen.zikr.data.preferences.CounterFontStyle

val SheenUiFont = FontFamily(
    Font(R.font.lato_regular, FontWeight.Normal),
    Font(R.font.lato_medium, FontWeight.Medium),
    Font(R.font.lato_semibold, FontWeight.SemiBold),
    Font(R.font.lato_bold, FontWeight.Bold)
)

val SheenEditorialSerif = FontFamily(
    Font(R.font.palatino_regular, FontWeight.Normal),
    Font(R.font.palatino_regular, FontWeight.Medium),
    Font(R.font.palatino_bold, FontWeight.SemiBold),
    Font(R.font.palatino_bold, FontWeight.Bold)
)

val SheenIndoPakBoldFont = FontFamily(
    Font(R.font.indopak_bold, FontWeight.Bold),
    Font(R.font.indopak_bold, FontWeight.SemiBold),
    Font(R.font.indopak_bold, FontWeight.Medium),
    Font(R.font.indopak_bold, FontWeight.Normal)
)

val SheenDuaCursiveItalicFont = FontFamily(
    Font(R.font.dua_italic_cursive, FontWeight.Normal, FontStyle.Italic),
    Font(R.font.dua_italic_cursive, FontWeight.Medium, FontStyle.Italic),
    Font(R.font.dua_italic_cursive, FontWeight.SemiBold, FontStyle.Italic),
    Font(R.font.dua_italic_cursive, FontWeight.Bold, FontStyle.Italic)
)

val CounterPlayfairDisplayFont = FontFamily(Font(R.font.playfair_display, FontWeight.Bold))
val CounterNeueHelveticaFont = FontFamily(Font(R.font.neue_helvetica, FontWeight.SemiBold))
val CounterCormorantGaramondFont = FontFamily(Font(R.font.cormorant_garamond, FontWeight.Medium, FontStyle.Italic))
val CounterFuturaPtFont = FontFamily(Font(R.font.futura_pt, FontWeight.SemiBold))

val CounterRoyalSerifFont = CounterPlayfairDisplayFont
val CounterHeritageFont = CounterNeueHelveticaFont
val CounterCalligraphicFont = CounterCormorantGaramondFont
val CounterGeometricFont = CounterFuturaPtFont

val SheenTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = SheenEditorialSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 56.sp,
        lineHeight = 64.sp,
        letterSpacing = (-0.5).sp
    ),
    headlineLarge = TextStyle(
        fontFamily = SheenEditorialSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = 36.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = SheenEditorialSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        lineHeight = 30.sp
    ),
    titleLarge = TextStyle(
        fontFamily = SheenEditorialSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 19.sp,
        lineHeight = 26.sp
    ),
    titleMedium = TextStyle(
        fontFamily = SheenUiFont,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        lineHeight = 20.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = SheenUiFont,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 21.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = SheenUiFont,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 16.sp
    ),
    labelLarge = TextStyle(
        fontFamily = SheenUiFont,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
        lineHeight = 17.sp,
        letterSpacing = 0.2.sp
    ),
    labelMedium = TextStyle(
        fontFamily = SheenUiFont,
        fontWeight = FontWeight.Medium,
        fontSize = 11.5.sp,
        lineHeight = 15.sp,
        letterSpacing = 0.2.sp
    )
)

fun CounterFontStyle.toFontFamily(): FontFamily = when (this) {
    CounterFontStyle.ROYAL_SERIF -> CounterPlayfairDisplayFont
    CounterFontStyle.HERITAGE -> CounterNeueHelveticaFont
    CounterFontStyle.CALLIGRAPHIC -> CounterCormorantGaramondFont
    CounterFontStyle.GEOMETRIC -> CounterFuturaPtFont
}

fun CounterFontStyle.toFontWeight(): FontWeight = when (this) {
    CounterFontStyle.ROYAL_SERIF -> FontWeight.Bold
    CounterFontStyle.HERITAGE -> FontWeight.SemiBold
    CounterFontStyle.CALLIGRAPHIC -> FontWeight.Medium
    CounterFontStyle.GEOMETRIC -> FontWeight.SemiBold
}

fun CounterFontStyle.toFontStyle(): FontStyle = when (this) {
    CounterFontStyle.CALLIGRAPHIC -> FontStyle.Italic
    else -> FontStyle.Normal
}

fun CounterFontStyle.toLetterSpacing(): TextUnit = when (this) {
    CounterFontStyle.GEOMETRIC -> 1.5.sp
    CounterFontStyle.HERITAGE -> 0.5.sp
    else -> 0.sp
}
