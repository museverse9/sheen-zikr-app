package com.sheen.zikr.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.sheen.zikr.R
import com.sheen.zikr.data.preferences.CounterFontStyle

val SheenUiFont = FontFamily(
    Font(R.font.lato_regular, FontWeight.Normal),
    Font(R.font.lato_medium, FontWeight.Medium),
    Font(R.font.lato_semibold, FontWeight.SemiBold),
    Font(R.font.lato_bold, FontWeight.Bold)
)

val SheenEditorialSerif = FontFamily(
    Font(R.font.palatino_regular, FontWeight.Normal),
    Font(R.font.palatino_regular, FontWeight.Medium),
    Font(R.font.palatino_bold, FontWeight.SemiBold),
    Font(R.font.palatino_bold, FontWeight.Bold)
)

val CounterRoyalSerifFont = FontFamily(Font(R.font.palatino_bold, FontWeight.Bold))
val CounterCalligraphicFont = FontFamily(Font(R.font.chancery_italic, FontWeight.Medium))
val CounterHeritageFont = FontFamily(Font(R.font.bookman_demi, FontWeight.SemiBold))
val CounterGeometricFont = FontFamily(Font(R.font.gothic_demi, FontWeight.SemiBold))

val SheenTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = SheenEditorialSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 56.sp,
        lineHeight = 64.sp,
        letterSpacing = (-0.5).sp
    ),
    headlineLarge = TextStyle(
        fontFamily = SheenEditorialSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = 36.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = SheenEditorialSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        lineHeight = 30.sp
    ),
    titleLarge = TextStyle(
        fontFamily = SheenEditorialSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 19.sp,
        lineHeight = 26.sp
    ),
    titleMedium = TextStyle(
        fontFamily = SheenUiFont,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        lineHeight = 20.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = SheenUiFont,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 21.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = SheenUiFont,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 16.sp
    ),
    labelLarge = TextStyle(
        fontFamily = SheenUiFont,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
        lineHeight = 17.sp,
        letterSpacing = 0.2.sp
    ),
    labelMedium = TextStyle(
        fontFamily = SheenUiFont,
        fontWeight = FontWeight.Medium,
        fontSize = 11.5.sp,
        lineHeight = 15.sp,
        letterSpacing = 0.2.sp
    )
)

fun CounterFontStyle.toFontFamily(): FontFamily = when (this) {
    CounterFontStyle.ROYAL_SERIF -> CounterRoyalSerifFont
    CounterFontStyle.CALLIGRAPHIC -> CounterCalligraphicFont
    CounterFontStyle.HERITAGE -> CounterHeritageFont
    CounterFontStyle.GEOMETRIC -> CounterGeometricFont
}

fun CounterFontStyle.toFontWeight(): FontWeight = when (this) {
    CounterFontStyle.ROYAL_SERIF -> FontWeight.Bold
    CounterFontStyle.CALLIGRAPHIC -> FontWeight.Medium
    CounterFontStyle.HERITAGE -> FontWeight.SemiBold
    CounterFontStyle.GEOMETRIC -> FontWeight.SemiBold
}

fun CounterFontStyle.toFontStyle(): FontStyle = FontStyle.Normal

fun CounterFontStyle.toLetterSpacing(): TextUnit = when (this) {
    CounterFontStyle.GEOMETRIC -> 1.5.sp
    CounterFontStyle.HERITAGE -> 0.8.sp
    else -> 0.sp
}
