package com.sheen.zikr.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sheen.zikr.data.preferences.CounterFontSize
import com.sheen.zikr.data.preferences.CounterFontStyle
import com.sheen.zikr.ui.theme.LocalSheenColors
import com.sheen.zikr.ui.theme.toFontFamily
import com.sheen.zikr.ui.theme.toFontWeight
import com.sheen.zikr.ui.theme.toFontStyle
import com.sheen.zikr.ui.theme.toLetterSpacing

@Composable
fun CircularProgressCounter(
    currentCount: Int,
    progressFraction: Float,
    progressPercent: Int,
    fontStyle: CounterFontStyle,
    fontSize: CounterFontSize,
    autoTickProgress: Float,
    isAutoRunning: Boolean,
    onTapCount: () -> Unit,
    modifier: Modifier = Modifier,
    diameter: Dp = 286.dp
) {
    val brandColors = LocalSheenColors.current
    val animatedProgress by animateFloatAsState(
        targetValue = progressFraction.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 220),
        label = "zikrProgress"
    )

    val interactionSource = remember { MutableInteractionSource() }
    val primaryColor = MaterialTheme.colorScheme.primary
    val goldColor = brandColors.gold
    val goldSoft = brandColors.goldSoft
    val trackColor = brandColors.trackColor
    val surfaceColor = MaterialTheme.colorScheme.surface

    Box(
        modifier = modifier.size(diameter + 24.dp),
        contentAlignment = Alignment.Center
    ) {
        // Outer progress ring + inner auto-tick ring
        Canvas(modifier = Modifier.size(diameter)) {
            val strokePx = 7.dp.toPx()
            val inset = strokePx / 2f + 2.dp.toPx()
            val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
            val topLeft = Offset(inset, inset)

            drawArc(
                color = trackColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )

            if (animatedProgress > 0f) {
                val sweepBrush = Brush.sweepGradient(
                    colors = listOf(goldColor, goldSoft, primaryColor, goldColor)
                )
                drawArc(
                    brush = sweepBrush,
                    startAngle = -90f,
                    sweepAngle = animatedProgress * 360f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )
            }

            if (isAutoRunning) {
                val innerInset = inset + 11.dp.toPx()
                val innerSize = Size(size.width - innerInset * 2, size.height - innerInset * 2)
                drawArc(
                    color = goldColor.copy(alpha = 0.65f),
                    startAngle = -90f,
                    sweepAngle = autoTickProgress.coerceIn(0f, 1f) * 360f,
                    useCenter = false,
                    topLeft = Offset(innerInset, innerInset),
                    size = innerSize,
                    style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }

        // Large tactile circular tap surface
        Surface(
            modifier = Modifier
                .size(diameter - 20.dp)
                .clip(CircleShape)
                .clickable(
                    interactionSource = interactionSource,
                    indication = ripple(bounded = true, color = goldColor),
                    onClick = onTapCount
                ),
            shape = CircleShape,
            color = surfaceColor,
            shadowElevation = 6.dp,
            tonalElevation = 2.dp
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = currentCount.toString(),
                    fontSize = fontSize.spValue.sp,
                    fontFamily = fontStyle.toFontFamily(),
                    fontWeight = fontStyle.toFontWeight(),
                    fontStyle = fontStyle.toFontStyle(),
                    letterSpacing = fontStyle.toLetterSpacing(),
                    color = goldColor,
                    maxLines = 1
                )
            }
        }

        // Floating percentage badge at top of ring (Easy Counter style)
        Surface(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = 2.dp),
            shape = RoundedCornerShape(999.dp),
            color = goldColor,
            shadowElevation = 3.dp
        ) {
            Text(
                text = "$progressPercent%",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = brandColors.deepBrand,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}
