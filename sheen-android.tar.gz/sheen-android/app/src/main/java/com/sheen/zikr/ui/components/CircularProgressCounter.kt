package com.sheen.zikr.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sheen.zikr.data.preferences.CounterFontSize
import com.sheen.zikr.data.preferences.CounterFontStyle
import com.sheen.zikr.ui.theme.LocalSheenColors
import com.sheen.zikr.ui.theme.SheenCalligraphicFont
import com.sheen.zikr.ui.theme.SheenEditorialSerif
import com.sheen.zikr.ui.theme.SheenGeometricFont
import com.sheen.zikr.ui.theme.SheenHeritageFont
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

fun counterFontFamilyFor(style: CounterFontStyle): FontFamily = when (style) {
    CounterFontStyle.ROYAL_SERIF -> SheenEditorialSerif
    CounterFontStyle.CALLIGRAPHIC -> SheenCalligraphicFont
    CounterFontStyle.HERITAGE -> SheenHeritageFont
    CounterFontStyle.GEOMETRIC -> SheenGeometricFont
}

/**
 * Scales digit size by digit length (1 digit largest -> 4+ digits smallest)
 * and boosts Calligraphic + Extra Large so it reads boldly without clipping.
 */
fun scaledCounterTextSize(
    numberValue: Int,
    fontStyle: CounterFontStyle,
    fontSize: CounterFontSize
): TextUnit {
    val baseSp = when (fontSize) {
        CounterFontSize.STANDARD -> 68f
        CounterFontSize.LARGE -> 82f
        CounterFontSize.EXTRA_LARGE -> if (fontStyle == CounterFontStyle.CALLIGRAPHIC) 104f else 96f
    }
    val digits = kotlin.math.abs(numberValue).toString().length
    val lengthFactor = when {
        digits <= 1 -> 1.14f
        digits == 2 -> 1.0f
        digits == 3 -> 0.80f
        else -> 0.64f
    }
    val styleBoost = if (fontStyle == CounterFontStyle.CALLIGRAPHIC) 1.08f else 1.0f
    return (baseSp * lengthFactor * styleBoost).sp
}

@Composable
fun CircularProgressCounter(
    currentCount: Int,
    progressFraction: Float,
    progressPercent: Int,
    fontStyle: CounterFontStyle,
    fontSize: CounterFontSize,
    autoTickProgress: Float = 0f,
    isAutoRunning: Boolean = false,
    onTapCount: () -> Unit,
    modifier: Modifier = Modifier,
    ringSize: Dp = 268.dp
) {
    val brandColors = LocalSheenColors.current
    val animatedSweep by animateFloatAsState(
        targetValue = (progressFraction.coerceIn(0f, 1f)) * 360f,
        animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing),
        label = "roundProgressSweep"
    )

    val interactionSource = remember { MutableInteractionSource() }
    val activeFontFamily = counterFontFamilyFor(fontStyle)
    val dynamicFontSize = scaledCounterTextSize(currentCount, fontStyle, fontSize)

    Box(
        modifier = modifier
            .size(ringSize)
            .semantics {
                contentDescription = "Tap to count. Current count $currentCount, $progressPercent percent of round"
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                role = Role.Button,
                onClick = onTapCount
            ),
        contentAlignment = Alignment.Center
    ) {
        val strokeWidth = 10.dp
        val trackColor = brandColors.trackColor
        val goldColor = brandColors.gold
        val goldSoftColor = brandColors.goldSoft
        val fillColor = brandColors.ringFill

        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokePx = strokeWidth.toPx()
            val radius = (min(size.width, size.height) - strokePx) / 2f
            val topLeft = Offset(
                x = (size.width - radius * 2f) / 2f,
                y = (size.height - radius * 2f) / 2f
            )
            val arcSize = Size(radius * 2f, radius * 2f)

            drawCircle(
                color = fillColor,
                radius = (radius - strokePx / 2f).coerceAtLeast(0f),
                center = center
            )

            drawArc(
                color = trackColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )

            if (animatedSweep > 0.5f) {
                drawArc(
                    color = goldColor,
                    startAngle = -90f,
                    sweepAngle = animatedSweep,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )
            }

            if (isAutoRunning && autoTickProgress > 0f) {
                val innerRadius = radius - strokePx * 1.15f
                if (innerRadius > 12f) {
                    drawArc(
                        color = goldSoftColor.copy(alpha = 0.72f),
                        startAngle = -90f,
                        sweepAngle = (autoTickProgress.coerceIn(0f, 1f)) * 360f,
                        useCenter = false,
                        topLeft = Offset(center.x - innerRadius, center.y - innerRadius),
                        size = Size(innerRadius * 2f, innerRadius * 2f),
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            val angleRad = Math.toRadians((-90.0 + animatedSweep))
            val knobX = center.x + radius * cos(angleRad).toFloat()
            val knobY = center.y + radius * sin(angleRad).toFloat()
            drawCircle(
                color = goldSoftColor,
                radius = strokePx * 0.42f,
                center = Offset(knobX, knobY)
            )
        }

        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = (-12).dp)
                .clip(RoundedCornerShape(999.dp))
                .background(goldColor)
                .padding(horizontal = 10.dp, vertical = 3.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "$progressPercent%",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = brandColors.deepBrand
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        ) {
            Text(
                text = currentCount.toString(),
                style = TextStyle(
                    fontFamily = activeFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = dynamicFontSize,
                    lineHeight = (dynamicFontSize.value * 1.15f).sp
                ),
                color = goldColor,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis
            )
            if (isAutoRunning) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "AUTO",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun CounterPreviewCard(
    sampleCount: Int,
    fontStyle: CounterFontStyle,
    fontSize: CounterFontSize,
    modifier: Modifier = Modifier
) {
    val brandColors = LocalSheenColors.current
    val activeFontFamily = counterFontFamilyFor(fontStyle)
    val previewSize = scaledCounterTextSize(sampleCount, fontStyle, fontSize)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(184.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(brandColors.dockBg)
            .padding(vertical = 18.dp, horizontal = 16.dp)
    ) {
        Text(
            text = "Live Preview",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.align(Alignment.TopCenter)
        )

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .height(116.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = sampleCount.toString(),
                style = TextStyle(
                    fontFamily = activeFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = previewSize,
                    lineHeight = (previewSize.value * 1.12f).sp
                ),
                color = brandColors.gold,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
