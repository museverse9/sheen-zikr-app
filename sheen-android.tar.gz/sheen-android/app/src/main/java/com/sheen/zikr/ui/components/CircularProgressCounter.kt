package com.sheen.zikr.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sheen.zikr.data.preferences.CounterFontSize
import com.sheen.zikr.data.preferences.CounterFontStyle
import com.sheen.zikr.ui.theme.LocalSheenColors
import com.sheen.zikr.ui.theme.toFontFamily

@Composable
fun CircularProgressCounter(
    currentCount: Int,
    targetCount: Int,
    progressFraction: Float,
    isTargetReached: Boolean,
    fontStyle: CounterFontStyle,
    fontSize: CounterFontSize,
    autoTickProgress: Float,
    isAutoRunning: Boolean,
    onTapCount: () -> Unit,
    modifier: Modifier = Modifier,
    diameter: Dp = 264.dp
) {
    val brandColors = LocalSheenColors.current
    val animatedProgress by animateFloatAsState(
        targetValue = progressFraction.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 260),
        label = "zikrProgress"
    )

    val interactionSource = remember { MutableInteractionSource() }
    val primaryColor = MaterialTheme.colorScheme.primary
    val goldColor = brandColors.gold
    val goldSoft = brandColors.goldSoft
    val trackColor = brandColors.trackColor
    val surfaceColor = MaterialTheme.colorScheme.surface

    Box(
        modifier = modifier.size(diameter),
        contentAlignment = Alignment.Center
    ) {
        // Outer subtle progress arc & inner auto-tick indicator
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokePx = 11.dp.toPx()
            val inset = strokePx / 2f + 4.dp.toPx()
            val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
            val topLeft = Offset(inset, inset)

            // Background track
            drawArc(
                color = trackColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )

            // Active progress sweep
            if (animatedProgress > 0f) {
                val sweepBrush = Brush.sweepGradient(
                    colors = if (isTargetReached) {
                        listOf(goldSoft, goldColor, goldSoft)
                    } else {
                        listOf(primaryColor, goldColor, primaryColor)
                    }
                )
                drawArc(
                    brush = sweepBrush,
                    startAngle = -90f,
                    sweepAngle = animatedProgress * 360f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )
            }

            // Subtle inner auto-interval sweep ring when hands-free auto-counting is active
            if (isAutoRunning) {
                val innerInset = inset + 13.dp.toPx()
                val innerSize = Size(size.width - innerInset * 2, size.height - innerInset * 2)
                drawArc(
                    color = goldColor.copy(alpha = 0.55f),
                    startAngle = -90f,
                    sweepAngle = autoTickProgress.coerceIn(0f, 1f) * 360f,
                    useCenter = false,
                    topLeft = Offset(innerInset, innerInset),
                    size = innerSize,
                    style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }

        // Tactile circular tap area in the center
        Surface(
            modifier = Modifier
                .size(diameter - 38.dp)
                .clip(CircleShape)
                .clickable(
                    interactionSource = interactionSource,
                    indication = ripple(bounded = true, color = goldColor),
                    onClick = onTapCount
                ),
            shape = CircleShape,
            color = surfaceColor,
            shadowElevation = 6.dp,
            tonalElevation = 2.dp
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = currentCount.toString(),
                    fontSize = fontSize.spValue.sp,
                    fontFamily = fontStyle.toFontFamily(),
                    fontWeight = FontWeight.SemiBold,
                    color = if (isTargetReached) goldColor else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "/ $targetCount",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (isTargetReached) "Target Completed" else "Tap to Count",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (isTargetReached) goldColor else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.72f)
                )
            }
        }
    }
}
