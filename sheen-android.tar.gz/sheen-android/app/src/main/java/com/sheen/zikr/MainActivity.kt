package com.sheen.zikr

import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sheen.zikr.ui.components.SheenLogoMark
import com.sheen.zikr.ui.components.ZikrEditorDialog
import com.sheen.zikr.ui.screens.CounterScreen
import com.sheen.zikr.ui.screens.MyZikrScreen
import com.sheen.zikr.ui.screens.OverallHistoryScreen
import com.sheen.zikr.ui.screens.SettingsScreen
import com.sheen.zikr.ui.screens.ZikrHistoryScreen
import com.sheen.zikr.ui.theme.LocalSheenColors
import com.sheen.zikr.ui.theme.SheenEditorialSerif
import com.sheen.zikr.ui.theme.SheenTheme
import com.sheen.zikr.ui.viewmodel.SheenViewModel

private enum class SheenRoute {
    COUNTER,
    MY_ZIKR,
    SETTINGS,
    ZIKR_HISTORY,
    OVERALL_HISTORY
}

class MainActivity : ComponentActivity() {

    private var isOnCounterScreen: Boolean = true

    private val viewModel: SheenViewModel by viewModels {
        val app = application as SheenApplication
        SheenViewModel.Factory(
            zikrRepository = app.zikrRepository,
            preferencesRepository = app.preferencesRepository,
            soundManager = app.soundManager,
            hapticManager = app.hapticManager
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val state by viewModel.uiState.collectAsStateWithLifecycle()

            LaunchedEffect(state.preferences.keepScreenOn) {
                if (state.preferences.keepScreenOn) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }

            val lifecycleOwner = LocalLifecycleOwner.current
            DisposableEffect(lifecycleOwner) {
                val observer = LifecycleEventObserver { _, event ->
                    if (event == Lifecycle.Event.ON_PAUSE || event == Lifecycle.Event.ON_STOP) {
                        viewModel.pauseAutoCountingFromLifecycle()
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose {
                    lifecycleOwner.lifecycle.removeObserver(observer)
                }
            }

            SheenTheme(
                themeMode = state.preferences.themeMode,
                accentPalette = state.preferences.accentPalette
            ) {
                SheenAppShell(
                    viewModel = viewModel,
                    onRouteChanged = { route -> isOnCounterScreen = (route == SheenRoute.COUNTER) }
                )
            }
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val prefs = viewModel.uiState.value.preferences
        if (isOnCounterScreen && prefs.volumeButtonsEnabled) {
            if (event.keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    viewModel.incrementManual()
                }
                return true
            }
            if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    viewModel.decrementManual()
                }
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onPause() {
        super.onPause()
        viewModel.pauseAutoCountingFromLifecycle()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SheenAppShell(
    viewModel: SheenViewModel,
    onRouteChanged: (SheenRoute) -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val brandColors = LocalSheenColors.current
    var currentRoute by rememberSaveable { mutableStateOf(SheenRoute.COUNTER) }
    var historyZikrId by rememberSaveable { mutableLongStateOf(-1L) }
    var historyReturnRoute by rememberSaveable { mutableStateOf(SheenRoute.MY_ZIKR) }
    var showQuickAddDialog by remember { mutableStateOf(false) }

    LaunchedEffect(currentRoute) {
        onRouteChanged(currentRoute)
    }

    BackHandler(enabled = currentRoute != SheenRoute.COUNTER) {
        currentRoute = when (currentRoute) {
            SheenRoute.ZIKR_HISTORY -> historyReturnRoute
            SheenRoute.OVERALL_HISTORY -> SheenRoute.MY_ZIKR
            else -> SheenRoute.COUNTER
        }
    }

    val historyZikr = state.zikrList.firstOrNull { it.id == historyZikrId }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            if (currentRoute != SheenRoute.COUNTER) {
                CenterAlignedTopAppBar(
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                currentRoute = when (currentRoute) {
                                    SheenRoute.ZIKR_HISTORY -> historyReturnRoute
                                    SheenRoute.OVERALL_HISTORY -> SheenRoute.MY_ZIKR
                                    else -> SheenRoute.COUNTER
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back"
                            )
                        }
                    },
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            SheenLogoMark(size = 28.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when (currentRoute) {
                                    SheenRoute.MY_ZIKR -> "My Zikr"
                                    SheenRoute.SETTINGS -> "Settings"
                                    SheenRoute.ZIKR_HISTORY -> historyZikr?.name ?: "History"
                                    SheenRoute.OVERALL_HISTORY -> "Overall History"
                                    SheenRoute.COUNTER -> "Sheen"
                                },
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = SheenEditorialSerif,
                                    fontWeight = FontWeight.SemiBold,
                                    letterSpacing = 0.6.sp
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    },
                    actions = {
                        if (currentRoute == SheenRoute.MY_ZIKR) {
                            IconButton(onClick = { currentRoute = SheenRoute.OVERALL_HISTORY }) {
                                Icon(
                                    imageVector = Icons.Rounded.BarChart,
                                    contentDescription = "Overall History",
                                    tint = brandColors.gold
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            }
        }
    ) { innerPadding ->
        when (currentRoute) {
            SheenRoute.COUNTER -> CounterScreen(
                state = state,
                onIncrement = viewModel::incrementManual,
                onDecrement = viewModel::decrementManual,
                onReset = viewModel::resetCurrentCount,
                onResetRounds = viewModel::resetRoundsToZero,
                onResetDayHistory = viewModel::clearHistoryForZikrDay,
                observeDailyHistory = viewModel::observeHistory,
                onStartAutoWithInterval = viewModel::startAutoCountingWithInterval,
                onPauseAuto = viewModel::pauseAutoCounting,
                onResumeAuto = viewModel::resumeAutoCounting,
                onStopAuto = viewModel::stopAutoCounting,
                onToggleStopwatch = viewModel::toggleStopwatch,
                onResetStopwatch = viewModel::resetStopwatch,
                onCycleZikr = viewModel::cycleZikr,
                onToggleDimming = viewModel::toggleDimming,
                onToggleSound = viewModel::setCountSoundEnabled,
                onToggleHaptic = viewModel::setHapticEnabled,
                onUpdateZikr = viewModel::updateZikr,
                onAddZikrClick = { showQuickAddDialog = true },
                onOpenMyZikr = { currentRoute = SheenRoute.MY_ZIKR },
                onOpenSettings = { currentRoute = SheenRoute.SETTINGS }
            )

            SheenRoute.MY_ZIKR -> MyZikrScreen(
                state = state,
                onSelectZikr = { id ->
                    viewModel.selectZikr(id)
                    currentRoute = SheenRoute.COUNTER
                },
                onOpenZikrHistory = { zikr ->
                    historyZikrId = zikr.id
                    historyReturnRoute = SheenRoute.MY_ZIKR
                    currentRoute = SheenRoute.ZIKR_HISTORY
                },
                onAddZikr = { name, target ->
                    viewModel.addZikr(name, target, selectImmediately = true)
                    currentRoute = SheenRoute.COUNTER
                },
                onUpdateZikr = viewModel::updateZikr,
                onDeleteZikr = viewModel::deleteZikr,
                modifier = Modifier.padding(innerPadding)
            )

            SheenRoute.ZIKR_HISTORY -> {
                if (historyZikr != null) {
                    ZikrHistoryScreen(
                        zikr = historyZikr,
                        observeDailyHistory = viewModel::observeHistory,
                        observeHourly = viewModel::observeHourly,
                        onResetDayHistory = viewModel::clearHistoryForZikrDay,
                        onResetHistory = viewModel::clearHistoryForZikr,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }

            SheenRoute.OVERALL_HISTORY -> OverallHistoryScreen(
                zikrList = state.zikrList,
                allDailyLogsFlow = viewModel.allDailyLogs,
                onOpenZikrHistory = { zikr ->
                    historyZikrId = zikr.id
                    historyReturnRoute = SheenRoute.OVERALL_HISTORY
                    currentRoute = SheenRoute.ZIKR_HISTORY
                },
                onClearAllHistory = viewModel::clearAllHistory,
                modifier = Modifier.padding(innerPadding)
            )

            SheenRoute.SETTINGS -> SettingsScreen(
                preferences = state.preferences,
                currentCountSample = state.selectedZikr?.currentCount ?: 102,
                onSelectTheme = viewModel::setThemeMode,
                onSelectPalette = viewModel::setAccentPalette,
                onSelectFontStyle = viewModel::setCounterFontStyle,
                onSelectFontSize = viewModel::setCounterFontSize,
                onToggleCountSound = viewModel::setCountSoundEnabled,
                onSelectSound = viewModel::setSelectedSound,
                onChangeVolume = viewModel::setSoundVolume,
                onToggleCompletionSound = viewModel::setCompletionSoundEnabled,
                onToggleHaptic = viewModel::setHapticEnabled,
                onToggleVolumeButtons = viewModel::setVolumeButtonsEnabled,
                onToggleKeepScreenOn = viewModel::setKeepScreenOn,
                modifier = Modifier.padding(innerPadding)
            )
        }
    }

    if (showQuickAddDialog) {
        ZikrEditorDialog(
            title = "New Zikr",
            confirmLabel = "Add",
            onDismiss = { showQuickAddDialog = false },
            onConfirm = { name, target ->
                showQuickAddDialog = false
                viewModel.addZikr(name, target, selectImmediately = true)
            }
        )
    }
}
