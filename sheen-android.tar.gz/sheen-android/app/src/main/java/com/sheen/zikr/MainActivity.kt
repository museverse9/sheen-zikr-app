package com.sheen.zikr

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FormatListBulleted
import androidx.compose.material.icons.rounded.RadioButtonChecked
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sheen.zikr.ui.components.SheenLogoMark
import com.sheen.zikr.ui.components.ZikrEditorDialog
import com.sheen.zikr.ui.screens.CounterScreen
import com.sheen.zikr.ui.screens.MyZikrScreen
import com.sheen.zikr.ui.screens.SettingsScreen
import com.sheen.zikr.ui.theme.SheenTheme
import com.sheen.zikr.ui.viewmodel.SheenUiEvent
import com.sheen.zikr.ui.viewmodel.SheenViewModel

private enum class SheenTab(
    val label: String,
    val icon: ImageVector
) {
    COUNTER("Counter", Icons.Rounded.RadioButtonChecked),
    MY_ZIKR("My Zikr", Icons.Rounded.FormatListBulleted),
    SETTINGS("Settings", Icons.Rounded.Settings)
}

class MainActivity : ComponentActivity() {

    private val viewModel: SheenViewModel by viewModels {
        val app = application as SheenApplication
        SheenViewModel.Factory(
            zikrRepository = app.zikrRepository,
            preferencesRepository = app.preferencesRepository,
            soundManager = app.soundManager
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val state by viewModel.uiState.collectAsStateWithLifecycle()

            // Keep screen awake only while SHEEN is actively open and preference is enabled
            LaunchedEffect(state.preferences.keepScreenOn) {
                if (state.preferences.keepScreenOn) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }

            // Lifecycle observer guarantees immediate pause on focus loss and NEVER auto-resumes
            val lifecycleOwner = LocalLifecycleOwner.current
            DisposableEffect(lifecycleOwner) {
                val observer = LifecycleEventObserver { _, event ->
                    if (event == Lifecycle.Event.ON_PAUSE || event == Lifecycle.Event.ON_STOP) {
                        viewModel.pauseAutoCountingFromLifecycle()
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose {
                    lifecycleOwner.lifecycle.removeObserver(observer)
                }
            }

            SheenTheme(
                themeMode = state.preferences.themeMode,
                accentPalette = state.preferences.accentPalette
            ) {
                SheenAppShell(viewModel = viewModel)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        // Extra safety net for screen lock / multi-window focus loss
        viewModel.pauseAutoCountingFromLifecycle()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SheenAppShell(viewModel: SheenViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var currentTab by rememberSaveable { mutableStateOf(SheenTab.COUNTER) }
    var showQuickAddDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val haptic = LocalHapticFeedback.current

    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            when (event) {
                is SheenUiEvent.HapticTick -> {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                }
                is SheenUiEvent.HapticComplete -> {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                }
                is SheenUiEvent.TargetReached -> {
                    snackbarHostState.currentSnackbarData?.dismiss()
                    snackbarHostState.showSnackbar(
                        message = "Completed ${event.target} repetitions of ${event.zikrName}",
                        duration = SnackbarDuration.Short
                    )
                }
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        SheenLogoMark(size = 32.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = when (currentTab) {
                                SheenTab.COUNTER -> "SHEEN"
                                SheenTab.MY_ZIKR -> "MY ZIKR"
                                SheenTab.SETTINGS -> "SETTINGS"
                            },
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 2.4.sp
                            )
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                SheenTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = currentTab == tab,
                        onClick = { currentTab = tab },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        when (currentTab) {
            SheenTab.COUNTER -> CounterScreen(
                state = state,
                onIncrement = viewModel::incrementManual,
                onDecrement = viewModel::decrementManual,
                onReset = viewModel::resetCurrentCount,
                onStartAuto = viewModel::startAutoCounting,
                onPauseAuto = viewModel::pauseAutoCounting,
                onResumeAuto = viewModel::resumeAutoCounting,
                onStopAuto = viewModel::stopAutoCounting,
                onIntervalSelected = viewModel::setAutoIntervalMs,
                onToggleSound = viewModel::setCountSoundEnabled,
                onOpenMyZikr = { currentTab = SheenTab.MY_ZIKR },
                onAddZikrClick = { showQuickAddDialog = true },
                modifier = Modifier.padding(innerPadding)
            )

            SheenTab.MY_ZIKR -> MyZikrScreen(
                state = state,
                onSelectZikr = { id ->
                    viewModel.selectZikr(id)
                    currentTab = SheenTab.COUNTER
                },
                onAddZikr = { name, target ->
                    viewModel.addZikr(name, target, selectImmediately = true)
                },
                onUpdateZikr = viewModel::updateZikr,
                onDeleteZikr = viewModel::deleteZikr,
                modifier = Modifier.padding(innerPadding)
            )

            SheenTab.SETTINGS -> SettingsScreen(
                preferences = state.preferences,
                onThemeModeChange = viewModel::setThemeMode,
                onAccentPaletteChange = viewModel::setAccentPalette,
                onFontStyleChange = viewModel::setCounterFontStyle,
                onFontSizeChange = viewModel::setCounterFontSize,
                onCountSoundToggle = viewModel::setCountSoundEnabled,
                onCompletionSoundToggle = viewModel::setCompletionSoundEnabled,
                onSoundSelected = viewModel::setSelectedSound,
                onPreviewCompletionSound = viewModel::previewCompletionSound,
                onVolumeChange = viewModel::setSoundVolume,
                onHapticToggle = viewModel::setHapticEnabled,
                onAutoIntervalChange = viewModel::setAutoIntervalMs,
                onKeepScreenOnToggle = viewModel::setKeepScreenOn,
                modifier = Modifier.padding(innerPadding)
            )
        }
    }

    if (showQuickAddDialog) {
        ZikrEditorDialog(
            title = "New Zikr",
            confirmLabel = "Add",
            onDismiss = { showQuickAddDialog = false },
            onConfirm = { name, target ->
                showQuickAddDialog = false
                viewModel.addZikr(name, target, selectImmediately = true)
            }
        )
    }
}
