package com.sheen.zikr.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.sheen.zikr.data.preferences.AccentPalette
import com.sheen.zikr.data.preferences.ThemeMode

data class SheenBrandColors(
    val gold: Color,
    val goldSoft: Color,
    val deepBrand: Color,
    val deepBrandMid: Color,
    val cardBorder: Color,
    val trackColor: Color,
    val dockBg: Color
)

val LocalSheenColors = staticCompositionLocalOf {
    SheenBrandColors(
        gold = SheenGold,
        goldSoft = SheenGoldBright,
        deepBrand = SheenEmeraldDeep,
        deepBrandMid = SheenEmeraldMid,
        cardBorder = Color(0x28D4AF37),
        trackColor = Color(0x220D4A45),
        dockBg = Color(0xFF0A2E2C)
    )
}

private fun colorSchemeFor(palette: AccentPalette, darkTheme: Boolean): Pair<ColorScheme, SheenBrandColors> {
    return when (palette) {
        AccentPalette.EMERALD_GOLD -> {
            if (darkTheme) {
                darkColorScheme(
                    primary = Color(0xFFE8C55E),
                    onPrimary = Color(0xFF062422),
                    primaryContainer = Color(0xFF124D46),
                    onPrimaryContainer = Color(0xFFF5DC8C),
                    secondary = Color(0xFF1F6E65),
                    onSecondary = Color(0xFFF5F1E8),
                    secondaryContainer = Color(0xFF13443E),
                    onSecondaryContainer = Color(0xFFF2D27A),
                    tertiary = Color(0xFFD4AF37),
                    onTertiary = Color(0xFF062422),
                    background = Color(0xFF061C1B),
                    onBackground = Color(0xFFF5F1E8),
                    surface = Color(0xFF0B2826),
                    onSurface = Color(0xFFF5F1E8),
                    surfaceVariant = Color(0xFF123734),
                    onSurfaceVariant = Color(0xFFA7BFBC),
                    outline = Color(0x45D4AF37)
                ) to SheenBrandColors(
                    gold = Color(0xFFE8C55E),
                    goldSoft = Color(0xFFF7E092),
                    deepBrand = Color(0xFF062C2B),
                    deepBrandMid = Color(0xFF0D4A45),
                    cardBorder = Color(0x38D4AF37),
                    trackColor = Color(0x2EF2D27A),
                    dockBg = Color(0xFF0A2322)
                )
            } else {
                lightColorScheme(
                    primary = Color(0xFF0D4A45),
                    onPrimary = Color.White,
                    primaryContainer = Color(0xFFD7EBE8),
                    onPrimaryContainer = Color(0xFF062C2B),
                    secondary = Color(0xFFB89022),
                    onSecondary = Color.White,
                    secondaryContainer = Color(0xFFE3F0ED),
                    onSecondaryContainer = Color(0xFF062C2B),
                    tertiary = Color(0xFFB89022),
                    onTertiary = Color.White,
                    background = Color(0xFFFAF7F2),
                    onBackground = Color(0xFF102423),
                    surface = Color.White,
                    onSurface = Color(0xFF102423),
                    surfaceVariant = Color(0xFFF1ECE3),
                    onSurfaceVariant = Color(0xFF4F6462),
                    outline = Color(0x380D4A45)
                ) to SheenBrandColors(
                    gold = Color(0xFFB89022),
                    goldSoft = Color(0xFFD4AF37),
                    deepBrand = Color(0xFF062C2B),
                    deepBrandMid = Color(0xFF0D4A45),
                    cardBorder = Color(0x2B0D4A45),
                    trackColor = Color(0x200D4A45),
                    dockBg = Color(0xFFEBF2F0)
                )
            }
        }

        AccentPalette.CRIMSON_GOLD -> {
            if (darkTheme) {
                darkColorScheme(
                    primary = Color(0xFFE8C55E),
                    onPrimary = Color(0xFF2B0812),
                    primaryContainer = Color(0xFF5C1528),
                    onPrimaryContainer = Color(0xFFF7E092),
                    secondary = Color(0xFF8C243E),
                    onSecondary = Color.White,
                    secondaryContainer = Color(0xFF471120),
                    onSecondaryContainer = Color(0xFFE8C55E),
                    tertiary = Color(0xFFD4AF37),
                    onTertiary = Color(0xFF2B0812),
                    background = Color(0xFF1C070D),
                    onBackground = Color(0xFFFAF2F4),
                    surface = Color(0xFF2A0C15),
                    onSurface = Color(0xFFFAF2F4),
                    surfaceVariant = Color(0xFF3C131F),
                    onSurfaceVariant = Color(0xFFD1AEB7),
                    outline = Color(0x45E8C55E)
                ) to SheenBrandColors(
                    gold = Color(0xFFE8C55E),
                    goldSoft = Color(0xFFF7E092),
                    deepBrand = Color(0xFF2B0812),
                    deepBrandMid = Color(0xFF5C1528),
                    cardBorder = Color(0x38E8C55E),
                    trackColor = Color(0x2EE8C55E),
                    dockBg = Color(0xFF240A12)
                )
            } else {
                lightColorScheme(
                    primary = Color(0xFF6B142B),
                    onPrimary = Color.White,
                    primaryContainer = Color(0xFFF7DCE3),
                    onPrimaryContainer = Color(0xFF3D0816),
                    secondary = Color(0xFFB89022),
                    onSecondary = Color.White,
                    secondaryContainer = Color(0xFFF5E3E8),
                    onSecondaryContainer = Color(0xFF4A0D1D),
                    tertiary = Color(0xFFB89022),
                    onTertiary = Color.White,
                    background = Color(0xFFFDF8F9),
                    onBackground = Color(0xFF2B0D15),
                    surface = Color.White,
                    onSurface = Color(0xFF2B0D15),
                    surfaceVariant = Color(0xFFF5EBEE),
                    onSurfaceVariant = Color(0xFF705059),
                    outline = Color(0x386B142B)
                ) to SheenBrandColors(
                    gold = Color(0xFFB89022),
                    goldSoft = Color(0xFFD4AF37),
                    deepBrand = Color(0xFF3D0816),
                    deepBrandMid = Color(0xFF6B142B),
                    cardBorder = Color(0x2B6B142B),
                    trackColor = Color(0x206B142B),
                    dockBg = Color(0xFFF4E6EA)
                )
            }
        }

        AccentPalette.INDIGO_GOLD -> {
            if (darkTheme) {
                darkColorScheme(
                    primary = Color(0xFFE8C55E),
                    onPrimary = Color(0xFF111833),
                    primaryContainer = Color(0xFF233266),
                    onPrimaryContainer = Color(0xFFF5DC8C),
                    secondary = Color(0xFF3E54A3),
                    onSecondary = Color.White,
                    secondaryContainer = Color(0xFF1F2B56),
                    onSecondaryContainer = Color(0xFFE8C55E),
                    tertiary = Color(0xFF8EA4F8),
                    onTertiary = Color(0xFF111833),
                    background = Color(0xFF0B1024),
                    onBackground = Color(0xFFF1F3FA),
                    surface = Color(0xFF121936),
                    onSurface = Color(0xFFF1F3FA),
                    surfaceVariant = Color(0xFF1B254B),
                    onSurfaceVariant = Color(0xFFA6B0D4),
                    outline = Color(0x45E8C55E)
                ) to SheenBrandColors(
                    gold = Color(0xFFE8C55E),
                    goldSoft = Color(0xFFF7E092),
                    deepBrand = Color(0xFF121936),
                    deepBrandMid = Color(0xFF233266),
                    cardBorder = Color(0x38E8C55E),
                    trackColor = Color(0x2EE8C55E),
                    dockBg = Color(0xFF101730)
                )
            } else {
                lightColorScheme(
                    primary = Color(0xFF22357A),
                    onPrimary = Color.White,
                    primaryContainer = Color(0xFFDDE4FA),
                    onPrimaryContainer = Color(0xFF101C47),
                    secondary = Color(0xFFB89022),
                    onSecondary = Color.White,
                    secondaryContainer = Color(0xFFE3E8F8),
                    onSecondaryContainer = Color(0xFF152354),
                    tertiary = Color(0xFFB89022),
                    onTertiary = Color.White,
                    background = Color(0xFFF6F7FC),
                    onBackground = Color(0xFF121A36),
                    surface = Color.White,
                    onSurface = Color(0xFF121A36),
                    surfaceVariant = Color(0xFFE9EDF8),
                    onSurfaceVariant = Color(0xFF4D587D),
                    outline = Color(0x3822357A)
                ) to SheenBrandColors(
                    gold = Color(0xFFB89022),
                    goldSoft = Color(0xFFD4AF37),
                    deepBrand = Color(0xFF152354),
                    deepBrandMid = Color(0xFF22357A),
                    cardBorder = Color(0x2B22357A),
                    trackColor = Color(0x2022357A),
                    dockBg = Color(0xFFE6EBF8)
                )
            }
        }

        AccentPalette.OBSIDIAN_GOLD -> {
            if (darkTheme) {
                darkColorScheme(
                    primary = Color(0xFFE6C25A),
                    onPrimary = Color(0xFF111313),
                    primaryContainer = Color(0xFF332D1B),
                    onPrimaryContainer = Color(0xFFF6E096),
                    secondary = Color(0xFF3A3F3F),
                    onSecondary = Color(0xFFF5F3EE),
                    secondaryContainer = Color(0xFF2B281E),
                    onSecondaryContainer = Color(0xFFE6C25A),
                    tertiary = Color(0xFFD4AF37),
                    onTertiary = Color(0xFF111313),
                    background = Color(0xFF101212),
                    onBackground = Color(0xFFF5F3EE),
                    surface = Color(0xFF1A1D1D),
                    onSurface = Color(0xFFF5F3EE),
                    surfaceVariant = Color(0xFF252929),
                    onSurfaceVariant = Color(0xFFB0B5B4),
                    outline = Color(0x45E6C25A)
                ) to SheenBrandColors(
                    gold = Color(0xFFE6C25A),
                    goldSoft = Color(0xFFF7E29C),
                    deepBrand = Color(0xFF101212),
                    deepBrandMid = Color(0xFF252929),
                    cardBorder = Color(0x38E6C25A),
                    trackColor = Color(0x2EE6C25A),
                    dockBg = Color(0xFF181B1B)
                )
            } else {
                lightColorScheme(
                    primary = Color(0xFF232727),
                    onPrimary = Color(0xFFF5DC8C),
                    primaryContainer = Color(0xFFEBE7DC),
                    onPrimaryContainer = Color(0xFF181B1B),
                    secondary = Color(0xFFB89022),
                    onSecondary = Color.White,
                    secondaryContainer = Color(0xFFF2EBD8),
                    onSecondaryContainer = Color(0xFF232727),
                    tertiary = Color(0xFFB89022),
                    onTertiary = Color.White,
                    background = Color(0xFFFAF8F4),
                    onBackground = Color(0xFF181B1B),
                    surface = Color.White,
                    onSurface = Color(0xFF181B1B),
                    surfaceVariant = Color(0xFFEFECE4),
                    onSurfaceVariant = Color(0xFF5A5E5D),
                    outline = Color(0x38232727)
                ) to SheenBrandColors(
                    gold = Color(0xFFB89022),
                    goldSoft = Color(0xFFE6C25A),
                    deepBrand = Color(0xFF181B1B),
                    deepBrandMid = Color(0xFF2B3030),
                    cardBorder = Color(0x2B232727),
                    trackColor = Color(0x20232727),
                    dockBg = Color(0xFFEDEAE2)
                )
            }
        }
    }
}

@Composable
fun SheenTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    accentPalette: AccentPalette = AccentPalette.EMERALD_GOLD,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val (colorScheme, brandColors) = colorSchemeFor(accentPalette, darkTheme)

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = Color.Transparent.toArgb()
            window.navigationBarColor = Color.Transparent.toArgb()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !darkTheme
            controller.isAppearanceLightNavigationBars = !darkTheme
        }
    }

    CompositionLocalProvider(LocalSheenColors provides brandColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = SheenTypography,
            content = content
        )
    }
}
