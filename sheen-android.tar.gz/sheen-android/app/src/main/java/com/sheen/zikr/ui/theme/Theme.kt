package com.sheen.zikr.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.sheen.zikr.data.preferences.AccentPalette
import com.sheen.zikr.data.preferences.ThemeMode

data class SheenBrandColors(
    val gold: Color,
    val goldSoft: Color,
    val deepBrand: Color,
    val deepBrandMid: Color,
    val cardBorder: Color,
    val trackColor: Color
)

val LocalSheenColors = staticCompositionLocalOf {
    SheenBrandColors(
        gold = SheenGold,
        goldSoft = SheenGoldBright,
        deepBrand = SheenEmeraldDeep,
        deepBrandMid = SheenEmeraldMid,
        cardBorder = Color(0x28D4AF37),
        trackColor = Color(0x220D4A45)
    )
}

private fun colorSchemeFor(palette: AccentPalette, darkTheme: Boolean): Pair<ColorScheme, SheenBrandColors> {
    return when (palette) {
        AccentPalette.EMERALD_GOLD -> {
            if (darkTheme) {
                darkColorScheme(
                    primary = SheenGold,
                    onPrimary = SheenEmeraldDeep,
                    primaryContainer = SheenEmeraldMid,
                    onPrimaryContainer = SheenGoldBright,
                    secondary = SheenEmeraldSoft,
                    onSecondary = SheenDarkText,
                    background = SheenDarkBg,
                    onBackground = SheenDarkText,
                    surface = SheenDarkSurface,
                    onSurface = SheenDarkText,
                    surfaceVariant = SheenDarkSurfaceElevated,
                    onSurfaceVariant = SheenDarkTextMuted,
                    outline = Color(0x38D4AF37)
                ) to SheenBrandColors(
                    gold = SheenGold,
                    goldSoft = SheenGoldBright,
                    deepBrand = SheenEmeraldDeep,
                    deepBrandMid = SheenEmeraldMid,
                    cardBorder = Color(0x33D4AF37),
                    trackColor = Color(0x33F2D27A)
                )
            } else {
                lightColorScheme(
                    primary = SheenEmeraldMid,
                    onPrimary = Color.White,
                    primaryContainer = Color(0xFFDDECE9),
                    onPrimaryContainer = SheenEmeraldDeep,
                    secondary = SheenGoldMuted,
                    onSecondary = Color.White,
                    background = SheenIvory,
                    onBackground = SheenInk,
                    surface = Color.White,
                    onSurface = SheenInk,
                    surfaceVariant = SheenIvorySurface,
                    onSurfaceVariant = SheenInkMuted,
                    outline = Color(0x330D4A45)
                ) to SheenBrandColors(
                    gold = SheenGoldMuted,
                    goldSoft = SheenGold,
                    deepBrand = SheenEmeraldDeep,
                    deepBrandMid = SheenEmeraldMid,
                    cardBorder = Color(0x280D4A45),
                    trackColor = Color(0x1E0D4A45)
                )
            }
        }

        AccentPalette.DEEP_TEAL -> {
            if (darkTheme) {
                darkColorScheme(
                    primary = TealChampagne,
                    onPrimary = TealDeep,
                    primaryContainer = TealMid,
                    onPrimaryContainer = SheenDarkText,
                    secondary = TealMid,
                    onSecondary = SheenDarkText,
                    background = Color(0xFF05181D),
                    onBackground = SheenDarkText,
                    surface = Color(0xFF0A242B),
                    onSurface = SheenDarkText,
                    surfaceVariant = Color(0xFF11353E),
                    onSurfaceVariant = Color(0xFFA0BDC4),
                    outline = Color(0x38E5C88B)
                ) to SheenBrandColors(
                    gold = TealChampagne,
                    goldSoft = SheenGoldBright,
                    deepBrand = TealDeep,
                    deepBrandMid = TealMid,
                    cardBorder = Color(0x33E5C88B),
                    trackColor = Color(0x30E5C88B)
                )
            } else {
                lightColorScheme(
                    primary = TealMid,
                    onPrimary = Color.White,
                    primaryContainer = Color(0xFFDCEEEF),
                    onPrimaryContainer = TealDeep,
                    secondary = SheenGoldMuted,
                    onSecondary = Color.White,
                    background = SheenIvory,
                    onBackground = Color(0xFF0E252A),
                    surface = Color.White,
                    onSurface = Color(0xFF0E252A),
                    surfaceVariant = Color(0xFFEFF4F5),
                    onSurfaceVariant = Color(0xFF4C676D),
                    outline = Color(0x330E5360)
                ) to SheenBrandColors(
                    gold = SheenGoldMuted,
                    goldSoft = TealChampagne,
                    deepBrand = TealDeep,
                    deepBrandMid = TealMid,
                    cardBorder = Color(0x260E5360),
                    trackColor = Color(0x1E0E5360)
                )
            }
        }

        AccentPalette.MIDNIGHT_JADE -> {
            if (darkTheme) {
                darkColorScheme(
                    primary = JadeAmber,
                    onPrimary = JadeDeep,
                    primaryContainer = JadeMid,
                    onPrimaryContainer = SheenDarkText,
                    secondary = JadeMid,
                    onSecondary = SheenDarkText,
                    background = Color(0xFF071A15),
                    onBackground = SheenDarkText,
                    surface = Color(0xFF0E2820),
                    onSurface = SheenDarkText,
                    surfaceVariant = Color(0xFF163A30),
                    onSurfaceVariant = Color(0xFFA4BFB6),
                    outline = Color(0x38E0A94F)
                ) to SheenBrandColors(
                    gold = JadeAmber,
                    goldSoft = SheenGoldBright,
                    deepBrand = JadeDeep,
                    deepBrandMid = JadeMid,
                    cardBorder = Color(0x33E0A94F),
                    trackColor = Color(0x30E0A94F)
                )
            } else {
                lightColorScheme(
                    primary = JadeMid,
                    onPrimary = Color.White,
                    primaryContainer = Color(0xFFDFEFE9),
                    onPrimaryContainer = JadeDeep,
                    secondary = Color(0xFFB8832E),
                    onSecondary = Color.White,
                    background = SheenIvory,
                    onBackground = Color(0xFF11261F),
                    surface = Color.White,
                    onSurface = Color(0xFF11261F),
                    surfaceVariant = Color(0xFFEFF5F2),
                    onSurfaceVariant = Color(0xFF4D665E),
                    outline = Color(0x33164D3E)
                ) to SheenBrandColors(
                    gold = Color(0xFFB8832E),
                    goldSoft = JadeAmber,
                    deepBrand = JadeDeep,
                    deepBrandMid = JadeMid,
                    cardBorder = Color(0x26164D3E),
                    trackColor = Color(0x1E164D3E)
                )
            }
        }

        AccentPalette.OBSIDIAN_GOLD -> {
            if (darkTheme) {
                darkColorScheme(
                    primary = ObsidianGold,
                    onPrimary = ObsidianBg,
                    primaryContainer = Color(0xFF2B281E),
                    onPrimaryContainer = SheenGoldBright,
                    secondary = Color(0xFF343A3A),
                    onSecondary = SheenDarkText,
                    background = ObsidianBg,
                    onBackground = SheenDarkText,
                    surface = ObsidianSurface,
                    onSurface = SheenDarkText,
                    surfaceVariant = Color(0xFF262B2B),
                    onSurfaceVariant = Color(0xFFB2B7B6),
                    outline = Color(0x3DE6C25A)
                ) to SheenBrandColors(
                    gold = ObsidianGold,
                    goldSoft = SheenGoldBright,
                    deepBrand = ObsidianBg,
                    deepBrandMid = ObsidianSurface,
                    cardBorder = Color(0x38E6C25A),
                    trackColor = Color(0x30E6C25A)
                )
            } else {
                lightColorScheme(
                    primary = Color(0xFF202626),
                    onPrimary = SheenGoldBright,
                    primaryContainer = Color(0xFFEBE8E0),
                    onPrimaryContainer = Color(0xFF1A1E1E),
                    secondary = SheenGoldMuted,
                    onSecondary = Color.White,
                    background = SheenIvory,
                    onBackground = Color(0xFF1A1E1E),
                    surface = Color.White,
                    onSurface = Color(0xFF1A1E1E),
                    surfaceVariant = Color(0xFFF2EFE8),
                    onSurfaceVariant = Color(0xFF5D6160),
                    outline = Color(0x33202626)
                ) to SheenBrandColors(
                    gold = SheenGoldMuted,
                    goldSoft = ObsidianGold,
                    deepBrand = Color(0xFF1A1E1E),
                    deepBrandMid = Color(0xFF2B3131),
                    cardBorder = Color(0x26202626),
                    trackColor = Color(0x1E202626)
                )
            }
        }
    }
}

@Composable
fun SheenTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    accentPalette: AccentPalette = AccentPalette.EMERALD_GOLD,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val (colorScheme, brandColors) = colorSchemeFor(accentPalette, darkTheme)

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = Color.Transparent.toArgb()
            window.navigationBarColor = Color.Transparent.toArgb()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !darkTheme
            controller.isAppearanceLightNavigationBars = !darkTheme
        }
    }

    CompositionLocalProvider(LocalSheenColors provides brandColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = SheenTypography,
            content = content
        )
    }
}
