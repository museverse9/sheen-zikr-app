package com.sheen.zikr.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sheen.zikr.BuildConfig
import com.sheen.zikr.data.local.SheenDatabase
import com.sheen.zikr.data.local.ZikrDailyLogEntity
import com.sheen.zikr.data.local.ZikrEntity
import com.sheen.zikr.data.preferences.AccentPalette
import com.sheen.zikr.data.preferences.CountSoundType
import com.sheen.zikr.data.preferences.CounterFontSize
import com.sheen.zikr.data.preferences.CounterFontStyle
import com.sheen.zikr.data.preferences.ThemeMode
import com.sheen.zikr.data.preferences.UserPreferences
import com.sheen.zikr.ui.components.CounterPreviewCard
import com.sheen.zikr.ui.theme.LocalSheenColors
import com.sheen.zikr.ui.theme.SheenEditorialSerif
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
private fun SettingsSectionCard(
    title: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val brandColors = LocalSheenColors.current
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, brandColors.cardBorder),
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = SheenEditorialSerif,
                    fontWeight = FontWeight.SemiBold
                ),
                color = brandColors.gold
            )
            content()
        }
    }
}

@Composable
private fun SettingsChoiceChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val brandColors = LocalSheenColors.current
    Surface(
        modifier = modifier
            .height(42.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (selected) 1.5.dp else 1.dp,
            color = if (selected) brandColors.gold else brandColors.cardBorder
        )
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                ),
                color = if (selected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val brandColors = LocalSheenColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = brandColors.deepBrand,
                checkedTrackColor = brandColors.gold
            )
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    preferences: UserPreferences,
    currentCountSample: Int,
    onSelectTheme: (ThemeMode) -> Unit,
    onSelectPalette: (AccentPalette) -> Unit,
    onSelectFontStyle: (CounterFontStyle) -> Unit,
    onSelectFontSize: (CounterFontSize) -> Unit,
    onToggleCountSound: (Boolean) -> Unit,
    onSelectSound: (CountSoundType) -> Unit,
    onChangeVolume: (Float) -> Unit,
    onToggleCompletionSound: (Boolean) -> Unit,
    onToggleHaptic: (Boolean) -> Unit,
    onToggleVolumeButtons: (Boolean) -> Unit,
    onToggleKeepScreenOn: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val brandColors = LocalSheenColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var backupStatus by remember { mutableStateOf<String?>(null) }
    var pendingImportJson by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val jsonString = withContext(Dispatchers.IO) {
                    val db = SheenDatabase.getInstance(context)
                    val zikrDao = db.zikrDao()
                    val dailyDao = db.dailyLogDao()
                    val items: List<ZikrEntity> = zikrDao.observeAll().first()
                    val daily: List<ZikrDailyLogEntity> = dailyDao.observeAll().first()

                    val root = JSONObject()
                    root.put("app", "SHEEN")
                    root.put("version", 1)
                    root.put("exportedAt", System.currentTimeMillis())

                    val zikrArr = JSONArray()
                    items.forEach { z ->
                        zikrArr.put(
                            JSONObject().apply {
                                put("id", z.id)
                                put("name", z.name)
                                put("targetCount", z.targetCount)
                                put("currentCount", z.currentCount)
                                put("completedRounds", z.completedRounds)
                                put("sortOrder", z.sortOrder)
                                put("createdAt", z.createdAt)
                                put("updatedAt", z.updatedAt)
                                put("currentRoundElapsedMs", z.currentRoundElapsedMs)
                                put("fastestRoundMs", z.fastestRoundMs)
                                put("slowestRoundMs", z.slowestRoundMs)
                                put("totalRoundDurationMs", z.totalRoundDurationMs)
                                put("timedRoundsCount", z.timedRoundsCount)
                            }
                        )
                    }
                    root.put("zikrItems", zikrArr)

                    val dailyArr = JSONArray()
                    daily.forEach { d ->
                        dailyArr.put(
                            JSONObject().apply {
                                put("zikrId", d.zikrId)
                                put("dateKey", d.dateKey)
                                put("count", d.count)
                                put("rounds", d.rounds)
                                put("updatedAt", d.updatedAt)
                            }
                        )
                    }
                    root.put("dailyLogs", dailyArr)
                    root.toString(2)
                }
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(jsonString.toByteArray(Charsets.UTF_8))
                    }
                }
                backupStatus = "Exported backup JSON"
            } catch (_: Exception) {
                backupStatus = "Export failed"
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val rawText = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        input.bufferedReader(Charsets.UTF_8).readText()
                    }
                } ?: return@launch
                JSONObject(rawText)
                pendingImportJson = rawText
            } catch (_: Exception) {
                backupStatus = "Invalid backup file"
            }
        }
    }

    fun executeImport(rawText: String, replaceExisting: Boolean) {
        scope.launch {
            try {
                val importedCount = withContext(Dispatchers.IO) {
                    val root = JSONObject(rawText)
                    val zikrArr = root.optJSONArray("zikrItems") ?: JSONArray()
                    val db = SheenDatabase.getInstance(context)
                    val zikrDao = db.zikrDao()
                    val dailyDao = db.dailyLogDao()

                    val currentItems: List<ZikrEntity> = zikrDao.observeAll().first()
                    if (replaceExisting) {
                        dailyDao.deleteAll()
                        currentItems.forEach { zikrDao.deleteById(it.id) }
                    }

                    val updatedExistingByName = zikrDao.observeAll().first().associateBy { it.name.trim() }
                    var count = 0
                    for (i in 0 until zikrArr.length()) {
                        val obj = zikrArr.optJSONObject(i) ?: continue
                        val name = obj.optString("name", "").trim()
                        val target = obj.optInt("targetCount", 33).coerceAtLeast(1)
                        if (name.isEmpty()) continue

                        val matched = updatedExistingByName[name]
                        if (matched != null && !replaceExisting) {
                            val mergedCount = maxOf(matched.currentCount, obj.optInt("currentCount", 0).coerceAtLeast(0))
                            val mergedRounds = maxOf(matched.completedRounds, obj.optInt("completedRounds", 0).coerceAtLeast(0))
                            zikrDao.update(
                                matched.copy(
                                    targetCount = target,
                                    currentCount = mergedCount,
                                    completedRounds = mergedRounds,
                                    updatedAt = System.currentTimeMillis()
                                )
                            )
                        } else {
                            zikrDao.insert(
                                ZikrEntity(
                                    id = 0L,
                                    name = name,
                                    targetCount = target,
                                    currentCount = obj.optInt("currentCount", 0).coerceAtLeast(0),
                                    completedRounds = obj.optInt("completedRounds", 0).coerceAtLeast(0),
                                    sortOrder = obj.optInt("sortOrder", i),
                                    createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                                    updatedAt = System.currentTimeMillis(),
                                    currentRoundElapsedMs = obj.optLong("currentRoundElapsedMs", 0L),
                                    fastestRoundMs = obj.optLong("fastestRoundMs", 0L),
                                    slowestRoundMs = obj.optLong("slowestRoundMs", 0L),
                                    totalRoundDurationMs = obj.optLong("totalRoundDurationMs", 0L),
                                    timedRoundsCount = obj.optInt("timedRoundsCount", 0)
                                )
                            )
                        }
                        count++
                    }

                    val dailyArr = root.optJSONArray("dailyLogs") ?: JSONArray()
                    val existingList: List<ZikrEntity> = zikrDao.observeAll().first()
                    val firstInsertedId = existingList.firstOrNull()?.id ?: 0L
                    if (firstInsertedId > 0L) {
                        for (i in 0 until dailyArr.length()) {
                            val dObj = dailyArr.optJSONObject(i) ?: continue
                            val dateKey = dObj.optString("dateKey", "")
                            if (dateKey.isNotBlank()) {
                                val incomingCount = dObj.optInt("count", 0).coerceAtLeast(0)
                                val incomingRounds = dObj.optInt("rounds", 0).coerceAtLeast(0)
                                val prevDay = if (!replaceExisting) dailyDao.getForDay(firstInsertedId, dateKey) else null
                                dailyDao.upsert(
                                    ZikrDailyLogEntity(
                                        zikrId = firstInsertedId,
                                        dateKey = dateKey,
                                        count = if (prevDay != null) maxOf(prevDay.count, incomingCount) else incomingCount,
                                        rounds = if (prevDay != null) maxOf(prevDay.rounds, incomingRounds) else incomingRounds,
                                        updatedAt = dObj.optLong("updatedAt", System.currentTimeMillis())
                                    )
                                )
                            }
                        }
                    }
                    count
                }
                backupStatus = if (replaceExisting) {
                    "Replaced with $importedCount Zikr item(s)"
                } else {
                    "Merged $importedCount Zikr item(s)"
                }
            } catch (_: Exception) {
                backupStatus = "Import failed"
            }
        }
    }

    if (pendingImportJson != null) {
        val rawToApply = pendingImportJson!!
        AlertDialog(
            onDismissRequest = { pendingImportJson = null },
            title = { Text("Import Backup") },
            text = {
                Text("Merge logs with existing Zikr items or replace existing items cleanly?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        pendingImportJson = null
                        executeImport(rawToApply, replaceExisting = true)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    )
                ) { Text("Replace") }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = { pendingImportJson = null }) { Text("Cancel") }
                    TextButton(
                        onClick = {
                            pendingImportJson = null
                            executeImport(rawToApply, replaceExisting = false)
                        }
                    ) { Text("Merge") }
                }
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SettingsSectionCard(title = "Appearance") {
            CounterPreviewCard(
                sampleCount = if (currentCountSample > 0) currentCountSample else 102,
                fontStyle = preferences.counterFontStyle,
                fontSize = preferences.counterFontSize
            )

            Text(
                text = "Theme",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ThemeMode.entries.forEach { mode ->
                    SettingsChoiceChip(
                        label = mode.label,
                        selected = preferences.themeMode == mode,
                        onClick = { onSelectTheme(mode) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Text(
                text = "Accent Palette",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                maxItemsInEachRow = 2
            ) {
                AccentPalette.entries.forEach { palette ->
                    SettingsChoiceChip(
                        label = palette.label,
                        selected = preferences.accentPalette == palette,
                        onClick = { onSelectPalette(palette) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Text(
                text = "Counter Number Style",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                maxItemsInEachRow = 2
            ) {
                CounterFontStyle.entries.forEach { style ->
                    SettingsChoiceChip(
                        label = style.label,
                        selected = preferences.counterFontStyle == style,
                        onClick = { onSelectFontStyle(style) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Text(
                text = "Counter Number Size",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CounterFontSize.entries.forEach { size ->
                    SettingsChoiceChip(
                        label = size.label,
                        selected = preferences.counterFontSize == size,
                        onClick = { onSelectFontSize(size) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        SettingsSectionCard(title = "Sound & Feedback") {
            SettingsSwitchRow(
                title = "Count Sound",
                checked = preferences.countSoundEnabled,
                onCheckedChange = onToggleCountSound
            )

            Text(
                text = "Sound Tone",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                maxItemsInEachRow = 2
            ) {
                CountSoundType.entries.forEach { tone ->
                    SettingsChoiceChip(
                        label = tone.label,
                        selected = preferences.selectedSound == tone,
                        onClick = { onSelectSound(tone) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Sound Volume",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${(preferences.soundVolume * 100f).toInt()}%",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = brandColors.gold
                )
            }
            Slider(
                value = preferences.soundVolume,
                onValueChange = onChangeVolume,
                valueRange = 0f..1f,
                colors = SliderDefaults.colors(
                    thumbColor = brandColors.gold,
                    activeTrackColor = brandColors.gold,
                    inactiveTrackColor = brandColors.trackColor
                )
            )

            SettingsSwitchRow(
                title = "Round Completion Chime",
                checked = preferences.completionSoundEnabled,
                onCheckedChange = onToggleCompletionSound
            )

            SettingsSwitchRow(
                title = "Haptic Feedback",
                checked = preferences.hapticEnabled,
                onCheckedChange = onToggleHaptic
            )

            SettingsSwitchRow(
                title = "Volume Button Counting",
                checked = preferences.volumeButtonsEnabled,
                onCheckedChange = onToggleVolumeButtons
            )
        }

        SettingsSectionCard(title = "Display & Backup") {
            SettingsSwitchRow(
                title = "Keep Screen On",
                checked = preferences.keepScreenOn,
                onCheckedChange = onToggleKeepScreenOn
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        val stamp = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                        exportLauncher.launch("sheen-zikr-backup-$stamp.json")
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Rounded.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Export")
                }

                OutlinedButton(
                    onClick = {
                        importLauncher.launch(arrayOf("application/json", "text/*"))
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Rounded.FileUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Import")
                }
            }

            if (backupStatus != null) {
                Text(
                    text = backupStatus!!,
                    style = MaterialTheme.typography.labelMedium,
                    color = brandColors.gold
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp, bottom = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = "Sheen",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = SheenEditorialSerif,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                ),
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Version ${BuildConfig.VERSION_NAME}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Developed with ❤️ by M",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Medium),
                color = brandColors.gold,
                textAlign = TextAlign.Center
            )
        }
    }
}
