package com.sheen.zikr.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sheen.zikr.BuildConfig
import com.sheen.zikr.data.preferences.AccentPalette
import com.sheen.zikr.data.preferences.CountSoundType
import com.sheen.zikr.data.preferences.CounterFontSize
import com.sheen.zikr.data.preferences.CounterFontStyle
import com.sheen.zikr.data.preferences.ThemeMode
import com.sheen.zikr.data.preferences.UserPreferences
import com.sheen.zikr.ui.components.CustomIntervalDialog
import com.sheen.zikr.ui.components.SheenLogoMark
import com.sheen.zikr.ui.components.formatIntervalLabel
import com.sheen.zikr.ui.theme.LocalSheenColors
import com.sheen.zikr.ui.theme.SheenEditorialSerif
import com.sheen.zikr.ui.theme.toFontFamily
import com.sheen.zikr.ui.theme.toFontStyle
import com.sheen.zikr.ui.theme.toFontWeight
import com.sheen.zikr.ui.theme.toLetterSpacing

@Composable
fun SettingsScreen(
    preferences: UserPreferences,
    onThemeModeChange: (ThemeMode) -> Unit,
    onAccentPaletteChange: (AccentPalette) -> Unit,
    onFontStyleChange: (CounterFontStyle) -> Unit,
    onFontSizeChange: (CounterFontSize) -> Unit,
    onCountSoundToggle: (Boolean) -> Unit,
    onCompletionSoundToggle: (Boolean) -> Unit,
    onSoundSelected: (CountSoundType) -> Unit,
    onPreviewCompletionSound: () -> Unit,
    onVolumeChange: (Float) -> Unit,
    onHapticToggle: (Boolean) -> Unit,
    onVolumeButtonsToggle: (Boolean) -> Unit,
    onAutoIntervalChange: (Long) -> Unit,
    onKeepScreenOnToggle: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val brandColors = LocalSheenColors.current
    var showCustomIntervalDialog by remember { mutableStateOf(false) }
    val presetIntervals = listOf(1000L, 2000L, 3000L, 4000L, 5000L)
    val isCustomInterval = preferences.autoIntervalMs !in presetIntervals

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Appearance Section
        SettingsCard(title = "Appearance") {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = brandColors.dockBg,
                border = BorderStroke(1.dp, brandColors.cardBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Live Preview",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "102",
                        fontSize = (preferences.counterFontSize.spValue * 0.72f).sp,
                        fontFamily = preferences.counterFontStyle.toFontFamily(),
                        fontWeight = preferences.counterFontStyle.toFontWeight(),
                        fontStyle = preferences.counterFontStyle.toFontStyle(),
                        letterSpacing = preferences.counterFontStyle.toLetterSpacing(),
                        color = brandColors.gold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            SettingLabel("Theme")
            OptionGrid(
                items = ThemeMode.entries,
                columns = 3,
                labelOf = { it.label },
                isSelected = { preferences.themeMode == it },
                onSelect = onThemeModeChange
            )

            Spacer(modifier = Modifier.height(16.dp))
            SettingLabel("Accent Palette")
            OptionGrid(
                items = AccentPalette.entries,
                columns = 2,
                labelOf = { it.label },
                isSelected = { preferences.accentPalette == it },
                onSelect = onAccentPaletteChange
            )

            Spacer(modifier = Modifier.height(16.dp))
            SettingLabel("Counter Number Style")
            OptionGrid(
                items = CounterFontStyle.entries,
                columns = 2,
                labelOf = { it.label },
                isSelected = { preferences.counterFontStyle == it },
                onSelect = onFontStyleChange
            )

            Spacer(modifier = Modifier.height(16.dp))
            SettingLabel("Counter Number Size")
            OptionGrid(
                items = CounterFontSize.entries,
                columns = 3,
                labelOf = { it.label },
                isSelected = { preferences.counterFontSize == it },
                onSelect = onFontSizeChange
            )
        }

        // 2. Sound & Feedback Section
        SettingsCard(title = "Sound & Feedback") {
            SwitchRow(
                title = "Count Sound",
                subtitle = "Play a subtle sound on every manual and automatic count",
                checked = preferences.countSoundEnabled,
                onCheckedChange = onCountSoundToggle
            )

            Spacer(modifier = Modifier.height(16.dp))
            SettingLabel("Sound Tone")
            OptionGrid(
                items = CountSoundType.entries,
                columns = 2,
                labelOf = { it.label },
                isSelected = { preferences.selectedSound == it },
                onSelect = onSoundSelected
            )

            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Sound Volume",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${(preferences.soundVolume * 100).toInt()}%",
                    style = MaterialTheme.typography.labelLarge,
                    color = brandColors.gold
                )
            }
            Slider(
                value = preferences.soundVolume,
                onValueChange = onVolumeChange,
                valueRange = 0f..1f
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = brandColors.cardBorder)

            SwitchRow(
                title = "Round Completion Chime",
                subtitle = "Play a warm chime every time a round completes",
                checked = preferences.completionSoundEnabled,
                onCheckedChange = onCompletionSoundToggle
            )
            TextButton(
                onClick = onPreviewCompletionSound,
                modifier = Modifier.padding(top = 2.dp)
            ) {
                Text("Preview Completion Chime")
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = brandColors.cardBorder)

            SwitchRow(
                title = "Haptic Feedback",
                subtitle = "Tactile vibration on each count and round",
                checked = preferences.hapticEnabled,
                onCheckedChange = onHapticToggle
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = brandColors.cardBorder)

            SwitchRow(
                title = "Volume Button Counting",
                subtitle = "Press Volume Up (+1) or Volume Down (−1) to count",
                checked = preferences.volumeButtonsEnabled,
                onCheckedChange = onVolumeButtonsToggle
            )
        }

        // 3. Automatic Counting Preferences
        SettingsCard(title = "Automatic Counting") {
            SettingLabel("Default Interval")
            val intervalChoices = listOf(1000L, 2000L, 3000L, 4000L, 5000L, -1L)
            OptionGrid(
                items = intervalChoices,
                columns = 3,
                labelOf = { ms ->
                    if (ms == -1L) {
                        if (isCustomInterval) formatIntervalLabel(preferences.autoIntervalMs) else "Custom"
                    } else {
                        formatIntervalLabel(ms)
                    }
                },
                isSelected = { ms ->
                    if (ms == -1L) isCustomInterval else preferences.autoIntervalMs == ms
                },
                onSelect = { ms ->
                    if (ms == -1L) showCustomIntervalDialog = true else onAutoIntervalChange(ms)
                }
            )

            Spacer(modifier = Modifier.height(16.dp))
            SwitchRow(
                title = "Keep Screen Awake",
                subtitle = "Prevent the display from sleeping while Sheen is open",
                checked = preferences.keepScreenOn,
                onCheckedChange = onKeepScreenOnToggle
            )

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Foreground-only guarantee: Automatic counting pauses immediately if you switch apps, minimize Sheen, or lock your phone, and never resumes on its own.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // 4. About Sheen
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, brandColors.cardBorder),
            tonalElevation = 1.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                SheenLogoMark(size = 72.dp)
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Sheen",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontFamily = SheenEditorialSerif,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.6.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Your Zikr. Your Rhythm. Your Routine.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = brandColors.gold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Version ${BuildConfig.VERSION_NAME}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
    }

    if (showCustomIntervalDialog) {
        CustomIntervalDialog(
            currentIntervalMs = preferences.autoIntervalMs,
            onDismiss = { showCustomIntervalDialog = false },
            onConfirm = { newMs ->
                showCustomIntervalDialog = false
                onAutoIntervalChange(newMs)
            }
        )
    }
}

@Composable
private fun <T> OptionGrid(
    items: List<T>,
    columns: Int,
    labelOf: (T) -> String,
    isSelected: (T) -> Boolean,
    onSelect: (T) -> Unit
) {
    val brandColors = LocalSheenColors.current
    val rows = items.chunked(columns)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        rows.forEach { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                rowItems.forEach { item ->
                    val selected = isSelected(item)
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelect(item) },
                        shape = RoundedCornerShape(12.dp),
                        color = if (selected) {
                            MaterialTheme.colorScheme.secondaryContainer
                        } else {
                            MaterialTheme.colorScheme.surface
                        },
                        border = BorderStroke(
                            width = if (selected) 1.4.dp else 1.dp,
                            color = if (selected) brandColors.gold else brandColors.cardBorder
                        )
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = labelOf(item),
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                ),
                                color = if (selected) {
                                    MaterialTheme.colorScheme.onSecondaryContainer
                                } else {
                                    MaterialTheme.colorScheme.onSurface
                                },
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
                val remainder = columns - rowItems.size
                repeat(remainder) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(
    title: String,
    content: @Composable () -> Unit
) {
    val brandColors = LocalSheenColors.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, brandColors.cardBorder),
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = SheenEditorialSerif,
                    fontWeight = FontWeight.SemiBold
                ),
                color = brandColors.gold
            )
            Spacer(modifier = Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
private fun SettingLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
