package com.sheen.zikr.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sheen.zikr.BuildConfig
import com.sheen.zikr.data.preferences.AccentPalette
import com.sheen.zikr.data.preferences.CountSoundType
import com.sheen.zikr.data.preferences.CounterFontSize
import com.sheen.zikr.data.preferences.CounterFontStyle
import com.sheen.zikr.data.preferences.ThemeMode
import com.sheen.zikr.data.preferences.UserPreferences
import com.sheen.zikr.ui.components.CustomIntervalDialog
import com.sheen.zikr.ui.components.SheenLogoMark
import com.sheen.zikr.ui.components.formatIntervalLabel
import com.sheen.zikr.ui.theme.LocalSheenColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    preferences: UserPreferences,
    onThemeModeChange: (ThemeMode) -> Unit,
    onAccentPaletteChange: (AccentPalette) -> Unit,
    onFontStyleChange: (CounterFontStyle) -> Unit,
    onFontSizeChange: (CounterFontSize) -> Unit,
    onCountSoundToggle: (Boolean) -> Unit,
    onCompletionSoundToggle: (Boolean) -> Unit,
    onSoundSelected: (CountSoundType) -> Unit,
    onPreviewCompletionSound: () -> Unit,
    onVolumeChange: (Float) -> Unit,
    onHapticToggle: (Boolean) -> Unit,
    onAutoIntervalChange: (Long) -> Unit,
    onKeepScreenOnToggle: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val brandColors = LocalSheenColors.current
    var showCustomIntervalDialog by remember { mutableStateOf(false) }
    val presetIntervals = listOf(1000L, 2000L, 3000L, 4000L, 5000L)
    val isCustomInterval = preferences.autoIntervalMs !in presetIntervals

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Appearance Section
        SettingsCard(title = "Appearance") {
            SettingLabel("Theme")
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = preferences.themeMode == mode,
                        onClick = { onThemeModeChange(mode) },
                        label = { Text(mode.label) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            SettingLabel("Accent Palette")
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                AccentPalette.entries.forEach { palette ->
                    FilterChip(
                        selected = preferences.accentPalette == palette,
                        onClick = { onAccentPaletteChange(palette) },
                        label = { Text(palette.label) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            SettingLabel("Counter Number Style")
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CounterFontStyle.entries.forEach { style ->
                    FilterChip(
                        selected = preferences.counterFontStyle == style,
                        onClick = { onFontStyleChange(style) },
                        label = { Text(style.label) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            SettingLabel("Counter Number Size")
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CounterFontSize.entries.forEach { size ->
                    FilterChip(
                        selected = preferences.counterFontSize == size,
                        onClick = { onFontSizeChange(size) },
                        label = { Text(size.label) }
                    )
                }
            }
        }

        // 2. Sound & Feedback Section
        SettingsCard(title = "Sound & Feedback") {
            SwitchRow(
                title = "Count Sound",
                subtitle = "Play a subtle sound on every manual and automatic count",
                checked = preferences.countSoundEnabled,
                onCheckedChange = onCountSoundToggle
            )

            Spacer(modifier = Modifier.height(12.dp))
            SettingLabel("Sound Tone (tap to preview)")
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CountSoundType.entries.forEach { sound ->
                    FilterChip(
                        selected = preferences.selectedSound == sound,
                        onClick = { onSoundSelected(sound) },
                        label = { Text(sound.label) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SettingLabel("Sound Volume")
                Text(
                    text = "${(preferences.soundVolume * 100).toInt()}%",
                    style = MaterialTheme.typography.labelLarge,
                    color = brandColors.gold
                )
            }
            Slider(
                value = preferences.soundVolume,
                onValueChange = onVolumeChange,
                valueRange = 0f..1f
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            SwitchRow(
                title = "Target Completion Sound",
                subtitle = "Play a gentle chime when your target is reached",
                checked = preferences.completionSoundEnabled,
                onCheckedChange = onCompletionSoundToggle
            )
            TextButton(onClick = onPreviewCompletionSound) {
                Text("Preview Completion Chime")
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            SwitchRow(
                title = "Haptic Feedback",
                subtitle = "Subtle tactile response on each count",
                checked = preferences.hapticEnabled,
                onCheckedChange = onHapticToggle
            )
        }

        // 3. Automatic Counting Preferences
        SettingsCard(title = "Automatic Counting") {
            SettingLabel("Default Interval")
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                presetIntervals.forEach { ms ->
                    FilterChip(
                        selected = preferences.autoIntervalMs == ms,
                        onClick = { onAutoIntervalChange(ms) },
                        label = { Text(formatIntervalLabel(ms)) }
                    )
                }
                FilterChip(
                    selected = isCustomInterval,
                    onClick = { showCustomIntervalDialog = true },
                    label = {
                        Text(
                            if (isCustomInterval) {
                                "Custom (${formatIntervalLabel(preferences.autoIntervalMs)})"
                            } else {
                                "Custom"
                            }
                        )
                    }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            SwitchRow(
                title = "Keep Screen Awake",
                subtitle = "Prevent the display from sleeping while SHEEN is open",
                checked = preferences.keepScreenOn,
                onCheckedChange = onKeepScreenOnToggle
            )

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Foreground-only guarantee: Automatic counting pauses immediately if you switch apps, minimize SHEEN, or lock your phone, and never resumes on its own.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // 4. About SHEEN
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, brandColors.cardBorder),
            tonalElevation = 1.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                SheenLogoMark(size = 64.dp)
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "SHEEN",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 3.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Your Zikr. Your Rhythm. Your Routine.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = brandColors.gold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Version ${BuildConfig.VERSION_NAME} • Offline & Private",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
    }

    if (showCustomIntervalDialog) {
        CustomIntervalDialog(
            currentIntervalMs = preferences.autoIntervalMs,
            onDismiss = { showCustomIntervalDialog = false },
            onConfirm = { newMs ->
                showCustomIntervalDialog = false
                onAutoIntervalChange(newMs)
            }
        )
    }
}

@Composable
private fun SettingsCard(
    title: String,
    content: @Composable () -> Unit
) {
    val brandColors = LocalSheenColors.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, brandColors.cardBorder),
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 1.2.sp),
                color = brandColors.gold
            )
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun SettingLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.padding(bottom = 6.dp)
    )
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
