package com.sheen.zikr.ui.viewmodel

import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.sheen.zikr.audio.HapticManager
import com.sheen.zikr.audio.SoundManager
import com.sheen.zikr.data.local.ZikrDailyLogEntity
import com.sheen.zikr.data.local.ZikrEntity
import com.sheen.zikr.data.local.ZikrHourlyLogEntity
import com.sheen.zikr.data.local.ZikrRepository
import com.sheen.zikr.data.preferences.AccentPalette
import com.sheen.zikr.data.preferences.CountSoundType
import com.sheen.zikr.data.preferences.CounterFontSize
import com.sheen.zikr.data.preferences.CounterFontStyle
import com.sheen.zikr.data.preferences.ThemeMode
import com.sheen.zikr.data.preferences.UserPreferences
import com.sheen.zikr.data.preferences.UserPreferencesRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class AutoCountStatus {
    STOPPED,
    RUNNING,
    PAUSED
}

data class AutoCountState(
    val status: AutoCountStatus = AutoCountStatus.STOPPED,
    val pausedNotice: String? = null,
    val nextTickProgress: Float = 0f
)

data class StopwatchState(
    val elapsedMs: Long = 0L,
    val isRunning: Boolean = false
)

data class RoundBanner(
    val zikrName: String,
    val roundNumber: Int,
    val timestamp: Long = System.currentTimeMillis()
)

data class SheenUiState(
    val zikrList: List<ZikrEntity> = emptyList(),
    val selectedZikr: ZikrEntity? = null,
    val preferences: UserPreferences = UserPreferences(),
    val autoCount: AutoCountState = AutoCountState(),
    val stopwatch: StopwatchState = StopwatchState(),
    val roundBanner: RoundBanner? = null,
    val isDimmed: Boolean = false,
    val isLoading: Boolean = true
)

object DuaLibrary {
    private val duas: List<String> = listOf(
        "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً\nوَّفِي الْآخِرَةِ حَسَنَةً وَّقِنَا عَذَابَ النَّارِ",
        "\"Our Lord, grant us good in this world,\ngood in the Hereafter, and protect us from the Fire.\"",
        "رَبِّ زِدْنِي عِلْمًا\nوَارْزُقْنِي فَهْمًا",
        "\"My Lord, increase me in knowledge\nand grant me sound understanding.\"",
        "رَبِّ اغْفِرْ وَارْحَمْ\nوَأَنْتَ خَيْرُ الرَّاحِمِينَ",
        "\"My Lord, forgive and have mercy,\nfor You are the Best of those who show mercy.\"",
        "رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا\nوَهَبْ لَنَا مِن لَّدُنكَ رَحْمَةً",
        "\"Our Lord, let not our hearts deviate after You have guided us,\nand grant us mercy from Yourself.\"",
        "رَبِّ اشْرَحْ لِي صَدْرِي\nوَيَسِّرْ لِي أَمْرِي",
        "\"My Lord, expand for me my chest\nand ease for me my task.\"",
        "رَبَّنَا تَقَبَّلْ مِنَّا\nإِنَّكَ أَنْتَ السَّمِيعُ الْعَلِيمُ",
        "\"Our Lord, accept this from us;\nindeed You are the All-Hearing, the All-Knowing.\"",
        "رَبِّ أَوْزِعْنِي أَنْ أَشْكُرَ نِعْمَتَكَ\nالَّتِي أَنْعَمْتَ عَلَيَّ وَعَلَىٰ وَالِدَيَّ",
        "\"My Lord, enable me to be grateful for Your favor\nwhich You have bestowed upon me and my parents.\"",
        "رَبَّنَا ظَلَمْنَا أَنفُسَنَا وَإِن لَّمْ تَغْفِرْ لَنَا\nوَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ",
        "\"Our Lord, we have wronged ourselves, and if You do not forgive us\nand have mercy upon us, we will surely be among the losers.\"",
        "اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ\nوَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ",
        "\"O Allah, help me to remember You,\nto give thanks to You, and to worship You in the best manner.\"",
        "اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا\nوَرِزْقًا طَيِّبًا وَعَمَلًا مُتَقَبَّلًا",
        "\"O Allah, I ask You for beneficial knowledge,\npure provision, and accepted deeds.\"",
        "يَا مُقَلِّبَ الْقُلُوبِ\nثَبِّتْ قَلْبِي عَلَى دِينِكَ",
        "\"O Turner of the hearts,\nkeep my heart firm upon Your religion.\"",
        "اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ\nفَاعْفُ عَنِّي",
        "\"O Allah, You are Most Forgiving and love forgiveness,\nso forgive me.\"",
        "رَبَّنَا هَبْ لَنَا مِنْ أَزْوَاجِنَا وَذُرِّيَّاتِنَا\nقُرَّةَ أَعْيُنٍ وَاجْعَلْنَا لِلْمُتَّقِينَ إِمَامًا",
        "\"Our Lord, grant us from among our spouses and offspring\ncomfort to our eyes and make us an example for the righteous.\"",
        "رَبِّ اجْعَلْنِي مُقِيمَ الصَّلَاةِ وَمِن ذُرِّيَّتِي\nرَبَّنَا وَتَقَبَّلْ دُعَاءِ",
        "\"My Lord, make me an establisher of prayer, and from my descendants.\nOur Lord, and accept my supplication.\"",
        "رَبَّنَا اغْفِرْ لَنَا ذُنُوبَنَا وَإِسْرَافَنَا فِي أَمْرِنَا\nوَثَبِّتْ أَقْدَامَنَا",
        "\"Our Lord, forgive us our sins and the excess in our affairs\nand plant firmly our feet.\"",
        "حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ\nنِعْمَ الْمَوْلَىٰ وَنِعْمَ النَّصِيرُ",
        "\"Sufficient for us is Allah, and He is the best Disposer of affairs,\nthe best Protector and the best Helper.\""
    )

    private var lastIndex: Int = -1

    fun duaForTick(seed: Int): String {
        val raw = ((seed * 7 + 3) % duas.size + duas.size) % duas.size
        val idx = if (raw == lastIndex) (raw + 1) % duas.size else raw
        lastIndex = idx
        return duas[idx]
    }
}

class SheenViewModel(
    private val zikrRepository: ZikrRepository,
    private val preferencesRepository: UserPreferencesRepository,
    private val soundManager: SoundManager,
    private val hapticManager: HapticManager
) : ViewModel() {

    private val _autoCountState = MutableStateFlow(AutoCountState())
    private val _stopwatchState = MutableStateFlow(StopwatchState())
    private val _roundBanner = MutableStateFlow<RoundBanner?>(null)
    private val _isDimmed = MutableStateFlow(false)
    private val _roundResetBoundaryIds = MutableStateFlow<Set<Long>>(emptySet())

    private var activeStopwatchZikrId: Long? = null

    val uiState: StateFlow<SheenUiState> = combine(
        zikrRepository.allZikr,
        preferencesRepository.preferencesFlow,
        _autoCountState,
        _stopwatchState,
        _roundBanner,
        _isDimmed
    ) { args ->
        @Suppress("UNCHECKED_CAST")
        val list = args[0] as List<ZikrEntity>
        val prefs = args[1] as UserPreferences
        val autoState = args[2] as AutoCountState
        val stopwatchState = args[3] as StopwatchState
        val banner = args[4] as RoundBanner?
        val dimmed = args[5] as Boolean
        val resetBoundaryIds = _roundResetBoundaryIds.value

        val rawSelected = list.firstOrNull { it.id == prefs.selectedZikrId } ?: list.firstOrNull()
        val selected = rawSelected?.copy()?.apply { isRoundResetAtBoundary = rawSelected.id in resetBoundaryIds }
        if (selected != null && activeStopwatchZikrId == null) {
            activeStopwatchZikrId = selected.id
            stopwatchAccumulatedMs = selected.currentRoundElapsedMs
            _stopwatchState.value = StopwatchState(elapsedMs = selected.currentRoundElapsedMs, isRunning = false)
        }
        SheenUiState(
            zikrList = list,
            selectedZikr = selected,
            preferences = prefs,
            autoCount = autoState,
            stopwatch = stopwatchState,
            roundBanner = banner,
            isDimmed = dimmed,
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = SheenUiState()
    )

    private var autoJob: Job? = null
    private var remainingUntilNextTickMs: Long = 0L
    private var bannerJob: Job? = null
    private var noticeJob: Job? = null

    private var stopwatchJob: Job? = null
    private var stopwatchAccumulatedMs: Long = 0L
    private var stopwatchSegmentStartMs: Long = 0L

    init {
        viewModelScope.launch {
            zikrRepository.ensureStarterDataIfEmpty()
        }
    }

    fun toggleDimming() {
        _isDimmed.value = !_isDimmed.value
    }

    fun observeHistory(zikrId: Long): Flow<List<ZikrDailyLogEntity>> =
        zikrRepository.observeHistory(zikrId)

    val allDailyLogs: Flow<List<ZikrDailyLogEntity>> = zikrRepository.allDailyLogs

    fun observeHourly(zikrId: Long, dateKey: String): Flow<List<ZikrHourlyLogEntity>> =
        zikrRepository.observeHourly(zikrId, dateKey)

    fun clearHistoryForZikrDay(zikrId: Long, dateKey: String) {
        if (uiState.value.selectedZikr?.id == zikrId) {
            stopAutoCounting()
            resetStopwatch()
        }
        viewModelScope.launch {
            zikrRepository.clearHistoryForZikrDay(zikrId, dateKey)
        }
    }

    fun clearHistoryForZikr(zikrId: Long) {
        if (uiState.value.selectedZikr?.id == zikrId) {
            stopAutoCounting()
            resetStopwatch()
        }
        viewModelScope.launch {
            zikrRepository.clearHistoryForZikr(zikrId)
        }
    }

    fun clearAllHistory() {
        stopAutoCounting()
        resetStopwatch()
        _roundResetBoundaryIds.value = emptySet()
        viewModelScope.launch {
            zikrRepository.clearAllHistory()
        }
    }

    fun selectZikr(zikrId: Long) {
        val current = uiState.value.selectedZikr
        if (current?.id != zikrId) {
            stopAutoCounting()
            if (current != null) {
                val outgoingElapsed = currentStopwatchElapsedMs()
                pauseStopwatchInternal(persist = false)
                viewModelScope.launch {
                    zikrRepository.saveStopwatchElapsed(current.id, outgoingElapsed)
                }
            }
            val target = uiState.value.zikrList.firstOrNull { it.id == zikrId }
            val incomingElapsed = target?.currentRoundElapsedMs ?: 0L
            activeStopwatchZikrId = zikrId
            stopwatchAccumulatedMs = incomingElapsed
            _stopwatchState.value = StopwatchState(elapsedMs = incomingElapsed, isRunning = false)

            viewModelScope.launch {
                preferencesRepository.setSelectedZikrId(zikrId)
            }
        }
    }

    fun cycleZikr(delta: Int) {
        val list = uiState.value.zikrList
        if (list.size <= 1) return
        val current = uiState.value.selectedZikr
        val currentIdx = list.indexOfFirst { it.id == current?.id }.coerceAtLeast(0)
        val nextIdx = ((currentIdx + delta) % list.size + list.size) % list.size
        selectZikr(list[nextIdx].id)
    }

    fun addZikr(name: String, targetCount: Int, selectImmediately: Boolean = true) {
        val trimmed = name.trim()
        if (trimmed.isEmpty() || targetCount <= 0) return
        viewModelScope.launch {
            if (selectImmediately) {
                val current = uiState.value.selectedZikr
                if (current != null) {
                    val outgoingElapsed = currentStopwatchElapsedMs()
                    pauseStopwatchInternal(persist = false)
                    zikrRepository.saveStopwatchElapsed(current.id, outgoingElapsed)
                }
                stopAutoCounting()
            }
            val newId = zikrRepository.addZikr(trimmed, targetCount)
            if (selectImmediately) {
                activeStopwatchZikrId = newId
                stopwatchAccumulatedMs = 0L
                _stopwatchState.value = StopwatchState(elapsedMs = 0L, isRunning = false)
                preferencesRepository.setSelectedZikrId(newId)
            }
        }
    }

    fun updateZikr(id: Long, name: String, targetCount: Int) {
        val trimmed = name.trim()
        if (trimmed.isEmpty() || targetCount <= 0) return
        viewModelScope.launch {
            zikrRepository.updateZikr(id, trimmed, targetCount)
        }
    }

    fun deleteZikr(id: Long) {
        if (uiState.value.selectedZikr?.id == id) {
            stopAutoCounting()
            pauseStopwatchInternal(persist = false)
            activeStopwatchZikrId = null
            stopwatchAccumulatedMs = 0L
            _stopwatchState.value = StopwatchState(elapsedMs = 0L, isRunning = false)
        }
        viewModelScope.launch {
            zikrRepository.deleteZikr(id)
        }
    }

    private fun currentStopwatchElapsedMs(): Long {
        return if (_stopwatchState.value.isRunning) {
            stopwatchAccumulatedMs + (SystemClock.elapsedRealtime() - stopwatchSegmentStartMs).coerceAtLeast(0L)
        } else {
            stopwatchAccumulatedMs
        }
    }

    fun toggleStopwatch() {
        if (_stopwatchState.value.isRunning) pauseStopwatch() else startStopwatch()
    }

    fun startStopwatch() {
        if (_stopwatchState.value.isRunning) return
        val currentId = uiState.value.selectedZikr?.id
        if (currentId != null) activeStopwatchZikrId = currentId
        stopwatchSegmentStartMs = SystemClock.elapsedRealtime()
        _stopwatchState.value = _stopwatchState.value.copy(isRunning = true)
        stopwatchJob?.cancel()
        stopwatchJob = viewModelScope.launch {
            while (isActive) {
                val now = SystemClock.elapsedRealtime()
                val total = stopwatchAccumulatedMs + (now - stopwatchSegmentStartMs).coerceAtLeast(0L)
                _stopwatchState.value = StopwatchState(elapsedMs = total, isRunning = true)
                delay(200L)
            }
        }
    }

    fun pauseStopwatch() {
        pauseStopwatchInternal(persist = true)
    }

    private fun pauseStopwatchInternal(persist: Boolean) {
        if (_stopwatchState.value.isRunning) {
            val now = SystemClock.elapsedRealtime()
            stopwatchAccumulatedMs += (now - stopwatchSegmentStartMs).coerceAtLeast(0L)
            stopwatchJob?.cancel()
            stopwatchJob = null
            _stopwatchState.value = StopwatchState(elapsedMs = stopwatchAccumulatedMs, isRunning = false)
        }
        if (persist) {
            val zikrId = activeStopwatchZikrId ?: uiState.value.selectedZikr?.id
            if (zikrId != null) {
                val saved = stopwatchAccumulatedMs
                viewModelScope.launch {
                    zikrRepository.saveStopwatchElapsed(zikrId, saved)
                }
            }
        }
    }

    fun resetStopwatch() {
        stopwatchJob?.cancel()
        stopwatchJob = null
        stopwatchAccumulatedMs = 0L
        _stopwatchState.value = StopwatchState(elapsedMs = 0L, isRunning = false)
        val zikrId = activeStopwatchZikrId ?: uiState.value.selectedZikr?.id
        if (zikrId != null) {
            viewModelScope.launch {
                zikrRepository.saveStopwatchElapsed(zikrId, 0L)
            }
        }
    }

    fun incrementManual() {
        if (_autoCountState.value.status == AutoCountStatus.RUNNING) {
            pauseInternal("Auto paused")
        }
        performIncrement().incremented
    }

    fun decrementManual() {
        if (_autoCountState.value.status == AutoCountStatus.RUNNING) {
            pauseInternal("Auto paused")
        }
        val current = uiState.value.selectedZikr ?: return
        if (current.currentCount <= 0) return
        val nextCount = current.currentCount - 1
        val nextRounds = if (current.targetCount > 0) nextCount / current.targetCount else 0
        val roundDelta = if (nextRounds < current.rounds) -1 else 0
        if (uiState.value.preferences.hapticEnabled) {
            hapticManager.tick()
        }
        viewModelScope.launch {
            zikrRepository.updateProgress(
                id = current.id,
                currentCount = nextCount,
                completedRounds = nextRounds,
                dailyCountDelta = -1,
                dailyRoundDelta = roundDelta
            )
        }
    }

    fun resetRoundsToZero() {
        val current = uiState.value.selectedZikr ?: return
        stopAutoCounting()
        _roundResetBoundaryIds.value = _roundResetBoundaryIds.value + current.id
        viewModelScope.launch {
            zikrRepository.resetRoundsToZero(current.id)
        }
    }

    fun resetCurrentCount() {
        val current = uiState.value.selectedZikr ?: return
        stopAutoCounting()
        resetStopwatch()
        viewModelScope.launch {
            zikrRepository.updateProgress(
                id = current.id,
                currentCount = 0,
                completedRounds = 0,
                dailyCountDelta = 0,
                dailyRoundDelta = 0
            )
        }
    }

    private fun isGoalMilestone(count: Int): Boolean {
        if (count <= 0) return false
        if (count == 33 || count == 66 || count == 99) return true
        return count >= 100 && count % 100 == 0
    }

    private data class IncrementOutcome(
        val incremented: Boolean,
        val roundCompleted: Boolean
    )

    private fun performIncrement(): IncrementOutcome {
        val state = uiState.value
        val current = state.selectedZikr ?: return IncrementOutcome(incremented = false, roundCompleted = false)
        _roundResetBoundaryIds.value = _roundResetBoundaryIds.value - current.id
        val prefs = state.preferences

        if (!_stopwatchState.value.isRunning) {
            startStopwatch()
        }

        val nextCount = current.currentCount + 1
        val completedRoundNow = current.targetCount > 0 && nextCount % current.targetCount == 0
        val nextRounds = if (current.targetCount > 0) nextCount / current.targetCount else 0
        val hitGoalMilestone = isGoalMilestone(nextCount)

        val completedDurationMs = if (completedRoundNow) {
            val dur = currentStopwatchElapsedMs()
            stopwatchJob?.cancel()
            stopwatchJob = null
            stopwatchAccumulatedMs = 0L
            _stopwatchState.value = StopwatchState(elapsedMs = 0L, isRunning = false)
            dur
        } else 0L

        viewModelScope.launch {
            zikrRepository.updateProgress(
                id = current.id,
                currentCount = nextCount,
                completedRounds = nextRounds,
                dailyCountDelta = 1,
                dailyRoundDelta = if (completedRoundNow) 1 else 0
            )
            if (completedRoundNow) {
                zikrRepository.recordRoundTiming(current.id, completedDurationMs)
            }
        }

        if (hitGoalMilestone) {
            if (prefs.countSoundEnabled || prefs.completionSoundEnabled) {
                soundManager.playHundredMilestoneSound(prefs.soundVolume)
            }
            if (prefs.hapticEnabled) {
                hapticManager.hundredMilestone()
            }
        } else if (completedRoundNow) {
            if (prefs.completionSoundEnabled) {
                soundManager.playCompletionSound(prefs.soundVolume)
            }
            if (prefs.hapticEnabled) {
                hapticManager.roundComplete()
            }
        } else {
            if (prefs.countSoundEnabled) {
                soundManager.playCountSound(prefs.selectedSound, prefs.soundVolume)
            }
            if (prefs.hapticEnabled) {
                hapticManager.tick()
            }
        }

        if (completedRoundNow) {
            showRoundBanner(current.name, nextRounds)
        }
        return IncrementOutcome(incremented = true, roundCompleted = completedRoundNow)
    }

    private fun showRoundBanner(zikrName: String, roundNumber: Int) {
        bannerJob?.cancel()
        _roundBanner.value = RoundBanner(zikrName = zikrName, roundNumber = roundNumber)
        bannerJob = viewModelScope.launch {
            delay(2600L)
            _roundBanner.value = null
        }
    }

    fun startAutoCountingWithInterval(intervalMs: Long) {
        val clamped = intervalMs.coerceIn(300L, 300_000L)
        viewModelScope.launch {
            preferencesRepository.setAutoIntervalMs(clamped)
        }
        remainingUntilNextTickMs = clamped
        launchAutoLoop(clamped)
    }

    fun resumeAutoCounting() {
        if (_autoCountState.value.status != AutoCountStatus.PAUSED) return
        val intervalMs = uiState.value.preferences.autoIntervalMs.coerceAtLeast(300L)
        if (remainingUntilNextTickMs <= 0L || remainingUntilNextTickMs > intervalMs) {
            remainingUntilNextTickMs = intervalMs
        }
        launchAutoLoop(intervalMs)
    }

    fun pauseAutoCounting() {
        pauseInternal(null)
    }

    fun pauseAutoCountingFromLifecycle() {
        if (_autoCountState.value.status == AutoCountStatus.RUNNING) {
            pauseInternal("Paused")
        }
        pauseStopwatchInternal(persist = true)
    }

    private fun pauseInternal(notice: String?) {
        if (_autoCountState.value.status != AutoCountStatus.RUNNING) return
        autoJob?.cancel()
        autoJob = null
        _autoCountState.value = _autoCountState.value.copy(
            status = AutoCountStatus.PAUSED,
            pausedNotice = notice
        )
        if (notice != null) {
            noticeJob?.cancel()
            noticeJob = viewModelScope.launch {
                delay(3200L)
                _autoCountState.value = _autoCountState.value.copy(pausedNotice = null)
            }
        }
    }

    fun stopAutoCounting() {
        autoJob?.cancel()
        autoJob = null
        noticeJob?.cancel()
        remainingUntilNextTickMs = 0L
        _autoCountState.value = AutoCountState(
            status = AutoCountStatus.STOPPED,
            pausedNotice = null,
            nextTickProgress = 0f
        )
    }

    private fun launchAutoLoop(initialIntervalMs: Long) {
        autoJob?.cancel()
        noticeJob?.cancel()
        val startMs = SystemClock.elapsedRealtime()
        var nextTickAtMs = startMs + remainingUntilNextTickMs

        _autoCountState.value = AutoCountState(
            status = AutoCountStatus.RUNNING,
            pausedNotice = null,
            nextTickProgress = (1f - remainingUntilNextTickMs.toFloat() / initialIntervalMs.toFloat()).coerceIn(0f, 1f)
        )

        autoJob = viewModelScope.launch {
            while (isActive) {
                val intervalMs = uiState.value.preferences.autoIntervalMs.coerceAtLeast(300L)
                val now = SystemClock.elapsedRealtime()
                val remaining = nextTickAtMs - now

                if (remaining <= 0L) {
                    val outcome = performIncrement()
                    if (!outcome.incremented) break
                    if (outcome.roundCompleted) {
                        remainingUntilNextTickMs = 0L
                        _autoCountState.value = AutoCountState(
                            status = AutoCountStatus.STOPPED,
                            pausedNotice = null,
                            nextTickProgress = 0f
                        )
                        autoJob = null
                        break
                    }
                    nextTickAtMs = maxOf(nextTickAtMs + intervalMs, SystemClock.elapsedRealtime() + 50L)
                    remainingUntilNextTickMs = intervalMs
                    _autoCountState.value = _autoCountState.value.copy(nextTickProgress = 0f)
                } else {
                    remainingUntilNextTickMs = remaining
                    val tickProgress = (1f - remaining.toFloat() / intervalMs.toFloat()).coerceIn(0f, 1f)
                    _autoCountState.value = _autoCountState.value.copy(nextTickProgress = tickProgress)
                    delay(minOf(remaining, 40L))
                }
            }
        }
    }

    fun setThemeMode(mode: ThemeMode) { viewModelScope.launch { preferencesRepository.setThemeMode(mode) } }
    fun setAccentPalette(palette: AccentPalette) { viewModelScope.launch { preferencesRepository.setAccentPalette(palette) } }
    fun setCounterFontStyle(style: CounterFontStyle) { viewModelScope.launch { preferencesRepository.setCounterFontStyle(style) } }
    fun setCounterFontSize(size: CounterFontSize) { viewModelScope.launch { preferencesRepository.setCounterFontSize(size) } }
    fun setCountSoundEnabled(enabled: Boolean) { viewModelScope.launch { preferencesRepository.setCountSoundEnabled(enabled) } }
    fun setCompletionSoundEnabled(enabled: Boolean) { viewModelScope.launch { preferencesRepository.setCompletionSoundEnabled(enabled) } }
    fun setSelectedSound(sound: CountSoundType) {
        viewModelScope.launch { preferencesRepository.setSelectedSound(sound) }
        soundManager.playCountSound(sound, uiState.value.preferences.soundVolume)
    }
    fun setSoundVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        viewModelScope.launch { preferencesRepository.setSoundVolume(clamped) }
        soundManager.playCountSound(uiState.value.preferences.selectedSound, clamped)
    }
    fun setHapticEnabled(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.setHapticEnabled(enabled) }
        if (enabled) hapticManager.tick()
    }
    fun setVolumeButtonsEnabled(enabled: Boolean) { viewModelScope.launch { preferencesRepository.setVolumeButtonsEnabled(enabled) } }
    fun setKeepScreenOn(enabled: Boolean) { viewModelScope.launch { preferencesRepository.setKeepScreenOn(enabled) } }

    override fun onCleared() {
        super.onCleared()
        autoJob?.cancel()
        stopwatchJob?.cancel()
    }

    class Factory(
        private val zikrRepository: ZikrRepository,
        private val preferencesRepository: UserPreferencesRepository,
        private val soundManager: SoundManager,
        private val hapticManager: HapticManager
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SheenViewModel(zikrRepository, preferencesRepository, soundManager, hapticManager) as T
        }
    }
}
