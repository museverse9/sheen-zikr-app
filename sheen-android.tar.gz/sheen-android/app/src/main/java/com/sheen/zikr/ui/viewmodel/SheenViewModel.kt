package com.sheen.zikr.ui.viewmodel

import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.sheen.zikr.audio.HapticManager
import com.sheen.zikr.audio.SoundManager
import com.sheen.zikr.data.local.ZikrDailyLogEntity
import com.sheen.zikr.data.local.ZikrEntity
import com.sheen.zikr.data.local.ZikrHourlyLogEntity
import com.sheen.zikr.data.local.ZikrRepository
import com.sheen.zikr.data.preferences.AccentPalette
import com.sheen.zikr.data.preferences.CountSoundType
import com.sheen.zikr.data.preferences.CounterFontSize
import com.sheen.zikr.data.preferences.CounterFontStyle
import com.sheen.zikr.data.preferences.ThemeMode
import com.sheen.zikr.data.preferences.UserPreferences
import com.sheen.zikr.data.preferences.UserPreferencesRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class AutoCountStatus {
    STOPPED,
    RUNNING,
    PAUSED
}

data class AutoCountState(
    val status: AutoCountStatus = AutoCountStatus.STOPPED,
    val pausedNotice: String? = null,
    val nextTickProgress: Float = 0f
)

data class StopwatchState(
    val elapsedMs: Long = 0L,
    val isRunning: Boolean = false
)

data class RoundBanner(
    val zikrName: String,
    val roundNumber: Int,
    val timestamp: Long = System.currentTimeMillis()
)

data class SheenUiState(
    val zikrList: List<ZikrEntity> = emptyList(),
    val selectedZikr: ZikrEntity? = null,
    val preferences: UserPreferences = UserPreferences(),
    val autoCount: AutoCountState = AutoCountState(),
    val stopwatch: StopwatchState = StopwatchState(),
    val roundBanner: RoundBanner? = null,
    val isLoading: Boolean = true
)

class SheenViewModel(
    private val zikrRepository: ZikrRepository,
    private val preferencesRepository: UserPreferencesRepository,
    private val soundManager: SoundManager,
    private val hapticManager: HapticManager
) : ViewModel() {

    private val _autoCountState = MutableStateFlow(AutoCountState())
    private val _stopwatchState = MutableStateFlow(StopwatchState())
    private val _roundBanner = MutableStateFlow<RoundBanner?>(null)

    private var activeStopwatchZikrId: Long? = null

    val uiState: StateFlow<SheenUiState> = combine(
        zikrRepository.allZikr,
        preferencesRepository.preferencesFlow,
        _autoCountState,
        _stopwatchState,
        _roundBanner
    ) { list, prefs, autoState, stopwatchState, banner ->
        val selected = list.firstOrNull { it.id == prefs.selectedZikrId } ?: list.firstOrNull()
        // Sync stopwatch when first loading a Zikr from disk
        if (selected != null && activeStopwatchZikrId == null) {
            activeStopwatchZikrId = selected.id
            stopwatchAccumulatedMs = selected.currentRoundElapsedMs
            _stopwatchState.value = StopwatchState(elapsedMs = selected.currentRoundElapsedMs, isRunning = false)
        }
        SheenUiState(
            zikrList = list,
            selectedZikr = selected,
            preferences = prefs,
            autoCount = autoState,
            stopwatch = stopwatchState,
            roundBanner = banner,
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = SheenUiState()
    )

    private var autoJob: Job? = null
    private var remainingUntilNextTickMs: Long = 0L
    private var bannerJob: Job? = null
    private var noticeJob: Job? = null

    private var stopwatchJob: Job? = null
    private var stopwatchAccumulatedMs: Long = 0L
    private var stopwatchSegmentStartMs: Long = 0L

    init {
        viewModelScope.launch {
            zikrRepository.ensureStarterDataIfEmpty()
        }
    }

    fun observeHistory(zikrId: Long): Flow<List<ZikrDailyLogEntity>> =
        zikrRepository.observeHistory(zikrId)

    val allDailyLogs: Flow<List<ZikrDailyLogEntity>> = zikrRepository.allDailyLogs

    fun observeHourly(zikrId: Long, dateKey: String): Flow<List<ZikrHourlyLogEntity>> =
        zikrRepository.observeHourly(zikrId, dateKey)

    fun clearHistoryForZikr(zikrId: Long) {
        if (uiState.value.selectedZikr?.id == zikrId) {
            stopAutoCounting()
            resetStopwatch()
        }
        viewModelScope.launch {
            zikrRepository.clearHistoryForZikr(zikrId)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            zikrRepository.clearAllHistory()
        }
    }

    // ---------------------------------------------------------
    // Zikr CRUD & Selection (Pauses & saves outgoing stopwatch, restores incoming)
    // ---------------------------------------------------------
    fun selectZikr(zikrId: Long) {
        val current = uiState.value.selectedZikr
        if (current?.id != zikrId) {
            stopAutoCounting()
            // Pause and save outgoing Zikr's stopwatch
            if (current != null) {
                val outgoingElapsed = currentStopwatchElapsedMs()
                pauseStopwatchInternal(persist = false)
                viewModelScope.launch {
                    zikrRepository.saveStopwatchElapsed(current.id, outgoingElapsed)
                }
            }
            // Restore incoming Zikr's paused stopwatch
            val target = uiState.value.zikrList.firstOrNull { it.id == zikrId }
            val incomingElapsed = target?.currentRoundElapsedMs ?: 0L
            activeStopwatchZikrId = zikrId
            stopwatchAccumulatedMs = incomingElapsed
            _stopwatchState.value = StopwatchState(elapsedMs = incomingElapsed, isRunning = false)

            viewModelScope.launch {
                preferencesRepository.setSelectedZikrId(zikrId)
            }
        }
    }

    fun addZikr(name: String, targetCount: Int, selectImmediately: Boolean = true) {
        val trimmed = name.trim()
        if (trimmed.isEmpty() || targetCount <= 0) return
        viewModelScope.launch {
            if (selectImmediately) {
                val current = uiState.value.selectedZikr
                if (current != null) {
                    val outgoingElapsed = currentStopwatchElapsedMs()
                    pauseStopwatchInternal(persist = false)
                    zikrRepository.saveStopwatchElapsed(current.id, outgoingElapsed)
                }
                stopAutoCounting()
            }
            val newId = zikrRepository.addZikr(trimmed, targetCount)
            if (selectImmediately) {
                activeStopwatchZikrId = newId
                stopwatchAccumulatedMs = 0L
                _stopwatchState.value = StopwatchState(elapsedMs = 0L, isRunning = false)
                preferencesRepository.setSelectedZikrId(newId)
            }
        }
    }

    fun updateZikr(id: Long, name: String, targetCount: Int) {
        val trimmed = name.trim()
        if (trimmed.isEmpty() || targetCount <= 0) return
        viewModelScope.launch {
            zikrRepository.updateZikr(id, trimmed, targetCount)
        }
    }

    fun deleteZikr(id: Long) {
        if (uiState.value.selectedZikr?.id == id) {
            stopAutoCounting()
            pauseStopwatchInternal(persist = false)
            activeStopwatchZikrId = null
            stopwatchAccumulatedMs = 0L
            _stopwatchState.value = StopwatchState(elapsedMs = 0L, isRunning = false)
        }
        viewModelScope.launch {
            zikrRepository.deleteZikr(id)
        }
    }

    // ---------------------------------------------------------
    // Per-Zikr Stopwatch Controls
    // ---------------------------------------------------------
    private fun currentStopwatchElapsedMs(): Long {
        return if (_stopwatchState.value.isRunning) {
            stopwatchAccumulatedMs + (SystemClock.elapsedRealtime() - stopwatchSegmentStartMs).coerceAtLeast(0L)
        } else {
            stopwatchAccumulatedMs
        }
    }

    fun toggleStopwatch() {
        if (_stopwatchState.value.isRunning) pauseStopwatch() else startStopwatch()
    }

    fun startStopwatch() {
        if (_stopwatchState.value.isRunning) return
        val currentId = uiState.value.selectedZikr?.id
        if (currentId != null) activeStopwatchZikrId = currentId
        stopwatchSegmentStartMs = SystemClock.elapsedRealtime()
        _stopwatchState.value = _stopwatchState.value.copy(isRunning = true)
        stopwatchJob?.cancel()
        stopwatchJob = viewModelScope.launch {
            while (isActive) {
                val now = SystemClock.elapsedRealtime()
                val total = stopwatchAccumulatedMs + (now - stopwatchSegmentStartMs).coerceAtLeast(0L)
                _stopwatchState.value = StopwatchState(elapsedMs = total, isRunning = true)
                delay(200L)
            }
        }
    }

    fun pauseStopwatch() {
        pauseStopwatchInternal(persist = true)
    }

    private fun pauseStopwatchInternal(persist: Boolean) {
        if (_stopwatchState.value.isRunning) {
            val now = SystemClock.elapsedRealtime()
            stopwatchAccumulatedMs += (now - stopwatchSegmentStartMs).coerceAtLeast(0L)
            stopwatchJob?.cancel()
            stopwatchJob = null
            _stopwatchState.value = StopwatchState(elapsedMs = stopwatchAccumulatedMs, isRunning = false)
        }
        if (persist) {
            val zikrId = activeStopwatchZikrId ?: uiState.value.selectedZikr?.id
            if (zikrId != null) {
                val saved = stopwatchAccumulatedMs
                viewModelScope.launch {
                    zikrRepository.saveStopwatchElapsed(zikrId, saved)
                }
            }
        }
    }

    fun resetStopwatch() {
        stopwatchJob?.cancel()
        stopwatchJob = null
        stopwatchAccumulatedMs = 0L
        _stopwatchState.value = StopwatchState(elapsedMs = 0L, isRunning = false)
        val zikrId = activeStopwatchZikrId ?: uiState.value.selectedZikr?.id
        if (zikrId != null) {
            viewModelScope.launch {
                zikrRepository.saveStopwatchElapsed(zikrId, 0L)
            }
        }
    }

    // ---------------------------------------------------------
    // Counting Controls (Manual, Volume Keys & Auto)
    // ---------------------------------------------------------
    fun incrementManual() {
        if (_autoCountState.value.status == AutoCountStatus.RUNNING) {
            pauseInternal("Auto paused")
        }
        performIncrement()
    }

    fun decrementManual() {
        if (_autoCountState.value.status == AutoCountStatus.RUNNING) {
            pauseInternal("Auto paused")
        }
        val current = uiState.value.selectedZikr ?: return
        if (current.currentCount <= 0) return
        val nextCount = current.currentCount - 1
        val nextRounds = if (current.targetCount > 0) nextCount / current.targetCount else 0
        val roundDelta = if (nextRounds < current.rounds) -1 else 0
        if (uiState.value.preferences.hapticEnabled) {
            hapticManager.tick()
        }
        viewModelScope.launch {
            zikrRepository.updateProgress(
                id = current.id,
                currentCount = nextCount,
                completedRounds = nextRounds,
                dailyCountDelta = -1,
                dailyRoundDelta = roundDelta
            )
        }
    }

    fun resetCurrentCount() {
        val current = uiState.value.selectedZikr ?: return
        stopAutoCounting()
        resetStopwatch()
        viewModelScope.launch {
            zikrRepository.updateProgress(
                id = current.id,
                currentCount = 0,
                completedRounds = 0,
                dailyCountDelta = 0,
                dailyRoundDelta = 0
            )
        }
    }

    private fun performIncrement(): Boolean {
        val state = uiState.value
        val current = state.selectedZikr ?: return false
        val prefs = state.preferences

        // Auto-start stopwatch on first count of the round
        if (!_stopwatchState.value.isRunning) {
            startStopwatch()
        }

        val nextCount = current.currentCount + 1
        val completedRoundNow = current.targetCount > 0 && nextCount % current.targetCount == 0
        val nextRounds = if (current.targetCount > 0) nextCount / current.targetCount else 0

        // Capture round duration & reset stopwatch immediately when a round completes
        val completedDurationMs = if (completedRoundNow) {
            val dur = currentStopwatchElapsedMs()
            stopwatchJob?.cancel()
            stopwatchJob = null
            stopwatchAccumulatedMs = 0L
            _stopwatchState.value = StopwatchState(elapsedMs = 0L, isRunning = false)
            dur
        } else 0L

        viewModelScope.launch {
            zikrRepository.updateProgress(
                id = current.id,
                currentCount = nextCount,
                completedRounds = nextRounds,
                dailyCountDelta = 1,
                dailyRoundDelta = if (completedRoundNow) 1 else 0
            )
            if (completedRoundNow) {
                zikrRepository.recordRoundTiming(current.id, completedDurationMs)
            }
        }

        if (completedRoundNow) {
            if (prefs.completionSoundEnabled) {
                soundManager.playCompletionSound(prefs.soundVolume)
            } else if (prefs.countSoundEnabled) {
                soundManager.playCountSound(prefs.selectedSound, prefs.soundVolume)
            }
            if (prefs.hapticEnabled) {
                hapticManager.roundComplete()
            }
            showRoundBanner(current.name, nextRounds)
        } else {
            if (prefs.countSoundEnabled) {
                soundManager.playCountSound(prefs.selectedSound, prefs.soundVolume)
            }
            if (prefs.hapticEnabled) {
                hapticManager.tick()
            }
        }
        return true
    }

    private fun showRoundBanner(zikrName: String, roundNumber: Int) {
        bannerJob?.cancel()
        _roundBanner.value = RoundBanner(zikrName = zikrName, roundNumber = roundNumber)
        bannerJob = viewModelScope.launch {
            delay(2600L)
            _roundBanner.value = null
        }
    }

    // ---------------------------------------------------------
    // Automatic Hands-Free Counting (Foreground-Only)
    // ---------------------------------------------------------
    fun startAutoCountingWithInterval(intervalMs: Long) {
        val clamped = intervalMs.coerceIn(300L, 300_000L)
        viewModelScope.launch {
            preferencesRepository.setAutoIntervalMs(clamped)
        }
        remainingUntilNextTickMs = clamped
        launchAutoLoop(clamped)
    }

    fun resumeAutoCounting() {
        if (_autoCountState.value.status != AutoCountStatus.PAUSED) return
        val intervalMs = uiState.value.preferences.autoIntervalMs.coerceAtLeast(300L)
        if (remainingUntilNextTickMs <= 0L || remainingUntilNextTickMs > intervalMs) {
            remainingUntilNextTickMs = intervalMs
        }
        launchAutoLoop(intervalMs)
    }

    fun pauseAutoCounting() {
        pauseInternal(null)
    }

    fun pauseAutoCountingFromLifecycle() {
        if (_autoCountState.value.status == AutoCountStatus.RUNNING) {
            pauseInternal("Paused")
        }
        pauseStopwatchInternal(persist = true)
    }

    private fun pauseInternal(notice: String?) {
        if (_autoCountState.value.status != AutoCountStatus.RUNNING) return
        autoJob?.cancel()
        autoJob = null
        _autoCountState.value = _autoCountState.value.copy(
            status = AutoCountStatus.PAUSED,
            pausedNotice = notice
        )
        if (notice != null) {
            noticeJob?.cancel()
            noticeJob = viewModelScope.launch {
                delay(3200L)
                _autoCountState.value = _autoCountState.value.copy(pausedNotice = null)
            }
        }
    }

    fun stopAutoCounting() {
        autoJob?.cancel()
        autoJob = null
        noticeJob?.cancel()
        remainingUntilNextTickMs = 0L
        _autoCountState.value = AutoCountState(
            status = AutoCountStatus.STOPPED,
            pausedNotice = null,
            nextTickProgress = 0f
        )
    }

    private fun launchAutoLoop(initialIntervalMs: Long) {
        autoJob?.cancel()
        noticeJob?.cancel()
        val startMs = SystemClock.elapsedRealtime()
        var nextTickAtMs = startMs + remainingUntilNextTickMs

        _autoCountState.value = AutoCountState(
            status = AutoCountStatus.RUNNING,
            pausedNotice = null,
            nextTickProgress = (1f - remainingUntilNextTickMs.toFloat() / initialIntervalMs.toFloat()).coerceIn(0f, 1f)
        )

        autoJob = viewModelScope.launch {
            while (isActive) {
                val intervalMs = uiState.value.preferences.autoIntervalMs.coerceAtLeast(300L)
                val now = SystemClock.elapsedRealtime()
                val remaining = nextTickAtMs - now

                if (remaining <= 0L) {
                    val ok = performIncrement()
                    if (!ok) break
                    nextTickAtMs = maxOf(nextTickAtMs + intervalMs, SystemClock.elapsedRealtime() + 50L)
                    remainingUntilNextTickMs = intervalMs
                    _autoCountState.value = _autoCountState.value.copy(nextTickProgress = 0f)
                } else {
                    remainingUntilNextTickMs = remaining
                    val tickProgress = (1f - remaining.toFloat() / intervalMs.toFloat()).coerceIn(0f, 1f)
                    _autoCountState.value = _autoCountState.value.copy(nextTickProgress = tickProgress)
                    delay(minOf(remaining, 40L))
                }
            }
        }
    }

    // ---------------------------------------------------------
    // Preferences
    // ---------------------------------------------------------
    fun setAutoIntervalMs(intervalMs: Long) {
        viewModelScope.launch { preferencesRepository.setAutoIntervalMs(intervalMs.coerceIn(300L, 300_000L)) }
    }
    fun setThemeMode(mode: ThemeMode) { viewModelScope.launch { preferencesRepository.setThemeMode(mode) } }
    fun setAccentPalette(palette: AccentPalette) { viewModelScope.launch { preferencesRepository.setAccentPalette(palette) } }
    fun setCounterFontStyle(style: CounterFontStyle) { viewModelScope.launch { preferencesRepository.setCounterFontStyle(style) } }
    fun setCounterFontSize(size: CounterFontSize) { viewModelScope.launch { preferencesRepository.setCounterFontSize(size) } }
    fun setCountSoundEnabled(enabled: Boolean) { viewModelScope.launch { preferencesRepository.setCountSoundEnabled(enabled) } }
    fun setCompletionSoundEnabled(enabled: Boolean) { viewModelScope.launch { preferencesRepository.setCompletionSoundEnabled(enabled) } }
    fun setSelectedSound(sound: CountSoundType) {
        viewModelScope.launch { preferencesRepository.setSelectedSound(sound) }
        soundManager.playCountSound(sound, uiState.value.preferences.soundVolume)
    }
    fun previewCompletionSound() { soundManager.playCompletionSound(uiState.value.preferences.soundVolume) }
    fun setSoundVolume(volume: Float) { viewModelScope.launch { preferencesRepository.setSoundVolume(volume) } }
    fun setHapticEnabled(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.setHapticEnabled(enabled) }
        if (enabled) hapticManager.tick()
    }
    fun setVolumeButtonsEnabled(enabled: Boolean) { viewModelScope.launch { preferencesRepository.setVolumeButtonsEnabled(enabled) } }
    fun setKeepScreenOn(enabled: Boolean) { viewModelScope.launch { preferencesRepository.setKeepScreenOn(enabled) } }

    override fun onCleared() {
        super.onCleared()
        autoJob?.cancel()
        stopwatchJob?.cancel()
    }

    class Factory(
        private val zikrRepository: ZikrRepository,
        private val preferencesRepository: UserPreferencesRepository,
        private val soundManager: SoundManager,
        private val hapticManager: HapticManager
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SheenViewModel(zikrRepository, preferencesRepository, soundManager, hapticManager) as T
        }
    }
}
