package com.sheen.zikr.ui.viewmodel

import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.sheen.zikr.audio.SoundManager
import com.sheen.zikr.data.local.ZikrEntity
import com.sheen.zikr.data.local.ZikrRepository
import com.sheen.zikr.data.preferences.AccentPalette
import com.sheen.zikr.data.preferences.CountSoundType
import com.sheen.zikr.data.preferences.CounterFontSize
import com.sheen.zikr.data.preferences.CounterFontStyle
import com.sheen.zikr.data.preferences.ThemeMode
import com.sheen.zikr.data.preferences.UserPreferences
import com.sheen.zikr.data.preferences.UserPreferencesRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class AutoCountStatus {
    STOPPED,
    RUNNING,
    PAUSED
}

data class AutoCountState(
    val status: AutoCountStatus = AutoCountStatus.STOPPED,
    val pausedByLifecycle: Boolean = false,
    val elapsedSessionMs: Long = 0L,
    val nextTickProgress: Float = 0f
)

data class SheenUiState(
    val zikrList: List<ZikrEntity> = emptyList(),
    val selectedZikr: ZikrEntity? = null,
    val preferences: UserPreferences = UserPreferences(),
    val autoCount: AutoCountState = AutoCountState(),
    val isLoading: Boolean = true
)

sealed interface SheenUiEvent {
    data class TargetReached(val zikrName: String, val target: Int) : SheenUiEvent
    data object HapticTick : SheenUiEvent
    data object HapticComplete : SheenUiEvent
}

class SheenViewModel(
    private val zikrRepository: ZikrRepository,
    private val preferencesRepository: UserPreferencesRepository,
    private val soundManager: SoundManager
) : ViewModel() {

    private val _autoCountState = MutableStateFlow(AutoCountState())
    private val _events = MutableSharedFlow<SheenUiEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<SheenUiEvent> = _events.asSharedFlow()

    val uiState: StateFlow<SheenUiState> = combine(
        zikrRepository.allZikr,
        preferencesRepository.preferencesFlow,
        _autoCountState
    ) { list, prefs, autoState ->
        val selected = list.firstOrNull { it.id == prefs.selectedZikrId } ?: list.firstOrNull()
        SheenUiState(
            zikrList = list,
            selectedZikr = selected,
            preferences = prefs,
            autoCount = autoState,
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = SheenUiState()
    )

    private var autoJob: Job? = null
    private var remainingUntilNextTickMs: Long = 0L
    private var accumulatedSessionMs: Long = 0L
    private var segmentStartElapsedMs: Long = 0L

    init {
        viewModelScope.launch {
            zikrRepository.ensureStarterDataIfEmpty()
        }
    }

    // ---------------------------------------------------------
    // Zikr CRUD & Selection
    // ---------------------------------------------------------
    fun selectZikr(zikrId: Long) {
        if (uiState.value.selectedZikr?.id != zikrId) {
            stopAutoCounting()
            viewModelScope.launch {
                preferencesRepository.setSelectedZikrId(zikrId)
            }
        }
    }

    fun addZikr(name: String, targetCount: Int, selectImmediately: Boolean = true) {
        val trimmed = name.trim()
        if (trimmed.isEmpty() || targetCount <= 0) return
        viewModelScope.launch {
            val newId = zikrRepository.addZikr(trimmed, targetCount)
            if (selectImmediately) {
                stopAutoCounting()
                preferencesRepository.setSelectedZikrId(newId)
            }
        }
    }

    fun updateZikr(id: Long, name: String, targetCount: Int) {
        val trimmed = name.trim()
        if (trimmed.isEmpty() || targetCount <= 0) return
        viewModelScope.launch {
            zikrRepository.updateZikr(id, trimmed, targetCount)
        }
    }

    fun deleteZikr(id: Long) {
        if (uiState.value.selectedZikr?.id == id) {
            stopAutoCounting()
        }
        viewModelScope.launch {
            zikrRepository.deleteZikr(id)
        }
    }

    // ---------------------------------------------------------
    // Counting Controls (Manual & Shared)
    // ---------------------------------------------------------
    fun incrementManual() {
        performIncrement(isAuto = false)
    }

    fun decrementManual() {
        val current = uiState.value.selectedZikr ?: return
        if (current.currentCount <= 0) return
        viewModelScope.launch {
            zikrRepository.updateProgress(
                id = current.id,
                currentCount = current.currentCount - 1,
                completedRounds = current.completedRounds
            )
        }
    }

    fun resetCurrentCount() {
        val current = uiState.value.selectedZikr ?: return
        stopAutoCounting()
        viewModelScope.launch {
            zikrRepository.updateProgress(
                id = current.id,
                currentCount = 0,
                completedRounds = current.completedRounds
            )
        }
    }

    private fun performIncrement(isAuto: Boolean): Boolean {
        val state = uiState.value
        val current = state.selectedZikr ?: return false
        val prefs = state.preferences

        // In automatic mode, stop once target is reached
        if (isAuto && current.currentCount >= current.targetCount) {
            stopAutoCounting()
            return false
        }

        val nextCount = current.currentCount + 1
        val reachedTargetNow = current.currentCount < current.targetCount && nextCount == current.targetCount
        val nextRounds = if (reachedTargetNow) current.completedRounds + 1 else current.completedRounds

        viewModelScope.launch {
            zikrRepository.updateProgress(
                id = current.id,
                currentCount = nextCount,
                completedRounds = nextRounds
            )
        }

        if (reachedTargetNow) {
            if (prefs.completionSoundEnabled) {
                soundManager.playCompletionSound(prefs.soundVolume)
            } else if (prefs.countSoundEnabled) {
                soundManager.playCountSound(prefs.selectedSound, prefs.soundVolume)
            }
            if (prefs.hapticEnabled) {
                _events.tryEmit(SheenUiEvent.HapticComplete)
            }
            _events.tryEmit(SheenUiEvent.TargetReached(current.name, current.targetCount))
            if (isAuto) {
                stopAutoCounting()
            }
            return false
        } else {
            if (prefs.countSoundEnabled) {
                soundManager.playCountSound(prefs.selectedSound, prefs.soundVolume)
            }
            if (prefs.hapticEnabled) {
                _events.tryEmit(SheenUiEvent.HapticTick)
            }
            return true
        }
    }

    // ---------------------------------------------------------
    // Automatic Hands-Free Counting (Elapsed-Time Accurate, Foreground-Only)
    // ---------------------------------------------------------
    fun startAutoCounting() {
        val current = uiState.value.selectedZikr ?: return
        val intervalMs = uiState.value.preferences.autoIntervalMs.coerceAtLeast(500L)

        // If already at or above target, reset to 0 before starting a fresh auto round
        if (current.currentCount >= current.targetCount) {
            viewModelScope.launch {
                zikrRepository.updateProgress(
                    id = current.id,
                    currentCount = 0,
                    completedRounds = current.completedRounds
                )
            }
        }

        accumulatedSessionMs = 0L
        remainingUntilNextTickMs = intervalMs
        launchAutoLoop(intervalMs)
    }

    fun resumeAutoCounting() {
        if (_autoCountState.value.status != AutoCountStatus.PAUSED) return
        val current = uiState.value.selectedZikr ?: return
        if (current.currentCount >= current.targetCount) {
            stopAutoCounting()
            return
        }
        val intervalMs = uiState.value.preferences.autoIntervalMs.coerceAtLeast(500L)
        if (remainingUntilNextTickMs <= 0L || remainingUntilNextTickMs > intervalMs) {
            remainingUntilNextTickMs = intervalMs
        }
        launchAutoLoop(intervalMs)
    }

    fun pauseAutoCounting() {
        pauseInternal(fromLifecycle = false)
    }

    /**
     * Strictly called whenever SHEEN loses foreground focus (app switch, minimize, screen lock).
     * Never resumes automatically when the user returns.
     */
    fun pauseAutoCountingFromLifecycle() {
        if (_autoCountState.value.status == AutoCountStatus.RUNNING) {
            pauseInternal(fromLifecycle = true)
        }
    }

    private fun pauseInternal(fromLifecycle: Boolean) {
        if (_autoCountState.value.status != AutoCountStatus.RUNNING) return
        val now = SystemClock.elapsedRealtime()
        accumulatedSessionMs += (now - segmentStartElapsedMs).coerceAtLeast(0L)
        autoJob?.cancel()
        autoJob = null

        _autoCountState.value = _autoCountState.value.copy(
            status = AutoCountStatus.PAUSED,
            pausedByLifecycle = fromLifecycle,
            elapsedSessionMs = accumulatedSessionMs
        )
    }

    fun stopAutoCounting() {
        autoJob?.cancel()
        autoJob = null
        accumulatedSessionMs = 0L
        remainingUntilNextTickMs = 0L
        _autoCountState.value = AutoCountState(
            status = AutoCountStatus.STOPPED,
            pausedByLifecycle = false,
            elapsedSessionMs = 0L,
            nextTickProgress = 0f
        )
    }

    private fun launchAutoLoop(initialIntervalMs: Long) {
        autoJob?.cancel()
        segmentStartElapsedMs = SystemClock.elapsedRealtime()
        var nextTickAtMs = segmentStartElapsedMs + remainingUntilNextTickMs

        _autoCountState.value = AutoCountState(
            status = AutoCountStatus.RUNNING,
            pausedByLifecycle = false,
            elapsedSessionMs = accumulatedSessionMs,
            nextTickProgress = (1f - remainingUntilNextTickMs.toFloat() / initialIntervalMs.toFloat()).coerceIn(0f, 1f)
        )

        autoJob = viewModelScope.launch {
            while (isActive) {
                val intervalMs = uiState.value.preferences.autoIntervalMs.coerceAtLeast(500L)
                val now = SystemClock.elapsedRealtime()
                val remaining = nextTickAtMs - now
                val totalSession = accumulatedSessionMs + (now - segmentStartElapsedMs).coerceAtLeast(0L)

                if (remaining <= 0L) {
                    val shouldContinue = performIncrement(isAuto = true)
                    if (!shouldContinue) {
                        break
                    }
                    // Advance by exact interval to prevent drift, while preventing burst catch-up
                    nextTickAtMs = maxOf(nextTickAtMs + intervalMs, SystemClock.elapsedRealtime() + 50L)
                    remainingUntilNextTickMs = intervalMs
                    _autoCountState.value = _autoCountState.value.copy(
                        elapsedSessionMs = totalSession,
                        nextTickProgress = 0f
                    )
                } else {
                    remainingUntilNextTickMs = remaining
                    val tickProgress = (1f - remaining.toFloat() / intervalMs.toFloat()).coerceIn(0f, 1f)
                    _autoCountState.value = _autoCountState.value.copy(
                        elapsedSessionMs = totalSession,
                        nextTickProgress = tickProgress
                    )
                    delay(minOf(remaining, 40L))
                }
            }
        }
    }

    // ---------------------------------------------------------
    // Preferences & Sound Preview
    // ---------------------------------------------------------
    fun setAutoIntervalMs(intervalMs: Long) {
        val clamped = intervalMs.coerceIn(500L, 300_000L)
        viewModelScope.launch {
            preferencesRepository.setAutoIntervalMs(clamped)
        }
        // If currently running, smoothly restart tick timing with the new interval
        if (_autoCountState.value.status == AutoCountStatus.RUNNING) {
            val now = SystemClock.elapsedRealtime()
            accumulatedSessionMs += (now - segmentStartElapsedMs).coerceAtLeast(0L)
            remainingUntilNextTickMs = clamped
            launchAutoLoop(clamped)
        } else if (_autoCountState.value.status == AutoCountStatus.PAUSED) {
            remainingUntilNextTickMs = clamped
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { preferencesRepository.setThemeMode(mode) }
    }

    fun setAccentPalette(palette: AccentPalette) {
        viewModelScope.launch { preferencesRepository.setAccentPalette(palette) }
    }

    fun setCounterFontStyle(style: CounterFontStyle) {
        viewModelScope.launch { preferencesRepository.setCounterFontStyle(style) }
    }

    fun setCounterFontSize(size: CounterFontSize) {
        viewModelScope.launch { preferencesRepository.setCounterFontSize(size) }
    }

    fun setCountSoundEnabled(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.setCountSoundEnabled(enabled) }
    }

    fun setCompletionSoundEnabled(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.setCompletionSoundEnabled(enabled) }
    }

    fun setSelectedSound(sound: CountSoundType) {
        viewModelScope.launch { preferencesRepository.setSelectedSound(sound) }
        soundManager.playCountSound(sound, uiState.value.preferences.soundVolume)
    }

    fun previewCompletionSound() {
        soundManager.playCompletionSound(uiState.value.preferences.soundVolume)
    }

    fun setSoundVolume(volume: Float) {
        viewModelScope.launch { preferencesRepository.setSoundVolume(volume) }
    }

    fun setHapticEnabled(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.setHapticEnabled(enabled) }
    }

    fun setKeepScreenOn(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.setKeepScreenOn(enabled) }
    }

    override fun onCleared() {
        super.onCleared()
        autoJob?.cancel()
    }

    class Factory(
        private val zikrRepository: ZikrRepository,
        private val preferencesRepository: UserPreferencesRepository,
        private val soundManager: SoundManager
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SheenViewModel(zikrRepository, preferencesRepository, soundManager) as T
        }
    }
}
