package com.sheen.zikr

import com.sheen.zikr.data.local.ZikrEntity
import com.sheen.zikr.ui.components.containsArabicScript
import com.sheen.zikr.ui.components.formatDurationTimer
import com.sheen.zikr.ui.components.formatIntervalLabel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ZikrEntityTest {

    @Test
    fun roundsAndLapCountMatchEasyCounterBehavior() {
        val zikr = ZikrEntity(name = "سُبْحَانَ اللَّهِ", targetCount = 100, currentCount = 102)
        assertEquals(1, zikr.rounds)
        assertEquals(2, zikr.lapCount)
        assertEquals(2, zikr.progressPercent)
        assertEquals(98, zikr.remainingCount)
        assertFalse(zikr.isTargetReached)
    }

    @Test
    fun exactMultipleCompletesRound() {
        val zikr = ZikrEntity(name = "SubhanAllah", targetCount = 33, currentCount = 33)
        assertEquals(1, zikr.rounds)
        assertEquals(0, zikr.lapCount)
        assertTrue(zikr.isTargetReached)
    }

    @Test
    fun detectsArabicAndLatinScriptsCorrectly() {
        assertTrue(containsArabicScript("سُبْحَانَ اللَّهِ"))
        assertFalse(containsArabicScript("SubhanAllah"))
    }

    @Test
    fun formatsIntervalsAndTimersProperly() {
        assertEquals("3s", formatIntervalLabel(3000L))
        assertEquals("1.5s", formatIntervalLabel(1500L))
        assertEquals("01:05", formatDurationTimer(65_000L))
    }
}
