# SHEEN ProGuard Rules
-keep class com.sheen.zikr.data.local.** { *; }
-keep class com.sheen.zikr.data.preferences.** { *; }
-dontwarn kotlinx.coroutines.**
